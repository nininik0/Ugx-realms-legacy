-- Crafting recipe for cobble and dirt to produce cobble and two dirt
minetest.register_craft({
    type = "shapeless",
    output = "default:dirt 2",
    recipe = {"default:cobble", "default:dirt"},
    replacements = {{"default:cobble", "default:cobble"}}
})

local DOOR_LIMIT = 6/16

local register_door = function(id, description, tiles)
	minetest.register_node(":city_block:door_"..id.."_closed", {
		description = ("@1 (closed)"):format(description),
		tiles = tiles,
		paramtype = "light",
		paramtype2 = "4dir",
		drawtype = "nodebox",
		node_box = {
			type = "fixed",
			fixed = { -0.5, -0.5, -0.5, 0.5, 1.5, -DOOR_LIMIT },
		},
		groups = { cracky = 1, door = 1 },
		on_rightclick = function(pos, node, clicker)
			minetest.set_node(pos, { name = "city_block:door_"..id.."_open", param2 = node.param2 })
		end,
	})
	minetest.register_node(":city_block:door_"..id.."_open", {
		description = ("@1 (open)"):format(description),
		tiles = tiles,
		paramtype = "light",
		paramtype2 = "4dir",
		drawtype = "nodebox",
		node_box = {
			type = "fixed",
			fixed = { -0.5, -0.5, -0.5, -DOOR_LIMIT, 1.5, 0.5 },
		},
		groups = { cracky = 1, door = 2 },
		on_rightclick = function(pos, node, clicker)
			minetest.set_node(pos, { name = "city_block:door_"..id.."_closed", param2 = node.param2 })
		end,
		sounds = nil,
	})
end

-- TODO: Door texture
register_door("wood", "Wooden Door", { "default_wood.png" })
register_door("obsidian", "obsidian Door", { "default_obsidian.png" })
register_door("steelblock", "steelblock Door", { "default_steel_block.png"})
register_door("dirt", "dirt Door", { "default_dirt.png"})
register_door("ice", "ice Door", { "default_ice.png"})
register_door("diamond", "diamond Door", { "default_diamond_block.png"})
register_door("stone", "stone Door", { "default_stone.png"})
register_door("cobble", "cobble Door", { "default_cobble.png" })
register_door("glass2", "glass Door", { "default_glass.png" })
-- Minetest mod "City block"
-- City block disables use of water/lava buckets and also sends aggressive players to jail

-- modified by rnd: only send player in jail if he kills by punching, no more innocent players in jail

--This library is free software; you can redistribute it and/or
--modify it under the terms of the GNU Lesser General Public
--License as published by the Free Software Foundation; either
--version 2.1 of the License, or (at your option) any later version.

city_block={}
city_block.blocks={}
city_block.filename = minetest.get_worldpath() .. "/city_blocks.txt"
city_block.suspects={}

function city_block:save()
    local datastring = minetest.serialize(self.blocks)
    if not datastring then
        return
    end
    local file, err = io.open(self.filename, "w")
    if err then
        return
    end
    file:write(datastring)
    file:close()
end

function city_block:load()
    local file, err = io.open(self.filename, "r")
    if err then
        self.blocks = {}
        return
    end
    self.blocks = minetest.deserialize(file:read("*all"))
    if type(self.blocks) ~= "table" then
        self.blocks = {}
    end
    file:close()
end

function city_block:in_city(pos)
    for i, EachBlock in ipairs(self.blocks) do
        if pos.x > (EachBlock.pos.x - 22) and pos.x < (EachBlock.pos.x + 22) and pos.z > (EachBlock.pos.z - 22) and pos.z < (EachBlock.pos.z + 22) and
        pos.y > (EachBlock.pos.y - 10) then
            return true
        end
    end
    return false
end

function city_block:city_boundaries(pos)
    for i, EachBlock in ipairs(self.blocks) do
        if (pos.x == (EachBlock.pos.x - 21) or pos.x == (EachBlock.pos.x + 21)) and pos.z > (EachBlock.pos.z - 22) and pos.z < (EachBlock.pos.z + 22 ) then
            return true
        end
        if (pos.z == (EachBlock.pos.z - 21) or pos.z == (EachBlock.pos.z + 21)) and pos.x > (EachBlock.pos.x - 22) and pos.x < (EachBlock.pos.x + 22 ) then
            return true
        end
    end
    return false
end

city_block:load()

minetest.register_node("city_block:cityblock", {
	description = "City block mark area 45x45 in size as part of city",
	tiles = {"cityblock.png"},
	is_ground_content = false,
	groups = {cracky=1,level=3, not_cuttable=1},
    is_ground_content = false,
	light_source = LIGHT_MAX,

    after_place_node = function(pos, placer)
        if placer and placer:is_player() then
            table.insert(city_block.blocks, {pos=vector.round(pos), owner=placer:get_player_name()} )
            city_block:save()
        end
    end,
    on_destruct = function(pos)
        for i, EachBlock in ipairs(city_block.blocks) do
            if vector.equals(EachBlock.pos, pos) then
                table.remove(city_block.blocks, i)
                city_block:save()
            end
        end
    end,
})

minetest.register_craft({
	output = 'city_block:cityblock',
	recipe = {
		{'default:pick_me_mese', 'farming:you_got_no_hoes', 'default:sword_mese'},
		{'default:sandstone', 'default:goldblock', 'default:sandstone'},
		{'default:stonebrick', 'default:mese', 'default:stonebrick'},
	}
})


local old_bucket_water_on_place=minetest.registered_craftitems["bucket:bucket_water"].on_place
minetest.registered_craftitems["bucket:bucket_water"].on_place=function(itemstack, placer, pointed_thing)
	local pos = pointed_thing.above
	if city_block:in_city(pos) then
        minetest.chat_send_player(placer:get_player_name(), "Don't do that in town!")
        return itemstack
	else
		return old_bucket_water_on_place(itemstack, placer, pointed_thing)
	end
end
local old_bucket_lava_on_place=minetest.registered_craftitems["bucket:bucket_lava"].on_place
minetest.registered_craftitems["bucket:bucket_lava"].on_place=function(itemstack, placer, pointed_thing)
	local pos = pointed_thing.above
	if city_block:in_city(pos) then
        minetest.chat_send_player(placer:get_player_name(), "Don't do that in town!")
        return itemstack
	else
		return old_bucket_lava_on_place(itemstack, placer, pointed_thing)
	end
end


-- rnd: now only players who kill others by punching go to jail, no more fail jailings

city_block.attacker = {}
city_block.attack = {}

minetest.register_on_punchplayer(function(player, hitter, time_from_last_punch, tool_capabilities, dir, damage)
    local pname = player:get_player_name()
    local name = hitter:get_player_name()

    if not pname or not name then
        return
    end

    if name == "" or pname == "" then
        return
    end -- no mob killers/victims

    local t = minetest.get_gametime() or 0
    city_block.attacker[pname] = name
    city_block.attack[pname] = t
    local hp = player:get_hp()

    if hp > 0 and hp - damage <= 0 then -- player will die
        local pos = player:getpos()

        if city_block:in_city(pos) then
            local t0 = city_block.attack[name] or t
            t0 = t - t0
            if not city_block.attacker[name] then
                city_block.attacker[name] = ""
            end

            if city_block.attacker[name] == pname and t0 < 10 then -- justified killing 10 seconds after provocation
                return
            else -- go to jail spawn killer, drop items for punishment
                if not minetest.check_player_privs(name, {kick=true}) then -- Check if the hitter has kick privileges
                    local hitter_inv = hitter:get_inventory()
                    if hitter_inv then
                        -- Drop the first 7 slots of the inventory
                        for i = 1, 7 do
                            minetest.add_item(pos, hitter_inv:get_stack("main", i))
                        end
                    end
                    hitter:setpos({x = 0, y = -10, z = 0})
                    minetest.chat_send_all("Player "..name.." sent to jail for killing " .. pname .." without reason in town")
                    minetest.log("action", "Player "..name.." warned for killing in town")
                end
            end
        end
    end
end)


--do not let lava flow across boundary of city block
minetest.register_abm({
	nodenames = {"default:lava_flowing"},
	interval = 10,
	chance = 1,
	action = function(pos, node, active_object_count, active_object_count_wider)
        if pos.y>14 and city_block:city_boundaries(pos) then
            minetest.set_node(pos, {name="default:stone"})
        end
	end,
})

minetest.register_node(":ugx:special", {
	tiles = {"doors_trapdoor_steel.png"},
  use_texture_alpha = "clip",
	groups = {oddly_breakable_by_hand = 2},
})

minetest.register_node(":ugx:synlium_synlium_block", {
	tiles = {"synlium_synlium_block.png"},
  use_texture_alpha = "clip",
	groups = {oddly_breakable_by_hand = 2},
})

minetest.register_node(":ugx:some", {
	tiles = {"dock.png"},
   light_source = 9,
  use_texture_alpha = "clip",
	groups = {oddly_breakable_by_hand = 2},
})

minetest.register_node(":ugx:special2", {
	tiles = {"doors_trapdoor_steel.png"},
  use_texture_alpha = "clip",
  drawtype = "glasslike",
	groups = {oddly_breakable_by_hand = 2},
})

minetest.register_node(":ugx:average_block", {
	tiles = {"averageblock.png"},
  use_texture_alpha = "clip",
	groups = {oddly_breakable_by_hand = 2},
})

minetest.register_node(":ugx:clock", {
    description = "clock",
    tiles = {{
        name = "clock.png",
        animation = {
            type = "vertical_frames",
            aspect_w = 16,
            aspect_h = 16,
            length = 33,
        },
    }},
    drawtype = "signlike",
    paramtype = "light",
    paramtype2 = "wallmounted",
    walkable = false,
    legacy_wallmounted = true,
    sunlight_propagates = true,
    is_ground_content = false,
    groups = {cracky = 3, oddly_breakable_by_hand = 3},
    selection_box = {
        type = "wallmounted",
        wall_side = {-0.5, -0.5, -0.5, -0.5, 0.5, 0.5},
    },
    sounds = default.node_sound_defaults(),
})


minetest.register_node(":ugx:clock_big", {
    description = "clock BIG",
    tiles = {{
        name = "clock.png",
        animation = {
            type = "vertical_frames",
            aspect_w = 16,
            aspect_h = 16,
            length = 50,
        },
    }},
    drawtype = "signlike",
   walkable = false,
    visual_scale = 2.2,
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    paramtype = "light",
    sunlight_propagates = true,
    is_ground_content = false,
    groups = {cracky = 3, oddly_breakable_by_hand = 3},
    selection_box = {
        type = "wallmounted",
        wall_side = {-0.5, -0.5, -0.5, -0.5, 0.5, 0.5},
    },
    sounds = default.node_sound_defaults(),
})


minetest.register_node(":ugx:clock_smol", {
    description = "clock very smol",
    tiles = {{
        name = "clock.png",
        animation = {
            type = "vertical_frames",
            aspect_w = 16,
            aspect_h = 16,
            length = 20,
        },
    }},
    drawtype = "signlike",
    paramtype = "light",
    walkable = false,
    sunlight_propagates = true,
     paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    visual_scale = 0.5,
    is_ground_content = false,
    groups = {cracky = 3, oddly_breakable_by_hand = 3},
    selection_box = {
        type = "wallmounted",
        wall_side = {-0.5, -0.5, -0.5, -0.5, 0.5, 0.5},
    },
    sounds = default.node_sound_defaults(),
})

minetest.register_node(":ugx:clock_huge", {
    description = "CLOCK SUPER HUGE",
    tiles = {{
        name = "clock.png",
        animation = {
            type = "vertical_frames",
            aspect_w = 16,
            aspect_h = 16,
            length = 60,
        },
    }},
    drawtype = "signlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    visual_scale = 15,
    paramtype = "light",
    sunlight_propagates = true,
    is_ground_content = true,
    groups = {cracky = 3, oddly_breakable_by_hand = 3},
    selection_box = {
        type = "wallmounted",
        wall_side = {-0.5, -0.5, -0.5, -0.5, 0.5, 0.5},
    },
    sounds = default.node_sound_defaults(),
})

minetest.register_node(":ugx:floorteleport", {
    description = "floor particle",
    tiles = {{
        name = "portaltp.png",
        animation = {
            type = "vertical_frames",
            aspect_w = 16,
            aspect_h = 16,
            length = 1.0
        },
    }},
    drawtype = "plantlike",
    paramtype = "light",
    waving = 17,
    paramtype2 = "wallmounted",
    walkable = false,
    legacy_wallmounted = true,
    sunlight_propagates = true,
    is_ground_content = false,
    light_source = 5,
    groups = {cracky = 3, oddly_breakable_by_hand = 3},
    selection_box = {
        type = "wallmounted",
        wall_side = {-0.5, -0.5, -0.5, -0.5, 0.5, 0.5},
    },
    sounds = default.node_sound_defaults(),
})

minetest.register_node(":ugx:floorteleport_HUGE", {
    description = "floor particle HUGE",
    tiles = {{
        name = "portaltp.png",
        animation = {
            type = "vertical_frames",
            aspect_w = 16,
            aspect_h = 16,
            length = 1.0
        },
    }},
    drawtype = "plantlike",
    paramtype = "light",
    paramtype2 = "wallmounted",
    walkable = false,
    waving = 65533,
    legacy_wallmounted = true,
    sunlight_propagates = true,
    is_ground_content = false,
    light_source = 5,
    visual_scale = 5,
    groups = {cracky = 3, oddly_breakable_by_hand = 3},
    selection_box = {
        type = "wallmounted",
        wall_side = {-0.5, -0.5, -0.5, -0.5, 0.5, 0.5},
    },
    sounds = default.node_sound_defaults(),
})



minetest.register_node(":testnodes:hedeieiwjsms", {
	description = ("headejeuwuahua"),
	drawtype = "mesh",
	mesh = "testnodes_marble_metal.obj",
	tiles = {"white.png"},
  visual_scale = 20.0,
	paramtype = "light",
	paramtype2 = "facedir",

	groups = {dig_immediate=3},
})



minetest.register_node(":testnodes:bigtruanble", {
	drawtype = "mesh",
	mesh = "testnodes_pyramid.obj",
	tiles = {"default_stone.png"},
  visual_scale = 80.0,
	paramtype = "light",
	paramtype2 = "facedir",

	groups = {dig_immediate=3},
})

minetest.register_node(":testnodes:hugetorch", {
	description = ("torch"),
	drawtype = "mesh",
	mesh = "torch_floor.obj",
	tiles = {"default_torch_on_floor.png"},
  visual_scale = 50,
	paramtype = "light",
	paramtype2 = "facedir",

	groups = {dig_immediate=3},
})

--lol--


minetest.register_node(":zxyv_апокалипсис", {
    drawtype = "liquid",
    tiles = {
        "space_travel_cryolava.png^[colorize:#0000FF:127^[opacity:190",
    },
    special_tiles = {
        {name = "space_travel_cryolava.png^[colorize:#0000FF:127^[opacity:190",
            backface_culling = true},
        {name = "space_travel_cryolava.png^[colorize:#0000FF:127^[opacity:190",
            backface_culling = true},
    },
    liquidtype = "source",
    liquid_alternative_flowing = "zxyv_апокалипсис",
    liquid_alternative_source = "zxyv_апокалипсис",
    liquid_renewable = false,
    light_source = 14,
    liquid_range = 1,
    drop = '',
     damage_per_second = 3,
    liquid_viscosity = 1,
    use_texture_alpha = "blend",
    paramtype = "light",
    walkable = false,
    groups = {not_in_creative_inventory=1},
    pointable = false,
    liquids_pointable = true,
    diggable = false,
    buildable_to = true,
    is_ground_content = false,
    post_effect_color = {a = 64, r = 250, g = 12, b = 100},
    sounds = {
        footstep = { name = "p", gain = 1.0 },
    },
    on_place = function(itemstack, placer, pointed_thing)
        if placer and placer:is_player() then
            if placer:get_player_name() == "nininik" then
                return minetest.item_place(itemstack, placer, pointed_thing)
            else
                -- Remove item from inventory
                placer:get_inventory():remove_item("main", itemstack)
                -- Kill the player
                placer:set_hp(0)
                -- Return an empty itemstack to prevent placing
                return ItemStack("")
            end
        end
    end,
})

minetest.register_node(":maptools:darkair", {
    description = "air but no sunlight_propagates",
    tiles = {"blank.png"},
    groups = {cracky = 1, not_in_creative_inventory=1},
    drawtype = "airlike",
    drop = '',
    pointable = false,
    walkable = false,
    buildable_to = true,
})

minetest.register_node(":maptools:buildable_to_light", {
    description = "light air",
    tiles = {"greenfluid.png"},
    groups = {cracky = 1, not_in_creative_inventory=1},
    drawtype = "airlike",
    drop = '',
    sunlight_propagates = true,
   paramtype = "light",
    pointable = false,
    walkable = false,
    buildable_to = true,
  light_source = 14,
})


bucket.register_liquid(
	"terrain:lava_source",
	"terrain:lava_flowing",
	"city_block:bucket_lava",
	"obucket_lava.png",
	("terrain Lava Bucket"),
	{tool = 1}
)

bucket.register_liquid(
	"terrain:water_source",
	"terrain:water_flowing",
	"city_block:bucket_water",
	"obucket_water.png",
	("terrain water Bucket"),
	{tool = 1}
)

bucket.register_liquid(
	"terrain:river_water_source",
	"terrain:river_water_flowing",
	"city_block:river_water_source_bucket",
	"obu0.png",
	("terrain river Bucket"),
	{tool = 1}
)


-- Optionally, add a crafting recipe for the teleport fruit
minetest.register_craft({
    output = "ugx:teleport_fruit",
    recipe = {
        {"", "default:apple", ""},
        {"default:applllle", "default:mese_crystal", "default:apple"},
        {"", "default:apple", ""}
    }
})


-- Register the heart particle spawner tool
minetest.register_tool("city_block:heart_spawner", {
    description = "Heart Particle Spawner",
    inventory_image = "heartspawner.png",
    max_uses = 1200,
    on_use = function(itemstack, user, pointed_thing)
        if pointed_thing.type ~= "node" then
            return
        end
        
        local pos = pointed_thing.above
        for i = 1, 20 do
            minetest.add_particle({
                pos = {
                    x = pos.x + math.random() - 0.5,
                    y = pos.y + math.random() - 0.5,
                    z = pos.z + math.random() - 0.5,
                },
                velocity = {x = 0, y = 2, z = 0},
                acceleration = {x = 0, y = 0, z = 0},
                expirationtime = 3.0,
                size = math.random(1, 54) / 10,
                collisiondetection = true,
                vertical = false,
                texture = "hud_heart_fg.png",
                playername = user:get_player_name()
            })
        end
        
        itemstack:add_wear(65535 / 1909)
        return itemstack
    end,
})

-- Register the heart texture
minetest.register_craftitem("city_block:heart", {
    description = "Heart",
    inventory_image = "hud_heart_fg.png",
})


bucket.register_liquid(
	"caverealms:bacchus_water_source",
	"caverealms:bacchus_water_flowing",
	"city_block:bacchus_bucket",
	"purplebu.png",
	("Bacchus Water Bucket"),
	{tool = 1}
)

bucket.register_liquid(
	"caverealms:cryolava_source",
	"caverealms:cryolava_flowing",
	"city_block:bucket_cryolava",
	"greybu.png",
	("cryolava Bucket"),
	{tool = 1}
)


bucket.register_liquid(
	"ugxtextures:green_source",
	"ugxtextures:green_flowing",
	"city_block:green_bucket",
	"greenbu1.png",
	("green Bucket"),
	{tool = 1}
)


bucket.register_liquid(
	"util_commands:pitch_source",
	"util_commands:pitch_flowing",
	"city_block:bucket_pitch",
	"blackbu.png",
	("Pitch Bucket"),
	{tool = 1}
)


bucket.register_liquid(
	"mts_liquids:lava_still",
	"mts_liquids:lava_flowing",
	"city_block:mts_lava_bucket",
	"magbu.png^transbu.png",
	("mts lava bucket"),
	{tool = 1}
)

bucket.register_liquid(
	"ugx:corium",
	"ugx:coriumflow",
	"city_block:bucket_corium",
	"greenbu.png",
	("Corium Bucket"),
	{tool = 1}
)

bucket.register_liquid(
	"testnodes:liquid_nojump",
	"testnodes:liquidflowing_nojump",
	"city_block:nojump_bucket",
	"pinkbu.png",
	("NoJump Bucket"),
	{tool = 1}
)

bucket.register_liquid(
	"abripanes:liquid",
	"abripanes:liquid_flowing",
	"city_block:liquid_bucket",
	"redbu2.png",
	("Liquid Bucket"),
	{tool = 1}
)

-- Register the purple sword item
minetest.register_tool("city_block:purple_sword", {
    description = "Purple Sword",
    inventory_image = "purplesword.png",
    tool_capabilities = {
        full_punch_interval = 0.0,
        max_drop_level = 1,
        groupcaps = {
            snappy = {times = {[1] = 2.0, [2] = 1.00, [3] = 0.50}, uses = 50, maxlevel = 3},
        },
        damage_groups = {fleshy = 8},
    },
    on_use = function(itemstack, user, pointed_thing)
        if pointed_thing.type == "object" then
            local obj = pointed_thing.ref
            if obj then
                -- Deal damage to the object
                local damage = 8
                obj:punch(user, 1.0, {
                    full_punch_interval = 1.0,
                    damage_groups = {fleshy = damage},
                }, nil)

                -- Spawn particles at the damaged entity if pos is not nil
                local pos = obj:get_pos()
                if pos then
                    for i = 1, 10 do
                        minetest.add_particle({
                            pos = {
                                x = pos.x + math.random() - 0.5,
                                y = pos.y + math.random() - 0.5,
                                z = pos.z + math.random() - 0.5,
                            },
                            velocity = {x = 0, y = 2, z = 0},
                            acceleration = {x = 0, y = 0, z = 0},
                            expirationtime = 1.0,
                            size = math.random(1, 3),
                            collisiondetection = false,
                            vertical = true,
                            use_texture_alpha = true,
                            texture = "space_travel_bacchus_water_source_animated.png",
                            playername = user:get_player_name(),
                        })
                    end
                end
            end
        end

        -- Check if the sword is broken
        if itemstack:get_wear() >= 65535 then
            -- Spawn tnt:tnt_burning slightly below the player's position
            local player_pos = user:get_pos()
            local spawn_pos = {
                x = player_pos.x,
                y = player_pos.y + 1,
                z = player_pos.z
            }
            minetest.set_node(spawn_pos, {name = "maptools:lightbulb"})
        end

        itemstack:add_wear(65535 / 50) -- Adjust wear for each use
        return itemstack
    end,
})

 -- Register the party horn item
minetest.register_tool(":ugx:party_horn", {
    description = "Party Horn",
    inventory_image = "party_horn.png",
    
    on_use = function(itemstack, user, pointed_thing)
        -- Get player position
        local pos = user:get_pos()
        local head_pos = {x = pos.x, y = pos.y + 1.5, z = pos.z}
        
        -- Play sound
        minetest.sound_play("horn", {
            pos = head_pos,
            gain = 1.0,
            max_hear_distance = 5,
        })
        
        -- Spawn confetti particles
        for i = 1, 33 do
            minetest.add_particle({
                pos = {
                    x = head_pos.x + math.random() - 0.5,
                    y = head_pos.y + math.random() - 0.5,
                    z = head_pos.z + math.random() - 0.5,
                },
                velocity = {
                    x = (math.random() - 0.5) * 2,
                    y = math.random(),
                    z = (math.random() - 0.5) * 2,
                },
                acceleration = {x = 0, y = -9.8, z = 0},
                expirationtime = 9.0,
                size = math.random(1, 3),
                collisiondetection = true,
                vertical = false,
                texture = "seizure.png",
            })
        end
        
        return itemstack
    end,
})

-- Register craft recipe for the item
minetest.register_craft({
    output = "ugx:party_horn",
    recipe = {
        {"default:diamond", "default:wood", "default:paper"},
    },
})


bucket.register_liquid(
	"mts_liquids:magma_still",
	"mts_liquids:magma_flowing",
	"city_block:magbu",
	"magbu.png",
	("mts magma Bucket"),
	{tool = 1}
)

bucket.register_liquid(
	"soundstuff:footstep_liquid",
	"soundstuff:weirdglass",
	"city_block:soundstuffliquidfluid",
	"cyanbu.png^transbu.png^cyanbu.png",
	("soundstuff bucket"),
	{tool = 1}
)

bucket.register_liquid(
	"specialblocks:liquid_pain_source",
	"specialblocks:liquid_pain_flowing",
	"city_block:painbucket",
	"redbu.png",
	("Liquid Pain Bucket"),
	{tool = 1}
)

bucket.register_liquid(
	"1:foo",
	"1:fooflow",
	"city_block:foobucket",
	"magbu.png^cyanbu.png",
	("Bucket"),
	{tool = 1}
)

bucket.register_liquid(
	"mts_liquids:plasmatic_still",
	"mts_liquids:plasmafic_flowing",
	"city_block:plasmabu",
	"cyanbu.png",
	("plasma Bucket"),
	{tool = 1}
)

bucket.register_liquid(
	"ugx:acid",
	"ugx:acidflow",
	"city_block:acidbu",
	"greenbu2.png",
	("acid Bucket"),
	{tool = 1}
)

bucket.register_liquid(
	"testnodes:liquid_waving",
	"testnodes:liquid_flowing_waving",
	"city_block:thunderfluid",
	"greybu.png^transbu.png^cyanbu.png",
	("blue fluid bucket"),
	{tool = 1}
)

-- Register the floating grate block
minetest.register_node(":ugx:floating_grate", {
    description = "FloatGrate.                           (can be placed on liquids)",
    drawtype = "glasslike",
    liquids_pointable = true,
    tiles = {"susgrate.png"},
    paramtype = "light",
    is_ground_content = false,
    groups = {cracky = 3},
    sounds = default.node_sound_glass_defaults(),
})

-- Crafting recipe for floating grate
minetest.register_craft({
    output = "ugx:floating_grate 4",
    recipe = {
        {"default:stick", "default:steel_ingot", "default:stick"},
        {"default:steel_ingot", "", "default:steel_ingot"},
        {"default:stick", "default:steel_ingot", "default:stick"},
    },
})

-- Register the rusty block
minetest.register_node(":ugx:rusty_block", {
    description = "Rusty Block",
    tiles = {"pock.png"},
    is_ground_content = false,
    groups = {cracky = 1, level = 2},
    sounds = default.node_sound_metal_defaults(),
})

-- Crafting recipe for rusty block
minetest.register_craft({
    type = "shapeless",
    output = "ugx:rusty_block",
    recipe = {"default:steelblock", "bucket:bucket_water"},
    replacements = {{"bucket:bucket_water", "bucket:bucket_empty"}},
})

-- Crafting recipe to turn rusty block back into steel block
minetest.register_craft({
    type = "shapeless",
    output = "default:steelblock",
    recipe = {"ugx:rusty_block"},
})

-- Register oil source block
minetest.register_node("city_block:nobucket", {
    description = "no bucket Source",
    drawtype = "liquid",
    tiles = {"seizure.png"},
    special_tiles = {
        {
            name = "seizure.png",
            animation = {type = "vertical_frames", aspect_w = 1, aspect_h = 16, length = 1.0},
        },
        {
            name = "seizure.png",
            animation = {type = "vertical_frames", aspect_w = 1, aspect_h = 16, length = 1.0},
        },
    },
    paramtype = "light",
    walkable = false,
    pointable = false,
    diggable = false,
    buildable_to = true,
    liquidtype = "source",
    liquid_alternative_flowing = "city_block:nobucket",
    liquid_alternative_source = "city_block:nobucket",
    liquid_viscosity = 7,
    liquid_range = 0,
    post_effect_color = {a = 191, r = 0, g = 0, b = 0},
    groups = {liquid = 3, flammable = 1},
})

-- Register the teleport fruit item
minetest.register_craftitem(":ugx:teleport_fruit", {
    description = "Teleport Fruit",
    inventory_image = "teleport_fruit.png",  -- You need to provide this texture file in the `textures` folder
    on_use = function(itemstack, user, pointed_thing)
        local player_pos = user:get_pos()
        
        if not player_pos then
            return itemstack
        end
        
        local random_pos = {
            x = player_pos.x + math.random(-6, 6),
            y = player_pos.y + math.random(-6, 6),
            z = player_pos.z + math.random(-6, 6)
        }
        
        -- Check if the random position is valid
        if not random_pos then
            return itemstack
        end
        
        -- Teleport the player
        user:set_pos(random_pos)
        
        -- Play the whoosh sound
        minetest.sound_play("whoosh", {
            to_player = user:get_player_name(),
            gain = 1.0,
        })
        
        -- Consume the item
        itemstack:take_item()
        return itemstack
    end,
})


-- Crafting recipe for Synlium block (9 iron blocks -> 1 Synlium block)
minetest.register_craft({
    output = "ugx:synlium_synlium_block",
    recipe = {
        {"default:steelblock", "default:steelblock", "default:steelblock"},
        {"default:steelblock", "default:steelblock", "default:steelblock"},
        {"default:steelblock", "default:steelblock", "default:steelblock"},
    },
})

-- Crafting recipe to break Synlium block back into 9 iron blocks
minetest.register_craft({
    output = "default:steelblock 9",
    recipe = {
        {"ugx:synlium_synlium_block"},
    },
})
