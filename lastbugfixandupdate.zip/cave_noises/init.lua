local spooky_sound_player_timer = 0

--this is to check if the player is exploring a cave
--if exploring cave not near an open shaft then play a scary noise
--every 5-7 minutes

local spooky_sound_player_timer = 0

minetest.register_globalstep(function(dtime)
    spooky_sound_player_timer = spooky_sound_player_timer + dtime

    -- try to play every 5 minutes
    if spooky_sound_player_timer > 111 then 
        spooky_sound_player_timer = 0

        for _, player in ipairs(minetest.get_connected_players()) do
            local pos = player:get_pos()
            local light = minetest.get_node_light(pos)

            -- Check if light exists before comparing
            if light and pos.y < 0 and light <= 12 then
                print(light)
                minetest.sound_play("spooky_noise", {
                    to_player = player:get_player_name(),
                    gain = 0.5,
                    pitch = math.random(70, 100) / 100
                })
            end
        end
    end
end)