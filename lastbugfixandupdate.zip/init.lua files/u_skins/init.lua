-- Unified Skins for Minetest - based modified Bags from unfied_inventory and skins from inventory_plus

-- Copyright (c) 2012 cornernote, Dean Montgomery
-- License: GPLv3
u_skins = {}
u_skins.type = { SPRITE=0, MODEL=1 }
u_skins.pages = {}
u_skins.u_skins = {}

u_skins.get_type = function(texture)
	if not texture then return end
	if string.sub(texture,0,string.len("character")) == "character" then
		return u_skins.type.MODEL
	end
	if string.sub(texture,0,string.len("player")) == "player" then
		return u_skins.type.SPRITE
	end
end

u_skins.modpath = minetest.get_modpath("u_skins")
dofile(u_skins.modpath.."/skinlist.lua")
dofile(u_skins.modpath.."/meta.lua")
dofile(u_skins.modpath.."/players.lua")


u_skins.update_player_skin = function(player)
	local name = player:get_player_name()
	if u_skins.get_type(u_skins.u_skins[name]) == u_skins.type.SPRITE then
		player:set_properties({
			visual = "upright_sprite",
			textures = {u_skins.u_skins[name]..".png",u_skins.u_skins[name].."_back.png"},
			visual_size = {x=1, y=2},
		})
	elseif u_skins.get_type(u_skins.u_skins[name]) == u_skins.type.MODEL then
		player:set_properties({
			visual = "mesh",
			textures = {u_skins.u_skins[name]..".png"},
			visual_size = {x=1, y=1},
		})
	end
	u_skins.save()
end

-- Display Current Skin
unified_inventory.register_page("u_skins", {
	get_formspec = function(player)
		local name = player:get_player_name()
		local formspec = "background[0.06,0.99;7.92,7.52;ui_misc_form.png]"
		if u_skins.get_type(u_skins.u_skins[name]) == u_skins.type.MODEL then
			formspec = formspec
				.. "image[0,.75;1,2;"..u_skins.u_skins[name].."_preview.png]"
--disable back preview				.. "image[1,.75;1,2;"..u_skins.u_skins[name].."_preview_back.png]"
				.. "label[6,.5;Raw texture:]"
				.. "image[6,1;2,1;"..u_skins.u_skins[name]..".png]"
			
		else
			formspec = formspec
				.. "image[0,.75;1,2;"..u_skins.u_skins[name]..".png]"
				.. "image[1,.75;1,2;"..u_skins.u_skins[name].."_back.png]"
		end
		local meta = u_skins.meta[u_skins.u_skins[name]]
		if meta then
			if meta.name then
				formspec = formspec .. "label[2,.5;Name: "..meta.name.."]"
			end
			if meta.author then
				formspec = formspec .. "label[2,1;Author: "..meta.author.."]"
			end
			if meta.description then
				formspec = formspec .. "label[2,1.5;"..meta.description.."]"
			end
			if meta.comment then
				formspec = formspec .. 'label[2,2;"'..meta.comment..'"]'
			end
		end

		formspec = formspec .. "button[.75,3;6.5,.5;u_skins_page_0;Change]"
		return {formspec=formspec}
	end,
})

unified_inventory.register_button("u_skins", {
	type = "image",
	image = "u_skins_button.png",
	tooltip = "Choose Skin",
})

-- Create all of the skin-picker pages.
for x = 0, math.floor(#u_skins.list/16+1) do
	unified_inventory.register_page("u_skins_page_"..x, {
		get_formspec = function(player)
			local page = u_skins.pages[player:get_player_name()]
			if page == nil then page = 0 end
			local formspec = "background[0.06,0.99;7.92,7.52;ui_misc_form.png]"
			local index = 0
			local skip = 0 -- Skip u_skins, used for pages
			-- skin thumbnails
			for i, skin in ipairs(u_skins.list) do
				if skip < page*16 then skip = skip + 1 else
					if index < 16 then
						formspec = formspec .. "image_button["..(index%8)..","..((math.floor(index/8))*2)..";1,2;"..skin
						if u_skins.get_type(skin) == u_skins.type.MODEL then
							formspec = formspec .. "_preview"
						end
						formspec = formspec .. ".png;u_skins_set_"..i..";]"
					end
					index = index +1
				end
			end
			-- prev next page buttons
			if page > 0 then
				formspec = formspec .. "button[0,4;1,.5;u_skins_page_"..(page-1)..";<<]"
			else
				formspec = formspec .. "button[0,4;1,.5;u_skins_page_"..page..";<<]"
			end
			formspec = formspec .. "button[.75,4;6.5,.5;u_skins_page_"..page..";Page "..(page+1).."/"..math.floor(#u_skins.list/16+1).."]" -- a button is used so text is centered
			if index > 16 then
				formspec = formspec .. "button[7,4;1,.5;u_skins_page_"..(page+1)..";>>]"
			else
				formspec = formspec .. "button[7,4;1,.5;u_skins_page_"..page..";>>]"
			end
			return {formspec=formspec}
		end,
	})
end

-- click button handlers
minetest.register_on_player_receive_fields(function(player,formname,fields)
	if fields.u_skins then
		unified_inventory.set_inventory_formspec(player,"craft")
	end
	for field, _ in pairs(fields) do
		if string.sub(field,0,string.len("u_skins_set_")) == "u_skins_set_" then
			u_skins.u_skins[player:get_player_name()] = u_skins.list[tonumber(string.sub(field,string.len("u_skins_set_")+1))]
			u_skins.update_player_skin(player)
			unified_inventory.set_inventory_formspec(player,"u_skins")
		end
		if string.sub(field,0,string.len("u_skins_page_")) == "u_skins_page_" then
			u_skins.pages[player:get_player_name()] = tonumber(string.sub(field,string.len("u_skins_page_")+1))
			unified_inventory.set_inventory_formspec(player,"u_skins_page_"..u_skins.pages[player:get_player_name()])
		end
	end
end)

-- set defaults
minetest.register_on_joinplayer(function(player)
	if not u_skins.u_skins[player:get_player_name()] then
		u_skins.u_skins[player:get_player_name()] = "character_1"
	end
	u_skins.update_player_skin(player)
end)




minetest.register_node(":testnodes:aerozoic", {
	description = ("aerozoic").."\n"..
		("param2 = wallmounted rotation (0..5)"),
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	tiles = { "aerozoic.png" },


	walkable = false,
	groups = { dig_immediate = 3 },
	sunlight_propagates = true,
})


minetest.register_node(":testnodes:mesh_wallmounted_player", {
	description = ("Wallmounted player block"),
	drawtype = "mesh",
	mesh = "character.b3d",
	tiles = {"character_1.png"},
	paramtype = "light",
	paramtype2 = "wallmounted",
	collision_box = tall_pyr_cbox,

	groups = {dig_immediate=3},
})

minetest.register_node(":testnodes:aerozoicbringhimbackplease", {
	description = ("AEROZOIC"),
	drawtype = "mesh",
	mesh = "character.b3d",
	tiles = {"character_aerozoic.png"},
  visual_scale = 1.0,
	paramtype = "light",
	paramtype2 = "facedir",

	groups = {dig_immediate=3},
})

minetest.register_node(":ugx:shshshsafaytwtwtdwfwtdrwctrtsr", {
    description = "THE TRUE MEANING OF UGX REVEALED! PLACE TO FIND OUT!",
    paramtype2 = "facedir",
    place_param2 = 0,
    light_source = 14,
    tiles = {"default_lava.png^invisible_node_overlay.png^hud_heart_fg.png^default_grass_1.png"},
    is_ground_content = false,
    groups = {cracky = 2, stone = 1, dig_immediate = 2, not_cuttable = 1},
    sounds = default.node_sound_glass_defaults(),
    
    on_construct = function(pos)
        local meta = minetest.get_meta(pos)
        meta:set_string("infotext", "THE TRUE MEANING OF UGX IS: Ultimate Gaming Experience")
    end,
})

minetest.register_node(":ugx:memorial_block", {
    description = "Memorial Block",
    paramtype2 = "facedir",
    place_param2 = 0,
    tiles = {"default_diamond_block.png^default_diamond.png"},
    is_ground_content = false,
    groups = {cracky = 2, stone = 1, dig_immediate = 2, not_cuttable = 1},
    sounds = default.node_sound_wood_defaults(),
    
    on_construct = function(pos)
        local meta = minetest.get_meta(pos)
        meta:set_string("formspec", "field[text;;${text}]")
        meta:set_string("text", "")
        meta:set_string("placed_by", "")
        meta:set_string("placed_at", os.date("%Y-%m-%d %H:%M:%S"))
        meta:set_string("infotext", "Memorial Block Placed by " .. meta:get_string("placed_by") .. " at: " .. meta:get_string("placed_at"))
    end,
    
    on_receive_fields = function(pos, _, fields, sender)
        local meta = minetest.get_meta(pos)
        if not fields.text then
            return
        end
        
        local player_name = sender:get_player_name()
        local current_text = meta:get_string("text")
        local new_text = fields.text
        
        -- Check if the player has the ban privilege or is the placer
        if minetest.check_player_privs(player_name, {ban=true}) or meta:get_string("placed_by") == player_name then
            if current_text ~= new_text then
                meta:set_string("text", new_text)
                meta:set_string("placed_by", player_name)
                meta:set_string("placed_at", os.date("%Y-%m-%d %H:%M:%S"))
                meta:set_string("infotext", "Memorial Block Placed by " .. player_name .. " at: " .. meta:get_string("placed_at") .. " " .. new_text)
            end
        else
            minetest.chat_send_player(player_name, "You don't have permission to modify this memorial block.")
        end
    end,
})
minetest.register_node(":testnodes:dylanfreddys", {
	description = ("dylanfreddys"),
	drawtype = "mesh",
	mesh = "character.b3d",
	tiles = {"character_60.png"},
  visual_scale = 1.0,
	paramtype = "light",
	paramtype2 = "facedir",

	groups = {dig_immediate=3},
})


minetest.register_node(":testnodes:sussy_lmao", {
	description = ("sussy_lmao"),
	drawtype = "mesh",
	mesh = "character.b3d",
	tiles = {"character_90.png"},
  visual_scale = 1.0,
	paramtype = "light",
	paramtype2 = "facedir",

	groups = {dig_immediate=3},
})



minetest.register_node(":testnodes:pointer", {
	description = ("so"),
	drawtype = "mesh",
	mesh = "character.b3d",
	tiles = {"character_103.png"},
  visual_scale = 1.0,
	paramtype = "light",
	paramtype2 = "facedir",

	groups = {dig_immediate=3},
})

minetest.register_node(":testnodes:nininik", {
	description = ("nininik the server admin"),
	drawtype = "mesh",
	mesh = "character.b3d",
	tiles = {"nininik.png"},
  visual_scale = 1.0,
	paramtype = "light",
	paramtype2 = "facedir",

	groups = {dig_immediate=3},
})


minetest.register_node(":testnodes:mesh_wallmounted_player_aerozoic", {
	description = ("Wallmounted AEROZOIC!!!!"),
	drawtype = "mesh",
	mesh = "character.b3d",
	tiles = {"character_aerozoic.png"},
	paramtype = "light",
	paramtype2 = "wallmounted",
	collision_box = tall_pyr_cbox,

	groups = {dig_immediate=3},
})


minetest.register_node(":testnodes:ugx_aero_block", {
	description = ("UGX♥︎REALMS"),
	tiles = {"default_water.png^default_grass_4.png^testnodes_plantlike_meshoptions.png^aerotop.png"},
	paramtype = "light",
	paramtype2 = "wallmounted",
	collision_box = tall_pyr_cbox,
  light_source = 7,
	groups = {dig_immediate=3},
})


minetest.register_node(":ugxtextures:green_flowing", {
description = "Flowing green liquid",
inventory_image = minetest.inventorycube("greenfluid.png"),
drawtype = "flowingliquid",
tiles = {"greenfluid.png"},
special_tiles = {
{name="greenfluid.png", backface_culling=false},
{name="greenfluid.png", backface_culling=true},
},
paramtype = "light",
walkable = false,
pointable = false,
diggable = true,
buildable_to = true,
liquidtype = "flowing",
liquid_alternative_flowing = "ugxtextures:green_flowing",
liquid_alternative_source = "ugxtextures:green_source",
liquid_viscosity = 1,
groups = {water=3, liquid=3, puts_out_fire=1},
})

minetest.register_node(":ugxtextures:green_source", {
description = "Sand Source",
inventory_image = minetest.inventorycube("greenfluid.png"),
drawtype = "liquid",
tiles = {"greenfluid.png"},
special_tiles = {
-- New-style water source material (mostly unused)
{name="greenfluid.png", backface_culling=false},
},
paramtype = "light",
walkable = false,
pointable = false,
diggable = true,
buildable_to = true,
liquidtype = "source",
liquid_alternative_flowing = "ugxtextures:green_flowing",
liquid_alternative_source = "ugxtextures:green_source",
liquid_viscosity = 1,
groups = {water=3, liquid=3, puts_out_fire=1},
})

minetest.register_node(":testnodes:hed", {
	description = ("head"),
	drawtype = "mesh",
	mesh = "character.b3d",
	tiles = {"character_76.png"},
  visual_scale = 1.0,
	paramtype = "light",
	paramtype2 = "facedir",

	groups = {dig_immediate=3},
})



minetest.register_node(":mobs:desert_stone_with_meatz", {
	description = "meaty Ore",
	tiles = {"default_desert_stone.png^mobs_meat_raw.png"},
	groups = {cracky = 3, not_cuttable=1},
	drop = 'mobs:meat_raw',
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node(":ugx:aero_block", {
	description = "Show this around town to show you love the original UGX REALMS. REMEMBER THE GOOD SERVER. aerozoic, This is a dedication block to you, and your server. WE MISS YOU SO MUCH!",
	tiles = {
		"default_river_water.png^hud_air_fg.png", -- Bottom texture
		"default_river_water.png^hud_hunger_fg.png", -- Top texture
		"default_river_water.png^default_junglegrass.png^testnodes_plantlike_meshoptions.png^hud_heart_fg.png"
	},
	is_ground_content = false,
	walkable = false,
  use_texture_alpha = true,
	light_source = 11,
	groups = {immortal=1, cracky=1, not_in_creative_inventory = 1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node(":ugx:nininik_ice", {
	description = "nininik's Ice. Has a 1 in 60 chance to melt in about 9 minutes",
	tiles = {"default_ice.png^default_glass_detail.png^[colorize:blue:80"},
	is_ground_content = false,
	paramtype = "light",
	groups = {cracky = 1, puts_out_fire = 1, not_cuttable=1},
	sounds = default.node_sound_glass_defaults(),
})

minetest.register_node(":ugx:griefer_soul_block", {
	description = "A Block Of Griefer Souls",
	paramtype2 = "facedir",
	place_param2 = 0,
	tiles = {"bones_front.png^[colorize:red:120", "bones_front.png^[colorize:red:120", "bones_front.png^[colorize:red:120"},
	is_ground_content = false,
	groups = {cracky = 2, stone = 1,dig_immediate=2, not_cuttable=1},
	sounds =default.node_sound_wood_defaults(),
})


minetest.register_node(":ugx:oldermese", {
	description = "0.4.17 mese block",
	light_source = 1,
	tiles = {"medmese.png"},
	is_ground_content = false,
	groups = {cracky = 2, stone = 1,not_cuttable=1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node(":ugx:lastmese", {
	description = "last mese block",
  light_source = 1,
	tiles = {"lastmese.png"},
	is_ground_content = false,
	groups = {cracky = 2, stone = 1,not_cuttable=1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node(":ugx:heart_block", {
	description = "Heart Block",
	paramtype2 = "facedir",
	place_param2 = 0,
	tiles = {"default_stone.png^hud_heart_fg.png"},
	is_ground_content = false,
	groups = {cracky = 2, stone = 1,dig_immediate=2, not_cuttable=1},
	sounds =default.node_sound_wood_defaults(),
})

minetest.register_node(":ugx:skinblock", {
	description = "skin btn Block (param2 rotates)",
	paramtype2 = "facedir",
	place_param2 = 0,
	tiles = {"default_stone.png^altskinbtn.png"},
	is_ground_content = false,
	groups = {cracky = 2, stone = 1,dig_immediate=2, not_cuttable=1},
	sounds =default.node_sound_wood_defaults(),
})
-- Define blue ice node
minetest.register_node(":ugx:blue_ice", {
    description = "Blue Ice",
    tiles = {"default_ice.png^[colorize:#0000FF:111"},
    is_ground_content = false,
    paramtype = "light",
    groups = {cracky = 3, puts_out_fire = 1, slippery = 100},
    sounds = default.node_sound_glass_defaults(),
    walkable = true,
})

-- Register crafting recipe for blue ice
minetest.register_craft({
    output = "ugx:blue_ice",
    recipe = {
        {"xdecor:packed_ice", "xdecor:packed_ice", "xdecor:packed_ice"},
        {"xdecor:packed_ice", "xdecor:packed_ice", "xdecor:packed_ice"},
        {"xdecor:packed_ice", "xdecor:packed_ice", "xdecor:packed_ice"},
    },
})


minetest.register_node(":ugx:blue_packed_ice", {
    description = "Blue Packed Ice",
    tiles = {"xdecor_packed_ice.png^[colorize:#0000FF:111"},
    is_ground_content = false,
    paramtype = "light",
    groups = {cracky = 3, puts_out_fire = 1, slippery = 200},
    sounds = default.node_sound_ice_defaults(),
    walkable = true,
})

-- Register crafting recipe for blue ice
minetest.register_craft({
    output = "ugx:blue_packed_ice",
    recipe = {
        {"ugx:blue_ice", "ugx:blue_ice", "ugx:blue_ice"},
        {"ugx:blue_ice", "ugx:blue_ice", "ugx:blue_ice"},
        {"ugx:blue_ice", "ugx:blue_ice", "ugx:blue_ice"},
    },
})


-- Register crafting recipe for blue ice
minetest.register_craft({
    output = "farming:blueberries 2",
    recipe = {
        {"", "", ""},
        {"", "default:blueberries", ""},
        {"", "default:blueberries", ""},
    },
})

minetest.register_craft({
    output = "ugx:blue_ice 9",
    recipe = {
        {"", "", ""},
        {"", "ugx:blue_packed_ice", ""},
        {"", "", ""},
    },
})

minetest.register_craft({
    output = "xdecor:packed_ice 9",
    recipe = {
        {"", "", ""},
        {"", "ugx:blue_ice", ""},
        {"", "", ""},
    },
})
minetest.register_abm({
	nodenames = {"ugx:nininik_ice"},
	interval = 666,
	chance = 60,
	action = function(pos, node, active_object_count, active_object_count_wider)
			if node.name == "ugx:nininik_ice" then
				minetest.set_node(pos, {name="default:water_source"})
			end
			--end
	end,
})

minetest.register_alias("tnt:tnt_stick", "tnt:tnt")

minetest.register_alias("tnt:tnt", "tnt:tnt_stick")

minetest.register_craftitem(":ugx:griefer_soul", {
	description = "Griefer Soul",
	inventory_image = "default_coal_lump.png^[colorize:red:120",
})

minetest.register_craft({
    output = "ugx:stripes",
    recipe = {
        {"", "default:blueberries", ""},
        {"wool:blue", "specialblocks:stripes", "wool:blue"},
        {"", "default:blueberries", ""},
    },
})

 
minetest.register_node(":ugx:healing_balm", {
	description = ("Climbable Healing Balm").."\n"..
		("You can climb up and down; reduced movement speed and healing properties"),
	walkable = false,
	climbable = true,
	move_resistance = 3,
  damage_per_second = -8,
	drawtype = "glasslike",
	paramtype = "light",
	sunlight_propagates = true,
	tiles = {"balm.png"},
	is_ground_content = false,
	groups = { dig_immediate = 3 },
})


minetest.register_ore({
	ore_type = "scatter",
	ore = "mobs:desert_stone_with_meatz",  -- Changed from "ethereal:etherium_ore" to "mobs:desert_stone_with_meatz"
	wherein = "default:desert_stone",
	clust_scarcity = 15 * 12 * 15,  -- Increased rarity
	clust_num_ores = 1,
	clust_size = 1,
	y_min = 5,
	y_max = 40,
	biomes = {"caves"}
})

minetest.register_craft({
	output = "mobs:meat_raw 9",  -- Output 9 raw meats from 1 raw meat block
	recipe = {
		{"mobs:meatblock_raw"},
	}
})

