local world_path = minetest.get_worldpath()

areas.config = {}

local function setting(tp, name, default)
	local full_name = "areas."..name
	local value
	if tp == "boolean" then
		value = minetest.settings:get_bool(full_name)
	elseif tp == "string" then
		value = minetest.settings:get(full_name)
	elseif tp == "position" then
		value = minetest.setting_get_pos(full_name)
	elseif tp == "number" then
		value = tonumber(minetest.settings:get(full_name))
	else
		error("Invalid setting type!")
	end
	if value == nil then
		value = default
	end
	areas.config[name] = value
end


minetest.register_node("areas:pos1", {
	tiles = {"areas_pos1.png"},
  use_texture_alpha = "clip",
  drawtype = "glasslike",
	groups = {oddly_breakable_by_hand = 2},
})

minetest.register_node("areas:pos2", {
	tiles = {"areas_pos2.png"},
  use_texture_alpha = "clip",
  drawtype = "glasslike",
	groups = {oddly_breakable_by_hand = 2},
})

--------------
-- Settings --
--------------

setting("string", "filename", world_path.."/areas.dat")

-- Allow players with a privilege create their own areas
-- within the maximum size and number.
setting("boolean",  "self_protection", false)
setting("string",   "self_protection_privilege", "debug")
setting("position", "self_protection_max_size",      {x=64,  y=128, z=64})
setting("number",   "self_protection_max_areas",      4)
-- For players with the areas_high_limit privilege.
setting("position", "self_protection_max_size_high", {x=512, y=512, z=512})
setting("number",   "self_protection_max_areas_high", 32)

-- legacy_table (owner_defs) compatibility.  Untested and has known issues.
setting("boolean", "legacy_table", false)

