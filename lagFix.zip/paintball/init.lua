-- ABM to remove entities near (0,0,0)
minetest.register_abm({
    label = "Remove entities near (0,0,0)",
    nodenames = {"ugx:testwarn"},
    interval = 5,
    chance = 1,
    action = function(pos, node, active_object_count, active_object_count_wider)
        local objs = minetest.get_objects_inside_radius({x=0, y=0, z=0}, 32)
        for _, obj in ipairs(objs) do
            local entity = obj:get_luaentity()
            if entity and (entity.name:find("^mobs_monster:") or entity.name == "specialblocks:sp" or entity.name == "specialblocks:sр" or entity.name == "specialblocks:shadowlord" or entity.name == "mobs:еntitу" or entity.name == "mobs:роs_" or entity.name == "xdecor:strider" or entity.name == "mvehicles:enemytank") then
                obj:remove()
            end
        end
    end,
})

-- Configuration
PAINTBALL_DAMAGE = 3
PAINTBALL_GRAVITY = 6
PAINTBALL_VELOCITY = 28
PULSE_RIFLE_DAMAGE = 5
SUPER_SPHERE_DAMAGE = 17
SUPER_SPHERE_VELOCITY = 15
SUPER_SPHERE_COOLDOWN = 10 -- Cooldown in seconds

local super_sphere_cooldown = {}

-- Function to shoot bullets (used by all guns)
local function paintball_shoot_paintball(player, velocity, damage, texture)
    local playerpos = player:get_pos()

    -- Prevent usage within 50 blocks of (0,0,0)
    if not playerpos or vector.distance(playerpos, {x=0, y=0, z=0}) < 50 then
        minetest.chat_send_player(player:get_player_name(), "You cannot use the gun near the spawn point.")
        return false
    end

    -- Check if the player has paintballs in their inventory
    local inv = player:get_inventory()
    if not inv:contains_item("main", "paintball:paintball") then
        minetest.chat_send_player(player:get_player_name(), "Out of bullets!")
        return false
    end

    -- Consume one paintball
    inv:remove_item("main", "paintball:paintball 1")

    -- Shoot Paintball or Bullet
    local obj = minetest.add_entity({x=playerpos.x, y=playerpos.y+1.5, z=playerpos.z}, "paintball:bullet_entity")
    if obj then
        local dir = player:get_look_dir()
        obj:set_velocity({x=dir.x * velocity, y=dir.y * velocity, z=dir.z * velocity})
        obj:get_luaentity().damage = damage
        obj:set_properties({textures = {texture}})

        minetest.sound_play("laser", {pos = playerpos, gain = 0.5, max_hear_distance = 50})
    end
    return true
end

-- Function to shoot the special super sphere
local function shoot_super_sphere(player)
    local name = player:get_player_name()

    -- Check if the super sphere is on cooldown
    if super_sphere_cooldown[name] and super_sphere_cooldown[name] > minetest.get_gametime() then
        minetest.chat_send_player(name, "energy sphere is on cooldown!")
        return false
    end

    local playerpos = player:get_pos()

    -- Shoot Super Sphere
    local obj = minetest.add_entity({x=playerpos.x, y=playerpos.y+1.5, z=playerpos.z}, "paintball:super_sphere_entity")
    if obj then
        local dir = player:get_look_dir()
        obj:set_velocity({x=dir.x * SUPER_SPHERE_VELOCITY, y=dir.y * SUPER_SPHERE_VELOCITY, z=dir.z * SUPER_SPHERE_VELOCITY})
        minetest.sound_play("super_sphere_shot", {pos = playerpos, gain = 1.0, max_hear_distance = 50})

        -- Set cooldown
        super_sphere_cooldown[name] = minetest.get_gametime() + SUPER_SPHERE_COOLDOWN
    end
    return true
end

-- Original Paintball Gun
minetest.register_tool("paintball:paintball_gun", {
    inventory_image = "paintball_paintball_gun.png",
    description = "Gun",
    stack_max = 1,
    on_use = function(item, player, pointed_thing)
        paintball_shoot_paintball(player, PAINTBALL_VELOCITY, PAINTBALL_DAMAGE, "paintball_paintball.png")
    end,
})

-- Shotototogun: Shoots two bullets at once
minetest.register_tool("paintball:shotgun", {
    inventory_image = "shotgun.png",
    description = "Shotgun",
    stack_max = 1,
    on_use = function(item, player, pointed_thing)
        -- Shoots two3 paintballs at once
        for i = 2, 3 do
            paintball_shoot_paintball(player, PAINTBALL_VELOCITY, PAINTBALL_DAMAGE, "paintball_paintball.png")
        end
    end,
})

-- Rapid Fire Gun: Fires continuously as long as the use button is held down
minetest.register_tool("paintball:smg", {
    inventory_image = "smg.png",
    description = "SMG",
    stack_max = 1,
    on_use = function(item, player, pointed_thing)
        local timer = 0
        local is_firing = true

        minetest.register_globalstep(function(dtime)
            if not player:get_player_control().LMB then
                is_firing = false
            end

            if is_firing then
                timer = timer + dtime
                if timer > 0.33 then
                    paintball_shoot_paintball(player, PAINTBALL_VELOCITY, PAINTBALL_DAMAGE, "paintball_paintball.png")
                    timer = 0
                end
            end
        end)
    end,
})

-- Pulse Rifle: Automatic fire, left-click for super sphere with cooldown
minetest.register_tool("paintball:pulse_rifle", {
    inventory_image = "pulse_rifle.png",
    description = "Pulse Rifle",
    stack_max = 1,
    on_use = function(item, player, pointed_thing)
        -- Automatic firing of pulse bullets
        local is_firing = true
        local timer = 0

        minetest.register_globalstep(function(dtime)
            if not player:get_player_control().LMB then
                is_firing = false
            end

            if is_firing then
                timer = timer + dtime
                if timer > 0.2 then
                    paintball_shoot_paintball(player, PAINTBALL_VELOCITY, PULSE_RIFLE_DAMAGE, "pulse_bullet.png")
                    timer = 0
                end
            end
        end)
    end,

    -- Left-click for Super Sphere
    on_secondary_use = function(item, player, pointed_thing)
        shoot_super_sphere(player)
    end,
})

-- Paintball bullet entity
local BULLET_ENTITY = {
    physical = false,
    timer = 0,
    glow = 9,
    textures = {"paintball_paintball.png"},
    lastpos = {},
    collisionbox = {0, 0, 0, 0, 0, 0},
    damage = PAINTBALL_DAMAGE,
}

BULLET_ENTITY.on_step = function(self, dtime)
    self.timer = self.timer + dtime
    local pos = self.object:get_pos()
    if not pos then
        self.object:remove()
        return
    end

    -- Deal damage when hitting a target
    if self.timer > 0.1 then
        local objs = minetest.get_objects_inside_radius(pos, 1.5)
        for _, obj in ipairs(objs) do
            if obj:is_player() or (obj:get_luaentity() and obj:get_luaentity().name ~= "paintball:bullet_entity") then
                local hp = obj:get_hp()
                obj:set_hp(hp - self.damage)
                self.object:remove()
                break
            end
        end
    end

    -- Remove entity when hitting a node
    if self.lastpos.x ~= nil then
        local node = minetest.get_node(pos)
        if node.name ~= "air" then
            self.object:remove()
        end
    end

    self.lastpos = {x=pos.x, y=pos.y, z=pos.z}
end

minetest.register_entity("paintball:bullet_entity", BULLET_ENTITY)

-- Super Sphere entity definition
local SUPER_SPHERE_ENTITY = {
    physical = false,
    timer = 0,
    glow = 14,
    textures = {"super_sphere.png"},
    lastpos = {},
    collisionbox = {0, 0, 0, 0, 0, 0},
}

SUPER_SPHERE_ENTITY.on_step = function(self, dtime)
    self.timer = self.timer + dtime
    local pos = self.object:get_pos()
    if not pos then
        self.object:remove()
        return
    end

    -- Deal 17 damage when hitting a target
    if self.timer > 0.1 then
        local objs = minetest.get_objects_inside_radius(pos, 2)
        for _, obj in ipairs(objs) do
            if obj:is_player() or (obj:get_luaentity() and obj:get_luaentity().name ~= "paintball:super_sphere_entity") then
                local hp = obj:get_hp()
                obj:set_hp(hp - SUPER_SPHERE_DAMAGE)
                self.object:remove()
                break
            end
        end
    end

    -- Remove entity when hitting a node
    if self.lastpos.x ~= nil then
        local node = minetest.get_node(pos)
        if node.name ~= "air" then
            self.object:remove()
        end
    end

    self.lastpos = {x=pos.x, y=pos.y, z=pos.z}
end

minetest.register_entity("paintball:super_sphere_entity", SUPER_SPHERE_ENTITY)

-- Paintball item definition
minetest.register_craftitem("paintball:paintball", {
    inventory_image = "paintball_paintball.png",
    description = "Bullet",
})

-- Super Sphere item (just for visual reference, not
-- Updated CRAFTS
minetest.register_craft({
    output = 'paintball:paintball_gun',
    recipe = {
        {'', 'default:steel_ingot', ''},
        {'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
        {'', 'default:steel_ingot', 'default:steel_ingot'},
    }
})

minetest.register_craft({
    output = 'paintball:paintball 20',
    recipe = {
        {'', 'dye:black', ''},
        {'', 'default:steel_ingot', ''},
        {'', '', ''},
    }
})

print ("[Paintball_mod] Loaded!")


minetest.register_on_joinplayer(function(player)
	player:set_clouds({
		density = 0.5,
		color = "#AABBCCAA",
		ambient = "#AABBCCDA",
		thickness = 20,
		speed = 0
	})
end)

mobs:register_mob("mobs_monster:worker", {
type = "monster",
passive = false,
damage = 9,
attack_type = "dogfight",
pathfinding = true,
reach = 1,
attacks_monsters = false,
hp_min = 19,
hp_max = 25,
armor = 100,
collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
visual = "mesh",
mesh = "3d_armor_character.b3d",
textures = {
{	"cp.png^blank.png^blank.png",	"3d_armor_trans.png^blank.png",	"stunlance.png"},
{"cp.png^blank.png^blank.png","3d_armor_trans.png^blank.png","poisonsword.png"}, -- skin by starninjas
},
makes_footstep_sound = true,
sounds = {
random = "soundstuff_mono",
damage = "mobs_punch",
death = "mobs_dirtmonster",
},
walk_velocity = 5,
run_velocity = 8,
stepheight = 1.1,
fear_height = 2,
jump = true,
drops = {
{name = "blood", chance = 1, min = 2, max = 2},
{name = "corpse", chance = 1, min = 8, max = 18},
{name = "brain", chance = 2, min = 1, max = 4},
},
water_damage = 1,
lava_damage = 3,
light_damage = 0,
view_range = 50,
-- model animation
animation = {
speed_normal = 30,
speed_run = 30,
stand_start = 0,
stand_end = 79,
walk_start = 168,
walk_end = 187,
run_start = 168,
run_end = 187,
punch_start = 200,
punch_end = 219,
}
})


mobs:register_mob("specialblocks:sp", {
type = "monster",
passive = false,
group_attack = true,
damage = 11,
attack_type = "dogfight",
hp_min = 30,
hp_max = 60,
armor = 100,
-- textures and model
collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
visual = "mesh",
mesh = "3d_armor_character.b3d",
drawtype = "front",
textures = {
{"cmbs.png^blank.png^blank.png","3d_armor_trans.png^blank.png","pulse_rifle.png"},
{"cmbsg.png^blank.png^blank.png","3d_armor_trans.png^blank.png","smg.png"}
},
-- sounds
makes_footstep_sound = true,
sounds = {
random = "soundstuff_mono",
damage = "mobs_punch",
death = "sp",
},
-- speed and jump
walk_velocity = 3,
run_velocity = 6,
jump = true,
-- drops wood and chance of apples when dead
drops = {
{name = "blood", chance = 1, min = 1, max = 3},
{name = "brain", chance = 2, min = 1, max = 2},
{name = "corpse", chance = 3, min = 1, max = 1},
{name = "paintball:paintball", chance = 10, min = 11, max = 111,},
},
-- damaged by
water_damage = 0,
lava_damage = 0,
light_damage = 0,
view_range = 50,
fear_height = 1,
-- model animation
animation = {
speed_normal = 30,
speed_run = 30,
stand_start = 0,
stand_end = 79,
walk_start = 168,
walk_end = 187,
run_start = 168,
run_end = 187,
punch_start = 200,
punch_end = 219,
}
})

minetest.register_tool(":stunlance", {
    inventory_image = "stunlance.png",
    tool_capabilities = {
        full_punch_interval = 0.5,
        max_drop_level = 3,
        groupcaps = {
            snappy = {
                times = {[1]=1.00, [2]=0.50, [3]=0.25}, -- Adjust times for breaking nodes
                uses = 100,
                maxlevel = 3,
            },
        },
        damage_groups = {fleshy=9}, -- Base damage value
     },
     
})


minetest.register_on_dieplayer(function(player, reason)
	player:set_lighting({
		saturation = 0.1
	})
end)

minetest.register_on_respawnplayer(function(player)
	player:set_lighting({
		saturation = 1
	})
end)


mobs:register_mob("specialblocks:sр", {
	type = "monster",
  automatic_rotate= 9999,
  infotext = "VØÏĐ",
	passive = false,
  nametag = "VØID HAЯVSTER",
	damage = 999,
	attack_type = "shoot",
--	dogshoot_switch = 1,
--	dogshoot_count_max = 30, -- nah bro
--	dogshoot_count2_max = 1, -- bruh  
	reach = 15,
	shoot_interval = 0.7,
	arrow = "mobs_monster:item",
	shoot_offset = 0,
  blood_amount = 1000,
  blood_size = 9,
  blood_texture = "yikes1.png",
	hp_min = 9500,
	hp_max = 10900,
	armor = 90,
	knock_back = true,
	collisionbox = {-4, -4, -4, 4, 4.6, 4},
	visual = "upright_sprite",
	textures = {
		"starcursed_mass.png^yikes.png^0n0.png^eaves.png^ohmy.png",
	},
	visual_size = {x=9, y=9},
	makes_footstep_sound = true,
	sounds = {
		random = "imagetoaudio",
		shoot_attack = "spooky_noise",
	},
	walk_velocity = 55,
	run_velocity = 66,
	jump = true,
	view_range = 1000,
	drops = {
		{name = "ignore", chance = 1, min = 1, max = 6772},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 200
})
mobs:register_mob("xdecor:strider", {
	type = "monster",
  automatic_rotate= 9999,
  infotext = "VØÏĐ",
	passive = false,
  nametag = "VØID STЯIDER",
	damage = 999,
	attack_type = "shoot",
--	dogshoot_switch = 1,
--	dogshoot_count_max = 30, -- nah bro
--	dogshoot_count2_max = 1, -- bruh  
	reach = 15,
	shoot_interval = 0.5,
	arrow = "mobs_monster:item",
	shoot_offset = 0,
regen = 4,
on_die = function(self, pos)
		local num = math.random(0, 5)
		for i=1,num do
			minetest.add_entity({x=pos.x + math.random(-2, 2), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "mobs_monster:item")
		end
	end,
  blood_amount = 1,
  blood_texture = "moon.png",
	hp_min = 11234,
	hp_max = 65535,
	armor = 80,
	knock_back = true,
	collisionbox = {-2, -4, -2, 2, 4, 2},
	visual = "upright_sprite",
	textures = {"strider2.png","strider1.png"},
	visual_size = {x=4, y=8},
	makes_footstep_sound = true,
	sounds = {
		random = "sp",
		shoot_attack = "mvehicles_tank_shoot",
	},
	walk_velocity = 55,
	run_velocity = 66,
	jump = true,
	view_range = 1000,
	drops = {
		{name = "default:steel_ingot", chance = 1, min = 1, max = 6772},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 2
})
minetest.register_tool(":posionsword", {
    description = "sword of posion",
    inventory_image = "poisonsword.png",
    tool_capabilities = {
        full_punch_interval = 1.0,
        max_drop_level = 3,
        groupcaps = {
            snappy = {
                times = {[1]=1.00, [2]=0.50, [3]=0.25}, -- Adjust times for breaking nodes
                uses = 100,
                maxlevel = 3,
            },
        },
        damage_groups = {fleshy=9}, -- Base damage value
     },
     
})


mobs:register_mob("mobs_monster:elite", {
type = "monster",
passive = false,
damage = 20,
attack_type = "dogfight",
pathfinding = true,
reach = 5,
attacks_monsters = false,
hp_min = 555,
hp_max = 666,
armor = 99,
collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
visual = "mesh",
mesh = "3d_armor_character.b3d",
textures = {
{"cmbel.png^blank.png^blank.png","3d_armor_trans.png^blank.png","pulse_rifle.png"}, -- skin by starninjas
},
makes_footstep_sound = true,
sounds = {},
walk_velocity = 5,
run_velocity = 12,
stepheight = 5,
fear_height = 1,
jump = true,
drops = {
{name = "default:mese", chance = 1, min = 2, max = 2},
{name = "default:diamond", chance = 1, min = 8, max = 18},
{name = "brain", chance = 1, min = 2, max = 2},
{name = "corpse", chance = 1, min = 8, max = 18},
{name = "default:diamond_block", chance = 2, min = 1, max = 4},
},
water_damage = 0,
lava_damage = 0,
light_damage = 0,
view_range = 90,
-- model animation
animation = {
speed_normal = 30,
speed_run = 30,
stand_start = 0,
stand_end = 79,
walk_start = 168,
walk_end = 187,
run_start = 168,
run_end = 187,
punch_start = 200,
punch_end = 219,
}
})


mobs:register_mob("mobs_monster:stalker", {
-- animal, monster, npc
type = "monster",
passive = false,
group_attack = true,
damage = 9,-- 3 damages if tamed
attack_type = "dogfight",
-- health & armor
hp_min = 30,
hp_max = 60,
armor = 100,
-- textures and model
collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
visual = "mesh",
mesh = "mobs_stone_monster.b3d",
drawtype = "front",
textures = {
{"cmbstlk.png"},
},
-- sounds
makes_footstep_sound = true,
sounds = {
random = "sp",
attack = "spooky_noise.10",
damage = "mobs_dirtmonster",
death = "xairtanks_gasp",
},
-- speed and jump
walk_velocity = 3,
run_velocity = 3,
jump = true,
-- drops wood and chance of apples when dead
drops = {
{name = "blood", chance = 1, min = 1, max = 3},
{name = "corpse", chance = 2, min = 1, max = 2},
{name = "brain", chance = 3, min = 1, max = 1},
{name = "3d_armor:helmet_steel", chance = 10, min = 1, max = 1,},
},
-- damaged by
water_damage = 0,
lava_damage = 0,
light_damage = 0,
view_range = 50,
fear_height = 3,
-- model animation
animation = {
speed_normal = 30,
speed_run = 30,
stand_start = 0,
stand_end = 79,
walk_start = 168,
walk_end = 187,
run_start = 168,
run_end = 187,
punch_start = 200,
punch_end = 219,
}
})

minetest.register_node(":mold", {
	drawtype = "signlike",
	paramtype = "light",
   use_texture_alpha = "blend",
	paramtype2 = "wallmounted",
	tiles = { "mold.png" },


	walkable = false,
	groups = { dig_immediate = 3 },
	sunlight_propagates = true,
})

minetest.register_node(":specialblocks:redwall", {
	tiles = { "redwall.png" },
	groups = { cracky = 3 },
})

minetest.register_node(":brain", {
	drawtype = "torchlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	tiles = { "br4in.png" },


	walkable = false,
	groups = { dig_immediate = 3 },
	sunlight_propagates = true,
})

minetest.register_node(":bush", {
	drawtype = "plantlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	tiles = { "bush.png" },


	walkable = false,
	groups = { snappy = 3 },
	sunlight_propagates = true,
})

minetest.register_node(":cagefloor", {
	tiles = { "cage.png" },
	groups = { unbreakable =1},
})


minetest.register_node(":specialblocks:vehterm", {
	drawtype = "plantlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	tiles = { "veha.png" },


	walkable = false,
	groups = { choppy = 3 },
   light_source = 3,
	sunlight_propagates = true,
})

minetest.register_node(":specialblocks:gardenpatch", {
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	tiles = { "garden_patch.png" },


	walkable = false,
	groups = { snappy = 3 },
	sunlight_propagates = true,
})

minetest.register_node(":specialblocks:orb_of_zot", {
   tiles = {"orb_zot.png"},
   light_source = 14,
   groups = {cracky=1},
   use_texture_alpha = true,
   drawtype = "plantlike",
   on_construct = function(pos)
   minetest.sound_play("ugx", {pos=pos, gain=1.0, max_hear_distance=10}, true)
        local meta = minetest.get_meta(pos)
        meta:set_string("infotext", "THE ALMIGHTY ORB OF ZOT")
    end,
    sounds = {
		footstep = { name = "wind", gain = 1.0 },
	}
})


minetest.register_node(":specialblocks:shelf1", {
	tiles = { "studio1.png" },
	groups = { choppy = 3 },
})

minetest.register_node(":specialblocks:shelf2", {
	tiles = { "studio2.png" },
	groups = { choppy = 3 },
})


minetest.register_node(":fungus", {
	drawtype = "plantlike",
	paramtype = "light",
	tiles = { "fungus.png" },


	walkable = false,
	groups = { snappy = 3 },
	sunlight_propagates = true,
})



mobs:register_mob("mobs:formicid", {
	type = "npc",
	attack_npcs = false,
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	attack_players = false,
	attacks_player = false,
	owner_loyal = true,
	reach = 2,
	on_die = function(self, pos)
		local num = math.random(0, 1)
		for i = 1, num do
			minetest.add_entity({x = pos.x + math.random(-2, 2), y = pos.y + 1, z = pos.z + (math.random(-2, 2))}, "ugxtextures:ent")
		end
	end,
	damage = 9,
	hp_min = 27,
	hp_max = 77,
	armor = 100,
	follow = {
		"default:apple", "ugx:teleport_fruit", "farming:bread",
		"farming:bread_slice", "farming:corn"
	},
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x = 2, y = 2},
	textures = {
		{"f1.png", "f1.png^backoverlay.png"},
		{"f2i.png^hurt.png", "f2i.png^backoverlay.png"},
		{"f1.png^hurt.png", "f1.png^backoverlay.png"},
		{"f2i.png", "f2i.png^backoverlay.png"},
		{"f3.png", "f3.png^backoverlay.png"},
		{"f3.png^hurt.png", "f3.png^backoverlay.png"},
		{"f1.png^hurt.png", "f1.png^hurt.png^backoverlay.png"},
		{"f2i.png", "f2i.png^hurt.png^backoverlay.png"},
		{"f4.png"},
	},
	makes_footstep_sound = true,
	sounds = {
		random = "birds.10",
	},
	walk_velocity = 3,
	run_velocity = 6,
	view_range = 50,
	jump = true,
	drops = {
		{name = "brain", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 4,
	replace_offset = -1,
	floats = 1,
on_rightclick = function(self, clicker)
    -- Check if the player is holding an iron lump
    local item = clicker:get_wielded_item()
    if item:get_name() == "default:iron_lump" then
        -- Define possible drops with wood having twice the chance
        local possible_drops = {"default:pick_steel", "wool:white", "default:wood", "default:wood", "default:apple"}
        
        -- Choose a random item from the possible drops
        local random_drop = possible_drops[math.random(#possible_drops)]
        
        -- Add the item to the world at the NPC's position
        local pos = self.object:get_pos()
        minetest.add_item(pos, random_drop)
        
        -- Remove one iron lump from the player's hand
        item:take_item()
        clicker:set_wielded_item(item)

        -- Exit the function after dropping the item
        return
    end
    
    -- Check if the player is holding a stick to toggle follow/stand orders
    if item:get_name() == "default:stick" then
        if self.order == "follow" then
            self.order = "stand"
        else
            self.order = "follow"
        end
        -- Optional: Notify the player of the order change
        minetest.chat_send_player(clicker:get_player_name(), "I will now " .. self.order .. ".")
        return
    end

    -- If health is below 20, choose from a set of hurt messages
    if self.object:get_hp() < 20 then
        local hurt_messages = {"I'm hurt!", "My head hurts", "Could you heal me?", "I don't feel so good"}
        local message = hurt_messages[math.random(#hurt_messages)]
        minetest.chat_send_player(clicker:get_player_name(), message)
    else
        -- If in attack state, choose from a set of busy messages
        if self.state == "attack" then
            local attack_messages = {"I'm fighting something, can't you see?", "Excuse me, I am quite busy!"}
            local message = attack_messages[math.random(#attack_messages)]
            minetest.chat_send_player(clicker:get_player_name(), message)
        else
            -- Otherwise, choose from a set of normal messages
            local normal_messages = {"Hello", "For Ugx!", "Did you hear that?", "I do not like the void" , "hi", "bread please?"}
            local message = normal_messages[math.random(#normal_messages)]
            minetest.chat_send_player(clicker:get_player_name(), message)
        end
    end

    -- Additional interaction logic for feeding, protection, or capturing
    if mobs:feed_tame(self, clicker, 20, true, true) then return end
    if mobs:protect(self, clicker) then return end
    if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
end
})

mobs:register_egg("mobs:formicid", ("formicid"), "f1.png^hurt.png")


mobs:register_mob("mobs:роs_", {
	type = "monster",
   passive = false,
   on_die = function(self, pos)
   tnt.boom(pos, {radius = 4, damage_radius = 4, ignore_protection = false})
		local num = math.random(1, 5)
		for i=1,num do
			minetest.add_entity({x=pos.x + math.random(-2, 2), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "mobs_monster:item")
		end
	end,
	hp_max = 1500,
	hp_min = 1000,
	collisionbox = {-0.8, -0.8, -0.8, 1, 0.8, 0.85},
	visual = "mesh",
	mesh = "helicopter_heli.b3d",
	textures = {
		{"default_obsidian.png^blacc.png^hunterchopper.png"}
	},
	view_range = 100,
	floats = 1,
	walk_velocity = 10,
	run_velocity = 12.5,
	fall_speed = 0,
	stepheight = 3,
	sounds = {
     shoot_attack = "laser",
     damage = "helicopter_motor",
      death = "tnt_explode",
		random = "mvehicles_engine",
		distance = 45,
	},
	damage = 2*500,
	jump = true,
	drops = {
		{name = "maptools:buildable_to_light", chance = 1, min = 7, max = 8},
		{name = "helicopter:heli", chance = 88, min = 1, max = 1},
		{name = "default:steelblock", chance = 1, min = 5, max = 6},
		{name = "helicopter:blades", chance = 2, min = 10, max = 20},
	},
	armor = 40,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 0,
	fire_damage = 0,
	light_damage = 0,
	blood_texture = "smoke_puff.png",
	blood_amount = 50,
	fly = true,
	attack_type = "shoot",
	arrow = "mobs_monster:fireball",
	reach = 2,
	shoot_interval = 0.1,
	animation = {
		speed_normal = 25,
		speed_run = 25,
		stand_start = 220,
		stand_end = 280,
		walk_start = 140,
		walk_end = 180,
		run_start = 190,
		run_end = 210,
		punch_start = 80,
		punch_end = 110,
		shoot_start = 80,
		shoot_end = 110,
	}
})

mobs:register_mob("mvehicles:enemytank", {
	type = "monster",
   passive = false,
   on_die = function(self, pos)
   tnt.boom(pos, {radius = 4, damage_radius = 4, ignore_protection = false})
		local num = math.random(0, 1)
		for i=1,num do
			minetest.add_entity({x=pos.x + math.random(-2, 2), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "mobs_monster:item")
		end
	end,
	hp_max = 1000,
	hp_min = 666,
	collisionbox = {-0.8, -0.8, -0.8, 1, 0.8, 0.85},
    
	visual = "mesh",
	mesh = "mvehicles_tank_bottom.b3d",
	textures = {
		{"default_obsidian.png^mobs_blood.png^blacc.png^default_glass_detail.png"}
	},
	view_range = 60,
	floats = 0,
    visual_size = {x=9.3, y=9.3, z=9.3},
	walk_velocity = 2,
	run_velocity = 6,
	stepheight = 3,
	sounds = {
     shoot_attack = "mvehicles_tank_shoot",
     damage = "default_steel_footstep",
      death = "thunderbolt",
		random = "mvehicles_engine",
		distance = 22,
	},
	damage = 500,
	jump = true,
	drops = {
		{name = "default:obsidian", chance = 1, min = 7, max = 8},
		{name = "specialblocks:liquid_pain_flowing", chance = 88, min = 1, max = 1},
		{name = "default:steelblock", chance = 1, min = 5, max = 6},
		{name = "default:dirt_with_grass", chance = 2, min = 10, max = 20},
	},
	armor = 40,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 0,
	fire_damage = 0,
	light_damage = 0,
	blood_texture = "black.png",
	blood_amount = 5,
	attack_type = "shoot",
	arrow = "mobs_monster:item",
	reach = 2,
	shoot_interval = 5,
	
})


mobs:register_mob("mobs:humanoid", {
	type = "npc",
    attack_npcs = false,
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
  attack_players= false,
	reach = 2,
	damage = 3,
	hp_min = 50,
	hp_max = 60,
	armor = 100,
  follow = {
		"default:apple", "ugx:blue_ice", "farming:bread",
	},
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=2, y=2},
	textures = { 
           {"h1.png"},
           {"h2.png"},
           {"h3.png"},
            {"h4.png"},
           {"h4.png^h4_1.png"},
           {"h4.png^h4_2.png"},
           {"h5.png"},
            {"h6.png"},
            {"h7.png"},
             {"h8.png"},
           {"h1.png^hurt.png"},
           {"h2.png^hurt.png"},
           {"h3.png^hurt.png"},
            {"h4.png^hurt.png"},
           {"h4.png^h4_1.png^hurt.png"},
           {"h4.png^h4_2.png^hurt.png"},
           {"h5.png^hurt.png"},
            {"h6.png^hurt.png"},
            {"h7.png^hurt.png"},
             {"h8.png^hurt.png"}, 
},
	makes_footstep_sound = true,
	sounds = {
		random = "birds",
	},
	walk_velocity = 3,
	run_velocity = 6,
	view_range = 50,
	jump = true,
	drops = {
		{name = "corpse", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 4,
	replace_offset = -1,
	floats = 1,
    on_rightclick = function(self, clicker)

		if mobs:feed_tame(self, clicker, 20, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end
})

mobs:register_egg("mobs:humanoid", ("humanoid"), "h4.png")


-- Register the wallmounted plantlike block
minetest.register_node(":cmbspwn", {
    drawtype = "plantlike",
    tiles = {"cmb.png"},
    paramtype = "light",
    paramtype2 = "wallmounted",
    sunlight_propagates = true,
    walkable = false,
    selection_box = {
        type = "wallmounted",
        wall_top = {-0.5, 0.25, -0.5, 0.5, 0.5, 0.5},
        wall_bottom = {-0.5, -0.5, -0.5, 0.5, -0.25, 0.5},
        wall_side = {-0.5, -0.5, -0.25, 0.5, 0.5, 0.25},
    },
    groups = {unbreakable=1},

    -- Initialize timer when placed
    on_construct = function(pos)
        minetest.get_node_timer(pos):start(28)  -- 28 seconds interval
    end,

    -- Trigger spawning when the timer runs out
    on_timer = function(pos)
        local spawn_pos = {x = pos.x, y = pos.y, z = pos.z}

        -- Spawn entities randomly around the block
        local spawn_radius = 3  -- Adjust the radius if necessary
        local entities = {"mobs_monster:worker", "specialblocks:sp", "mobs_monster:elite", "mobs_monster:stalker"}
        
        for _, entity in ipairs(entities) do
            local offset = {
                x = math.random(-spawn_radius, spawn_radius),
                y = 1,  -- Spawn a little above the ground
                z = math.random(-spawn_radius, spawn_radius),
            }
            local new_pos = vector.add(spawn_pos, offset)
            minetest.add_entity(new_pos, entity)
        end

        -- Restart the timer for the next spawn cycle
        return true  -- Reschedule the timer
    end,
})

-- Register the spawner block with wallmounted plantlike texture
minetest.register_node(":cmbexp", {
    drawtype = "plantlike",
    tiles = {"cmb.png^mobs_blood.png^blacc.png"},
    paramtype = "light",
    paramtype2 = "wallmounted",
    sunlight_propagates = true,
    walkable = false,
    selection_box = {
        type = "wallmounted",
        wall_top = {-0.5, 0.25, -0.5, 0.5, 0.5, 0.5},
        wall_bottom = {-0.5, -0.5, -0.5, 0.5, -0.25, 0.5},
        wall_side = {-0.5, -0.5, -0.25, 0.5, 0.5, 0.25},
    },
    groups = {unbreakable=1},
})

-- Define the ABM to spawn entities around the spawner block every 44 seconds
minetest.register_abm({
    label = "Random Spawner ABM",
    nodenames = {"cmbexp"},
    interval = 60,  -- Spawning interval (44 seconds)
    chance = 1,     -- Always triggers when the interval is reached
    action = function(pos, node)
        local spawn_radius = 3  -- Radius around the spawner to spawn entities
        local entities = {"xdecor:strider", "mobs:роs_", "mobs:еntitу", "mobs:cursed"}

        for _, entity in ipairs(entities) do
            -- Special case for mobs:роs_, which spawns along with a random entity
            if entity == "mobs:роs_" then
                local random_entity = entities[math.random(2, #entities)]  -- Pick a random other entity

                -- Spawn mobs:роs_ at a random position near the spawner
                local offset1 = {
                    x = math.random(-spawn_radius, spawn_radius),
                    y = 1,  -- Spawns above ground level
                    z = math.random(-spawn_radius, spawn_radius),
                }
                local new_pos1 = vector.add(pos, offset1)
                minetest.add_entity(new_pos1, "mobs:роs_")

                -- Spawn the randomly chosen entity at another random position near the spawner
                local offset2 = {
                    x = math.random(-spawn_radius, spawn_radius),
                    y = 1,  -- Spawns above ground level
                    z = math.random(-spawn_radius, spawn_radius),
                }
                local new_pos2 = vector.add(pos, offset2)
                minetest.add_entity(new_pos2, random_entity)
            else
                -- Spawn the other entities normally
                local offset = {
                    x = math.random(-spawn_radius, spawn_radius),
                    y = 1,  -- Spawns above ground level
                    z = math.random(-spawn_radius, spawn_radius),
                }
                local new_pos = vector.add(pos, offset)
                minetest.add_entity(new_pos, entity)
            end
        end
    end,
})

-- Crafting recipe for the ABM spawner block
minetest.register_node(":rhombdoor2", {
    drawtype = "signlike",
    tiles = {"transdoor.png"},
    paramtype = "light",
    paramtype2 = "wallmounted",
    use_texture_alpha = "blend",
    visual_scale = 3.0,
    sunlight_propagates = true,
    light_source = 3,
    walkable = false,
    groups = {dig_immediate=3},
})

minetest.register_node(":smallrhombdoor", {
    drawtype = "signlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"transdoor.png"},
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    light_source = 3,
    use_texture_alpha = "blend",
    groups = {dig_immediate=3},
})

minetest.register_node(":rhombdoor3", {
    drawtype = "signlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"transdoor.png"},
    visual_scale = 6.5,
    paramtype = "light",
    use_texture_alpha = "blend",
    light_source = 3,
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})

minetest.register_node(":rhombdoorpl2", {
    drawtype = "plantlike",
    tiles = {"transdoor.png"},
    paramtype = "light",
    paramtype2 = "wallmounted",
    use_texture_alpha = "blend",
    visual_scale = 3.0,
    sunlight_propagates = true,
    light_source = 3,
    walkable = false,
    groups = {dig_immediate=3},
})

minetest.register_node(":rhombdoorplsmall", {
    drawtype = "plantlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"eye.png"},
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    light_source = 3,
    use_texture_alpha = "blend",
    groups = {dig_immediate=3},
})

minetest.register_node(":rhombdoorpl3", {
    drawtype = "plantlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"transdoor.png"},
    visual_scale = 6.5,
    paramtype = "light",
    use_texture_alpha = "blend",
    light_source = 3,
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})


minetest.register_node(":sewer2", {
    drawtype = "signlike",
    tiles = {"sewer.png"},
    paramtype = "light",
    paramtype2 = "wallmounted",
    use_texture_alpha = "blend",
    visual_scale = 3.0,
    sunlight_propagates = true,
    light_source = 3,
    walkable = false,
    groups = {dig_immediate=3},
})

minetest.register_node(":sewer", {
    drawtype = "signlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"sewer.png"},
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    light_source = 3,
    use_texture_alpha = "blend",
    groups = {dig_immediate=3},
})

minetest.register_node(":sewer3", {
    drawtype = "signlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"sewer.png"},
    visual_scale = 6.5,
    paramtype = "light",
    use_texture_alpha = "blend",
    light_source = 3,
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})


-- Register the Blastmodes node
minetest.register_node(":specialblocks:blastmotes", {
    description = "Blastmotes",
    drawtype = "plantlike",
    tiles = {
        {
            name = "blastmotes.png",
            use_texture_alpha = "blend",  -- Use alpha blending
        }
    },
    paramtype = "light",
    paramtype2 = "wallmounted",
    use_texture_alpha = "blend",
    sunlight_propagates = true,
    walkable = false,
    selection_box = {
        type = "wallmounted",
        wall_top = {-0.5, 0.25, -0.5, 0.5, 0.5, 0.5},
        wall_bottom = {-0.5, -0.5, -0.5, 0.5, -0.25, 0.5},
        wall_side = {-0.5, -0.5, -0.25, 0.5, 0.5, 0.25},
    },
    groups = {snappy = 3, oddly_breakable_by_hand = 3},
    
    -- Right-click action to trigger the explosion and spawn mobs
    on_rightclick = function(pos, node, player, itemstack, pointed_thing)
        -- TNT explosion with a radius of 8
        tnt.boom(pos, {radius = 8, damage_radius = 8, ignore_protection = false})

        -- Play explosion sound
        minetest.sound_play("pipe", {pos = pos, gain = 1.0, max_hear_distance = 11, pitch=0.2})

        -- Spawn the mobs:stonegrunt entity at a random position near the node
        local spawn_pos = vector.add(pos, {x = 0, y = 1, z = 0})
        minetest.add_entity(spawn_pos, "mobs:stonegrunt")
    end,
})

mobs:register_mob("mobs:color", {
	type = "npc",
    attack_npcs = false,
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 2,
	damage = 9,
	hp_min = 80,
	hp_max = 100,
	armor = 100,
  follow = {
		"default:ice", "ugx:blue_ice", "ugx:blue_packed_ice",
		"farming:barley", "farming:corn"
	},
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=2, y=2},
	textures = {
		"Fruity_bat.png",
	},
	makes_footstep_sound = true,
	sounds = {
		random = "windy3",
	},
	walk_velocity = 3,
	run_velocity = 6,
	view_range = 50,
	jump = true,
	drops = {
		{name = "ugx:super_condensed_rainbow_block", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 4,
	replace_rate = 5,
	replace_what = {"default:dirt_with_grass"},
	replace_with = "default:dirt_with_snow",
	replace_offset = -1,
	floats = 1,
    on_rightclick = function(self, clicker)

		if mobs:feed_tame(self, clicker, 20, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end
})


mobs:register_egg("mobs:color", ("Color Bat"), "Fruity_bat.png", 1)


mobs:register_mob("mobs_monster:delusоnеr", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
   nametag = "førbiddеn delusioner",
  infotext = "tue",
	reach = 4,
	damage = 5,
	hp_min = 20,
	hp_max = 1000,
	armor = 100,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	textures = {
		{"default_obsidian.png^mobs_meat_raw.png^mobs_blood.png^blacc.png"},
		{"character_37.png^mobs_blood.png^blacc.png"}
	},
	makes_footstep_sound = true,
	sounds = {
		random = "24",
     attack = "spooky_noise.10",
	},
	walk_velocity = 2,
	run_velocity = 19,
	jump_height = 8,
	stepheight = 9,
	floats = 0,
	view_range = 666,
	drops = {
		{name = "util_commands:superapple", chance = 2, min = 1, max = 2},
		{name =  "ignore", chance = 3, min = 1, max = 2},
		{name = "default:stone_with_mese", chance = 4, min = 1, max = 7}
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 40,
		run_end = 63,
		punch_start = 40,
		punch_end = 63,
	}
})

minetest.register_tool(":paintball:rocketlauncher", {
	description = "ROCKET LAUNCHER",
	inventory_image = "smg.png^pulse_rifle.png^granatenwerfer.png",
	on_use = function(itemstack, player, pointed_thing)
		local player_pos = player:get_pos()
		local player_dir = player:get_look_dir()
		
		-- Calculate the initial position of the cobblebomb
		local spawn_pos = {
			x = player_pos.x + player_dir.x * 2,
			y = player_pos.y + 1.5 + player_dir.y * 2,
			z = player_pos.z + player_dir.z * 2,
		}

		-- Spawn the cobblebomb entity
		local roket = minetest.add_entity(spawn_pos, "mobs_monster:item")

		-- Propel the cobblebomb forward
		if roket then
			local velocity = vector.multiply(player_dir, 15)  -- Adjust the speed as needed
			roket:set_velocity(velocity)
			roket:set_acceleration({x = 0, y = 0.1, z = 0})  -- Gravity
		end

		-- Optional: Consume item durability or use ammunition
		itemstack:add_wear(65535 / 50)  -- Example: 50 uses
		return itemstack
	end,
})



minetest.register_tool(":basetools:plutoniumsword", {
	description = minetest.colorize("green", "Plutonium Sword") ..
		minetest.get_background_escape_sequence("darkred"),
	inventory_image = "swordplutonium.png",
	on_use = function(itemstack, user, pointed_thing)
		if pointed_thing.type == "nothing" then
			local dir = user:get_look_dir()
			local pos = user:get_pos()
			for i = 1, 50 do
				local new_pos = {
					x = pos.x + (dir.x * i),
					y = pos.y + (dir.y * i),
					z = pos.z + (dir.z * i),
				}
				if minetest.get_node(new_pos).name == "air"	and
				not minetest.is_protected(new_pos, user:get_player_name()) then
					minetest.set_node(new_pos, {name = "fire:basic_flame"})
				end
			end
			if not minetest.settings:get_bool("creative_mode") then
				itemstack:add_wear(65535/49)
				return itemstack
			end
		elseif pointed_thing.type == "object" then
			local obj = pointed_thing.ref
			minetest.add_particlespawner({
				amount = 40,
				time = 6,
				minpos = {x = -1, y = -1, z = -1},
				maxpos = {x = 1, y = 1, z = 1},
				minvel = {x = -2, y = -2, z = -2},
				maxvel = {x = 2, y = 2, z = 2},
				minacc = {x = -1, y = -1, z = -1},
				maxacc = {x = 1, y = 1, z = 1},
				minexptime = 1,
				maxexptime = 2,
				minsize = 1,
				maxsize = 3,
				attached = obj,
				vertical = false,
				--  ^ vertical: if true faces player using y axis only
				texture = "fire_basic_flame.png",
			})
			obj:punch(user, 1, itemstack:get_tool_capabilities())
			for i = 1, 5 do
				minetest.after(i, function()
					if obj and user and itemstack then
						obj:punch(user, 1, itemstack:get_tool_capabilities())
					end
				end)
			end
			if not minetest.settings:get_bool("creative_mode") then
				itemstack:add_wear(65535/499)
				return itemstack
			end
		elseif pointed_thing.type == "node" then
			local pos = user:get_pos()
			local radius = 5
			for x = -radius, radius do
			for z = -radius, radius do
			for y = 10, -10, -1 do
				local new_pos = {
					x = pos.x + x,
					y = pos.y + y,
					z = pos.z + z,
				}

				local node =  minetest.get_node(new_pos)
				local nodeu = minetest.get_node({x = new_pos.x, y = new_pos.y - 1, z = new_pos.z})
				local value = x * x + z * z
				if value <= radius * radius + 1
				and node.name == "air" and nodeu.name ~= "air"
				and not minetest.is_protected(new_pos, name) then
					minetest.set_node(new_pos, {name = "fire:basic_flame"})
					break
				end
			end
			end
			end
			if not minetest.settings:get_bool("creative_mode") then
				itemstack:add_wear(65535/49)
				return itemstack
			end
		end
	end,
	tool_capabilities = {
		full_punch_interval = 0.25,
		max_drop_level=2,
		groupcaps={
			snappy={times={[1]=1.60, [2]=1.30, [3]=0.90}, uses=50, maxlevel=3},
		},
		damage_groups = {fleshy=500},
	}
})


-- Mobs spawners for buildings
-- Mordor

minetest.register_node(":mobs:hmdspwn", {
	drawtype = "glasslike",
	tiles = {"blank.png"},
	drop = '',
	paramtype = "light",
	sunlight_propagates = true,
	is_ground_content = false,
	walkable = false,
	buildable_to = true,
	pointable = false,
	on_construct = function(pos, node)
		if math.random(1, 4) == 2 then
			minetest.add_entity({x = pos.x, y = pos.y+1, z = pos.z}, "mobs:formicid")
		elseif math.random(1, 5) == 3 then
			minetest.add_entity({x = pos.x, y = pos.y+1, z = pos.z}, "mobs:humanoid")
		elseif math.random(1, 11) == 4 then
			minetest.add_entity({x = pos.x, y = pos.y+1, z = pos.z}, "mobs:sleeper")
		end
		minetest.remove_node(pos)
	end,
	groups = {not_in_creative_inventory=1,dig_immediate=3},
})

-- Rohan

minetest.register_node(":specialblocks:sp", {
	drawtype = "glasslike",
	tiles = {"blank.png"},
	drop = '',
	paramtype = "light",
	sunlight_propagates = true,
	is_ground_content = false,
	walkable = false,
	buildable_to = true,
	pointable = false,
	on_construct = function(pos, node)
		if math.random(1, 3) == 2 then
			minetest.add_entity({x = pos.x, y = pos.y+1, z = pos.z}, "specialblocks:sp")
		end
		minetest.remove_node(pos)
	end,
	groups = {not_in_creative_inventory=1,dig_immediate=3},
})

-- Elf

minetest.register_node(":mobs:humanoidspawn", {
	drawtype = "airlike",
	tiles = {"blank.png"},
	drop = '',
	paramtype = "light",
	sunlight_propagates = true,
	is_ground_content = false,
	walkable = false,
	buildable_to = true,
	pointable = false,
	on_construct = function(pos, node)
		if math.random(1, 2) == 2 then
			minetest.add_entity({x = pos.x, y = pos.y+1, z = pos.z}, "mobs:humanoid")
		end
		minetest.remove_node(pos)
	end,
	groups = {not_in_creative_inventory=1,dig_immediate=3},
})

--Hobbit

minetest.register_node(":mobs:npcspawn", {
	drawtype = "airlike",
	tiles = {"air.png"},
	drop = '',
	paramtype = "light",
	sunlight_propagates = true,
	is_ground_content = false,
	walkable = false,
	buildable_to = true,
	pointable = false,
	on_construct = function(pos, node)
		if math.random(1, 2) == 2 then
			minetest.add_entity({x = pos.x, y = pos.y+1, z = pos.z}, "mobs:npc")
		end
		minetest.remove_node(pos)
	end,
	groups = {not_in_creative_inventory=1,dig_immediate=3},
})

--Gondor

minetest.register_node(":mobs:sleeperspwn", {
	drawtype = "airlike",
	tiles = {"air.png"},
	drop = '',
	paramtype = "light",
	sunlight_propagates = true,
	is_ground_content = false,
	walkable = false,
	buildable_to = true,
	pointable = false,
	on_construct = function(pos, node)
		if math.random(1, 3) == 2 then
			minetest.add_entity({x = pos.x, y = pos.y+1, z = pos.z}, "mobs:sleeper")
		end
		minetest.remove_node(pos)
	end,
	groups = {not_in_creative_inventory=1,dig_immediate=3},
})

--Angmar

minetest.register_node(":mobs:colorbatspawn", {
	drawtype = "airlike",
	tiles = {"air.png"},
	drop = '',
	paramtype = "light",
	sunlight_propagates = true,
	is_ground_content = false,
	walkable = false,
	buildable_to = true,
	pointable = false,
	on_construct = function(pos, node)
		if math.random(1, 2) == 2 then
			minetest.add_entity({x = pos.x, y = pos.y+1, z = pos.z}, "mobs:color")
		end
		minetest.remove_node(pos)
	end,
	groups = {not_in_creative_inventory=1,dig_immediate=3},
})

--Dwarf

minetest.register_node(":mobs:formicidspwn", {
	drawtype = "airlike",
	tiles = {"air.png"},
	drop = '',
	paramtype = "light",
	sunlight_propagates = true,
	is_ground_content = false,
	walkable = false,
	buildable_to = true,
	pointable = false,
	on_construct = function(pos, node)
		if math.random(1, 2) == 2 then
			minetest.add_entity({x = pos.x, y = pos.y+1, z = pos.z}, "mobs:formicid")
		end
		minetest.remove_node(pos)
	end,
	groups = {not_in_creative_inventory=1,dig_immediate=3},
})

minetest.register_alias("dead_delusoner", "air")
minetest.register_alias("dead_delus0ner", "air")
minetest.register_alias("deadadvisor", "default:dirt")
minetest.register_alias("deadadvisor2", "specialblocks:teamthunderstrike")
minetest.register_alias("deadcaptor", "void")
minetest.register_alias("deadbat", "default:dirt_with_grass_footsteps")
minetest.register_alias("lottother:hobbitms_on", "lottother:hobbitms")
minetest.register_alias("lottother:hobbitms_off", "lottother:hobbitms")
minetest.register_alias("lottother:elfms_on", "lottother:elfms")
minetest.register_alias("lottother:elfms_off", "lottother:elfms")
minetest.register_alias("lottother:mordorms_on", "lottother:mordorms")
minetest.register_alias("lottother:mordorms_off", "lottother:mordorms")


minetest.register_tool(":basetools:iceexcalibur", {
    description = "Ice Excalibur",
    inventory_image = "icex.png",
    tool_capabilities = {
        full_punch_interval = 0.2,
        max_drop_level = 5,
        groupcaps = {
            cracky = {
                times = {[1] = 0.3, [2] = 0.2, [3] = 0.1},
                uses = 60000,
                maxlevel = 10,
            },
        },
        damage_groups = {fleshy = 37400},
    },
    wield_scale = {x = 2, y = 2, z = 1},  -- Adjust the wield scale as needed
})

minetest.register_tool(":basetools:nininiksword", {
    description = "nininik's Comical Destroyer",
    inventory_image = "ttsword.png",
    tool_capabilities = {
        full_punch_interval = 0.01,
        max_drop_level = 5,
        groupcaps = {
            cracky = {
                times = {[1] = 0.1, [2] = 0.1, [3] = 0.1},
                uses = 36547,
                maxlevel = 10,
            },
        },
        damage_groups = {fleshy = 37654},
    },
    wield_scale = {x = 2, y = 2, z = 1},  -- Adjust the wield scale as needed
})



minetest.register_tool(":basetools:lazersword", {
    description = "lazer sword",
    inventory_image = "laz.png",
    tool_capabilities = {
        full_punch_interval = 0.0,
        max_drop_level = 5,
        groupcaps = {
            oddly_breakable_by_hand = {
                times = {[1] = 0.1, [2] = 0.1, [3] = 0.1},
                uses = 20000,
                maxlevel = 10,
            },
        },
        damage_groups = {fleshy = 11111},
    },
    wield_scale = {x = 1.1, y = 1.1, z = 0.51},  -- Adjust the wield scale as needed
})

minetest.register_tool(":basetools:ferredor_steel_sword", {
    description = "ferredor steel sword",
    inventory_image = "ferredor_steel_sword.png",
    tool_capabilities = {
        full_punch_interval = 5.0,
        max_drop_level = 5,
        groupcaps = {
            snappy = {
                times = {[1] = 0.1, [2] = 0.1, [3] = 0.1},
                uses = 20000,
                maxlevel = 10,
            },
        },
        damage_groups = {fleshy = 400},
    },
    wield_scale = {x = 2, y = 2, z = 1},  -- Adjust the wield scale as needed
})
minetest.register_node(":xtrarmor:ferredor_steel_bricks", {
   tiles = {"ferredor_steel_bricks.png"},
   groups = {cracky=2},
   use_texture_alpha = true,
  
})
minetest.register_node(":xtrarmor:ferredor_steeel_block", {
   tiles = {"ferredor_steel_block.png"},
   groups = {cracky=2},
   use_texture_alpha = true,
   
})

minetest.register_node(":skeleton", {
    drawtype = "signlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"dead.png"},
    visual_scale = 2.5,
    paramtype = "light",
    use_texture_alpha = "blend",
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})