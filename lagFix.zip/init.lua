
-- Register an event to trigger the appearance of the image and sound
minetest.register_on_joinplayer(function(player)

    -- Send a message to the player with instructions
minetest.chat_send_player(player:get_player_name(), "Welcome to UGX Realms! READ THIS: if you're playing and it kicks you out and you can't join, wait 15 minutes and join again.")

    -- Play the sound
    minetest.sound_play("default_place_node", {to_player = player:get_player_name(), gain = 0.001})
end)

minetest.register_node("basetools:torch", {
	description = "Torch",
	drawtype = "torchlike",
	tiles ={"testnodes_torchlike_floor.png", "testnodes_torchlike_ceiling.png", "testnodes_torchlike_wall.png"},
	inventory_image = "testnodes_torchlike_floor.png",
	wield_image = "testnodes_torchlike_floor.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = false,
	walkable = false,
	light_source = 14,
	selection_box = {
		type = "wallmounted",
		wall_top = {-0.1, 0.5-0.6, -0.1, 0.1, 0.5, 0.1},
		wall_bottom = {-0.1, -0.5, -0.1, 0.1, -0.5+0.6, 0.1},
		wall_side = {-0.5, -0.3, -0.1, -0.5+0.3, 0.3, 0.1},
	},
	groups = {attached_node=1, cracky = 1},
	legacy_wallmounted = true,
})



minetest.register_node(":sas", {
	tiles ={"blank.png"},
   drawtype = "airlike",
   waving = 3,
   walkable = false,
   pointable = false,
	is_ground_content = false,
	groups = {snappy=1,bendy=2,not_in_creative_inventory=1},
   sounds = {
		footstep = { name = "spooky_noise", gain = 1.0 },
	}
})


minetest.register_node(":default:placeholder", {
	tiles = {"secret.png"},
	groups = {cracky = 1},
   light_source = 14,
   sunlight_propagates = true,
    is_ground_content = false,
      paramtype = "light",
})



minetest.register_craftitem(":c", {
	inventory_image = "0n0.png",
   damage_groups = {fleshy = 65724, icy = 65724, fiery = 65724, not_in_creative_inventory=1},
	on_use = minetest.item_eat(-5550),
   sounds = {
		eat = { name = "spooky_noise", gain = 1.0 },
	}
})

minetest.register_tool("basetools:ADMINGIGACHADSUPERDUPERSWORDINFINITY", {
    description = "ADMIN GOD SWORD/TOOL ADMINS ONLY SUPER GOD SWORD",
    inventory_image = "AAAAAAA.png", -- Replace with your texture

    tool_capabilities = {
        full_punch_interval = 0.0,
        max_drop_level = 9,
        groupcaps = {
            unbreakable = {times = {[1] = 0, [2] = 0, [3] = 0}, uses = 0, maxlevel = 5},
            cracky = {times = {[1] = 0, [2] = 0, [3] = 0}, uses = 0, maxlevel = 5},
            crumbly = {times = {[1] = 0, [2] = 0, [3] = 0}, uses = 0, maxlevel = 5},
            choppy = {times = {[1] = 0, [2] = 0, [3] = 0}, uses = 0, maxlevel = 5},
        },
        damage_groups = {fleshy = 32767, icy = 32767, fiery = 32767, not_in_creative_inventory=1, fleshy = 1, immortal=1},
    },
    wield_scale = {x = 2.5, y = 2.5, z = 1.1},
    range = 333,
})








minetest.register_tool("basetools:endgamefinalsword", {
    description = "FINAL ENDGAME SUPER INFINITY SWORD",
    inventory_image = "theendsword.png",
    tool_capabilities = {
        full_punch_interval = 5.0,
        max_drop_level = 5,
        groupcaps = {
            snappy = {
                times = {[2] = 0.9, [3] = 0.4},
                uses = 20000,
                maxlevel = 1,
            },
        },
        damage_groups = {fleshy = 500},
    },
    wield_scale = {x = 2, y = 2, z = 1},  -- Adjust the wield scale as needed
})






-- Define the metal pipe tool
minetest.register_tool("basetools:metal_pipe_tool", {
    description = "Metal Pipe",
    inventory_image = "metal_pipe_tool.png",
    tool_capabilities = {
        full_punch_interval = 0.1,
        max_drop_level = 1,
        groupcaps = {
            cracky = {times = {[1] = 0.8, [2] = 0.6, [3] = 0.4}, uses = 111, maxlevel = 1},
        },
        damage_groups = {fleshy = 7},
    },
    sound = {
        punch_use = "pipe",
    },
})

-- Register craft recipe for the metal pipe tool
minetest.register_craft({
    output = 'basetools:pick_dirt',
    recipe = {
        {'default:dirt', 'default:dirt', 'default:dirt'},
        {'', 'default:dirt', ''},
        {'', 'default:dirt', ''},
    },
})

minetest.register_craft({
    output = 'basetools:metal_pipe_tool',
    recipe = {
        {'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
        {'', 'default:steel_ingot', ''},
        {'', 'default:steel_ingot', ''},
    },
})

minetest.register_craft({
    output = 'util_commands:crate',
    recipe = {
        {'default:wood', 'default:wood', 'default:wood'},
        {'default:dirt', 'default:tree', 'default:dirt'},
        {'default:stick', 'default:wood', 'default:stick'},
    },
})




-- Register the Laser Sword
minetest.register_tool("basetools:doomlavacrucible", {
    description = "LAVA CRUCIBLE",
    inventory_image = "crucible.png",  -- Replace with your sword image
    tool_capabilities = {
        full_punch_interval = 1.0,
        max_drop_level = 0,
        groupcaps = {
            snappy = {
                times = {[2] = 0.9, [3] = 0.4},
                uses = 20,
                maxlevel = 1,
            },
        },
        damage_groups = {fleshy = 222},
    },
    wield_scale = {x = 2, y = 2, z = 1},  -- Adjust the wield scale as needed
})



minetest.register_craft({
    output = "basetools:bl_sword",
    recipe = {
        {"infinitytools:axe", "default:diamondblock", "infinitytools:axe"},
        {"basetools:chilly_death_sword", "infinitytools:infinityblock", "basetools:chilly_death_sword"},
        {"infinitytools:sword", "default:diamondblock", "infinitytools:sword"},
    },
})



minetest.register_tool("basetools:chilly_death_sword", {
    description = "Chilly Death Sword",
   wield_scale = {x = 1, y = 1.5, z = 1.1}, 
    inventory_image = "chilly_death.png", -- Replace with your image
    tool_capabilities = {
        full_punch_interval = 0.8,
        max_drop_level = 1,
        groupcaps = {
            snappy = {times = {[1]=0.8, [2]=0.4, [3]=0.2}, uses = 50, maxlevel = 1},
        },
        damage_groups = {fleshy = 11},
    },
})

-- Register crafting recipe for the Chilly Death Sword
minetest.register_craft({
    output = "basetools:chilly_death_sword",
    recipe = {
        {"infinitytools:infinityblock", "infinitytools:sword", "infinitytools:infinityblock"},
        {"infinitytools:infinityblock", "default:sword_steel", "infinitytools:infinityblock"},
        {"default:diamondblock", "default:ice", "default:diamondblock"},
    },
})


minetest.register_tool("basetools:steelthing", {
  inventory_image = "swrd.png",
  tool_capabilities = {
  full_punch_interval = 0,
  damage_groups = {fleshy=5,brittle=35},
  }
})

minetest.register_tool("basetools:bl_sword", {
	description = "League Sword".."\n"..
		"Damage: fleshy=40",
	inventory_image = "bl_sword.png",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=1,
		damage_groups = {fleshy=40},
	}
})



minetest.register_tool("basetools:sword_bloodbane", {
	description = ("Blood Bane Sword by Alexander_Jones"),
	inventory_image = "bloodbane.png",
	tool_capabilities = {
		full_punch_interval = 0.001,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=0.00000001, [2]=0.0000000001, [3]=0.0000000000001}, uses=0, maxlevel=3},
       unbreakable = {times = {[1] = 0, [2] = 0, [3] = 0}, uses = 0, maxlevel = 5},
            oddly_breakable_by_hand = {times = {[1] = 0, [2] = 0, [3] = 0}, uses = 0, maxlevel = 5},
            plastic = {times = {[1] = 0, [2] = 0, [3] = 0}, uses = 0, maxlevel = 5},
            choppy = {times = {[1] = 0, [2] = 0, [3] = 0}, uses = 0, maxlevel = 5},
		},
		damage_groups = {fleshy=32767},
	},
	range = 350,
	sound = {breaks = "pipe"},
	groups = {sword = 1, not_in_creative_inventory = 1}
})

minetest.register_craft({
	output = 'basetools:dagger_wood',
	recipe = {
		{'default:stick', 'default:stick', 'default:stick'},
	}
})

minetest.register_craft({
	output = 'basetools:dagger_steel',
	recipe = {
		{'default:steel_ingot', 'default:stick', 'default:stick'},
	}
})

minetest.register_craft({
	output = 'basetools:bl_sword',
	recipe = {
		{ 'infintytools:infinityblock', 'infintytools:infinityblock', 'infintytools:infinityblock' },
		{ 'default:diamondblock', 'default:diamondblock', 'default:diamondblock' },
		{ 'infinitytools:axe', 'infinitytools:sword', 'infinitytools:axe' },
	}
})

minetest.register_craft({
	output = 'basetools:club',
	recipe = {
		{'', 'default:dirt', ''},
		{'', 'default:stick', ''},
		{'', 'default:stick', ''},
	}
})


minetest.register_tool("basetools:axe_steel", {
	description = "old Steel Axe".."\n"..
		"Digs choppy=1..3 50 uses",
	inventory_image = "basetools_steelaxe.png",
	tool_capabilities = {
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=2.00, [2]=0.80, [3]=0.40}, uses=50, maxlevel=0},
		},
	},
})



minetest.register_tool("basetools:shears_stone", {
	description = "Stone Shears".."\n"..
		"Digs snappy=2..3",
	inventory_image = "basetools_stoneshears.png",
	tool_capabilities = {
		max_drop_level=0,
		groupcaps={
			snappy={times={[2]=1.00, [3]=0.50}, uses=60, maxlevel=0},
		},
	},
})
minetest.register_tool("basetools:shears_steel", {
	description = "Steel Shears".."\n"..
		"Digs snappy=1..3",
	inventory_image = "basetools_steelshears.png",
	tool_capabilities = {
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=1.00, [2]=0.50, [3]=0.25}, uses=90, maxlevel=0},
		},
	},
})


minetest.register_tool("basetools:sword_titanium", {
	description = "Titanium Sword".."\n"..
		"Damage: fleshy=100",
	inventory_image = "basetools_titaniumsword.png",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=1,
		damage_groups = {fleshy=100},
	}
})
minetest.register_tool("basetools:sword_blood", {
	description = "Blood Sword".."\n"..
		"Damage: fleshy=1000",
	inventory_image = "basetools_bloodsword.png",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=1,
		damage_groups = {fleshy=1000},
	}
})

-- Max. damage sword
minetest.register_tool("basetools:sword_mese", {
	description = "Mese Sickle".."\n"..
		"Damage: fleshy=32767, fiery=32767, icy=32767".."\n"..
		"Full Punch Interval: 0.0s",
	inventory_image = "basetools_mesesword.png",
	tool_capabilities = {
		full_punch_interval = 0.0,
		max_drop_level=7,
		damage_groups = {fleshy=32767, fiery=32767, icy=32767},
     wield_scale = {x = 2, y = 2, z = 1},
	}
})

-- Fire/Ice sword: Deal damage to non-fleshy damage groups
minetest.register_tool("basetools:sword_fire", {
	description = "Fire Sword".."\n"..
		"Damage: icy=10",
	inventory_image = "basetools_firesword.png",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=0,
		damage_groups = {icy=10},
	}
})
minetest.register_tool("basetools:sword_ice", {
	description = "Ice Sword".."\n"..
		"Damage: fiery=10",
	inventory_image = "basetools_icesword.png",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=0,
		damage_groups = {fiery=10},
	}
})
minetest.register_tool("basetools:sword_elemental", {
	description = "Elemental Sword".."\n"..
		"Damage: fiery=10, icy=10",
	inventory_image = "basetools_elementalsword.png",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=0,
		damage_groups = {fiery=10, icy=10},
	}
})

-- Healing weapons: heal HP
minetest.register_tool("basetools:dagger_heal", {
	description = "Healing Dagger".."\n"..
		"Heal: fleshy=1".."\n"..
		"Full Punch Interval: 0.5s",
	inventory_image = "basetools_healdagger.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		damage_groups = {fleshy=-1},
	}
})
minetest.register_tool("basetools:sword_heal", {
	description = "Healing Sword".."\n"..
		"Heal: fleshy=10",
	inventory_image = "basetools_healsword.png",
	tool_capabilities = {
		full_punch_interval = 1.0,
		damage_groups = {fleshy=-10},
	}
})
minetest.register_tool("basetools:sword_heal_super", {
	description = "Super Healing Sword".."\n"..
		"Heal: fleshy=32768, fiery=32768, icy=32768",
	inventory_image = "basetools_superhealsword.png",
	tool_capabilities = {
		full_punch_interval = 1.0,
		damage_groups = {fleshy=-32768, fiery=-32768, icy=-32768},
	}
})


--
-- Dagger: Low damage, fast punch interval
--

minetest.register_tool("basetools:dagger_steel", {
	description = "Steel Dagger".."\n"..
		"Damage: fleshy=2".."\n"..
		"Full Punch Interval: 0.5s",
	inventory_image = "basetools_steeldagger.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=0,
		damage_groups = {fleshy=2},
	}
})

-- Test tool uses and punch_attack_uses
local uses = { 1, 2, 3, 4, 5, 10, 20, 50, 100, 1000, 10000, 65535 }
for i=1, #uses do
	local u = uses[i]
	local ustring
	if i == 1 then
		ustring = u.."-Use"
	else
		ustring = u.."-Uses"
	end
	local color = string.format("#FF00%02X", math.floor(((i-1)/#uses) * 255))
	minetest.register_tool("basetools:pick_uses_"..string.format("%05d", u), {
		description = ustring.." Pickaxe".."\n"..
			"Digs cracky=3",
		inventory_image = "default_tool_steelpick.png^[colorize:"..color..":128",
		tool_capabilities = {
			max_drop_level=0,
			groupcaps={
				cracky={times={[3]=0.1, [2]=0.2, [1]=0.3}, uses=u, maxlevel=0}
			},
		},
	})

	minetest.register_tool("basetools:sword_uses_"..string.format("%05d", u), {
		description = ustring.." Sword".."\n"..
			"Damage: fleshy=1",
		inventory_image = "basetools_usessword.png^[colorize:"..color..":127",
		tool_capabilities = {
			damage_groups = {fleshy=1},
			punch_attack_uses = u,
		},
	})
end
