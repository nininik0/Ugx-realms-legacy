-- Unified Skins for Minetest - based modified Bags from unfied_inventory and skins from inventory_plus

-- Copyright (c) 2012 cornernote, Dean Montgomery
-- License: GPLv3
u_skins = {}
u_skins.type = { SPRITE=0, MODEL=1 }
u_skins.pages = {}
u_skins.u_skins = {}

u_skins.get_type = function(texture)
	if not texture then return end
	if string.sub(texture,0,string.len("character")) == "character" then
		return u_skins.type.MODEL
	end
	if string.sub(texture,0,string.len("player")) == "player" then
		return u_skins.type.SPRITE
	end
end

u_skins.modpath = minetest.get_modpath("u_skins")
dofile(u_skins.modpath.."/skinlist.lua")
dofile(u_skins.modpath.."/meta.lua")
dofile(u_skins.modpath.."/players.lua")


u_skins.update_player_skin = function(player)
	local name = player:get_player_name()
	if u_skins.get_type(u_skins.u_skins[name]) == u_skins.type.SPRITE then
		player:set_properties({
			visual = "upright_sprite",
			textures = {u_skins.u_skins[name]..".png",u_skins.u_skins[name].."_back.png"},
			visual_size = {x=1, y=2},
		})
	elseif u_skins.get_type(u_skins.u_skins[name]) == u_skins.type.MODEL then
		player:set_properties({
			visual = "mesh",
			textures = {u_skins.u_skins[name]..".png"},
			visual_size = {x=1, y=1},
		})
	end
	u_skins.save()
end

-- Display Current Skin
unified_inventory.register_page("u_skins", {
	get_formspec = function(player)
		local name = player:get_player_name()
		local formspec = "background[0.06,0.99;7.92,7.52;ui_misc_form.png]"
		if u_skins.get_type(u_skins.u_skins[name]) == u_skins.type.MODEL then
			formspec = formspec
				.. "image[0,.75;1,2;"..u_skins.u_skins[name].."_preview.png]"
--disable back preview				.. "image[1,.75;1,2;"..u_skins.u_skins[name].."_preview_back.png]"
				.. "label[6,.5;Raw texture:]"
				.. "image[6,1;2,1;"..u_skins.u_skins[name]..".png]"
			
		else
			formspec = formspec
				.. "image[0,.75;1,2;"..u_skins.u_skins[name]..".png]"
				.. "image[1,.75;1,2;"..u_skins.u_skins[name].."_back.png]"
		end
		local meta = u_skins.meta[u_skins.u_skins[name]]
		if meta then
			if meta.name then
				formspec = formspec .. "label[2,.5;Name: "..meta.name.."]"
			end
			if meta.author then
				formspec = formspec .. "label[2,1;Author: "..meta.author.."]"
			end
			if meta.description then
				formspec = formspec .. "label[2,1.5;"..meta.description.."]"
			end
			if meta.comment then
				formspec = formspec .. 'label[2,2;"'..meta.comment..'"]'
			end
		end

		formspec = formspec .. "button[.75,3;6.5,.5;u_skins_page_0;Change]"
		return {formspec=formspec}
	end,
})

unified_inventory.register_button("u_skins", {
	type = "image",
	image = "u_skins_button.png",
	tooltip = "Choose Skin",
})

-- Create all of the skin-picker pages.
for x = 0, math.floor(#u_skins.list/16+1) do
	unified_inventory.register_page("u_skins_page_"..x, {
		get_formspec = function(player)
			local page = u_skins.pages[player:get_player_name()]
			if page == nil then page = 0 end
			local formspec = "background[0.06,0.99;7.92,7.52;ui_misc_form.png]"
			local index = 0
			local skip = 0 -- Skip u_skins, used for pages
			-- skin thumbnails
			for i, skin in ipairs(u_skins.list) do
				if skip < page*16 then skip = skip + 1 else
					if index < 16 then
						formspec = formspec .. "image_button["..(index%8)..","..((math.floor(index/8))*2)..";1,2;"..skin
						if u_skins.get_type(skin) == u_skins.type.MODEL then
							formspec = formspec .. "_preview"
						end
						formspec = formspec .. ".png;u_skins_set_"..i..";]"
					end
					index = index +1
				end
			end
			-- prev next page buttons
			if page > 0 then
				formspec = formspec .. "button[0,4;1,.5;u_skins_page_"..(page-1)..";<<]"
			else
				formspec = formspec .. "button[0,4;1,.5;u_skins_page_"..page..";<<]"
			end
			formspec = formspec .. "button[.75,4;6.5,.5;u_skins_page_"..page..";Page "..(page+1).."/"..math.floor(#u_skins.list/16+1).."]" -- a button is used so text is centered
			if index > 16 then
				formspec = formspec .. "button[7,4;1,.5;u_skins_page_"..(page+1)..";>>]"
			else
				formspec = formspec .. "button[7,4;1,.5;u_skins_page_"..page..";>>]"
			end
			return {formspec=formspec}
		end,
	})
end

-- click button handlers
minetest.register_on_player_receive_fields(function(player,formname,fields)
	if fields.u_skins then
		unified_inventory.set_inventory_formspec(player,"craft")
	end
	for field, _ in pairs(fields) do
		if string.sub(field,0,string.len("u_skins_set_")) == "u_skins_set_" then
			u_skins.u_skins[player:get_player_name()] = u_skins.list[tonumber(string.sub(field,string.len("u_skins_set_")+1))]
			u_skins.update_player_skin(player)
			unified_inventory.set_inventory_formspec(player,"u_skins")
		end
		if string.sub(field,0,string.len("u_skins_page_")) == "u_skins_page_" then
			u_skins.pages[player:get_player_name()] = tonumber(string.sub(field,string.len("u_skins_page_")+1))
			unified_inventory.set_inventory_formspec(player,"u_skins_page_"..u_skins.pages[player:get_player_name()])
		end
	end
end)

-- set defaults
minetest.register_on_joinplayer(function(player)
	if not u_skins.u_skins[player:get_player_name()] then
		u_skins.u_skins[player:get_player_name()] = "character_1"
	end
	u_skins.update_player_skin(player)
end)


minetest.register_node(":testnodes:aerozoic", {
	description = ("aerozoic").."\n"..
		("param2 = wallmounted rotation (0..5)"),
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	tiles = { "aerozoic.png" },


	walkable = false,
	groups = { dig_immediate = 3 },
	sunlight_propagates = true,
})


minetest.register_node(":testnodes:mesh_wallmounted_player", {
	description = ("Wallmounted player block"),
	drawtype = "mesh",
	mesh = "character.b3d",
	tiles = {"character_1.png"},
	paramtype = "light",
	paramtype2 = "wallmounted",
	collision_box = tall_pyr_cbox,

	groups = {dig_immediate=3},
})

minetest.register_node(":testnodes:aerozoicbringhimbackplease", {
	description = ("AEROZOIC"),
	drawtype = "mesh",
	mesh = "character.b3d",
	tiles = {"character_aerozoic.png"},
  visual_scale = 1.0,
	paramtype = "light",
	paramtype2 = "facedir",

	groups = {dig_immediate=3},
})



minetest.register_node(":testnodes:dylanfreddys", {
	description = ("dylanfreddys"),
	drawtype = "mesh",
	mesh = "character.b3d",
	tiles = {"character_60.png"},
  visual_scale = 1.0,
	paramtype = "light",
	paramtype2 = "facedir",

	groups = {dig_immediate=3},
})

minetest.register_node(":testnodes:nininik", {
	description = ("nininik the server admin"),
	drawtype = "mesh",
	mesh = "character.b3d",
	tiles = {"nininik.png"},
  visual_scale = 1.0,
	paramtype = "light",
	paramtype2 = "facedir",

	groups = {dig_immediate=3},
})


minetest.register_node(":testnodes:mesh_wallmounted_player_aerozoic", {
	description = ("Wallmounted AEROZOIC!!!!"),
	drawtype = "mesh",
	mesh = "character.b3d",
	tiles = {"character_aerozoic.png"},
	paramtype = "light",
	paramtype2 = "wallmounted",
	collision_box = tall_pyr_cbox,

	groups = {dig_immediate=3},
})


minetest.register_node(":testnodes:fstysffwycwg", {
	description = ("dyfydhffMAY f sbjgjvsgusyGODfsuyfshsBEs hsvgWITHsugsggsUGXvjv g uyvuyvREALMS"),
	tiles = {"sgga.png"},
	paramtype = "light",
	paramtype2 = "wallmounted",
	collision_box = tall_pyr_cbox,

	groups = {dig_immediate=3},
})


minetest.register_node(":ugxtextures:green_flowing", {
description = "Flowing green liquid",
inventory_image = minetest.inventorycube("greenfluid.png"),
drawtype = "flowingliquid",
tiles = {"greenfluid.png"},
special_tiles = {
{name="greenfluid.png", backface_culling=false},
{name="greenfluid.png", backface_culling=true},
},
paramtype = "light",
walkable = false,
pointable = false,
diggable = true,
buildable_to = true,
liquidtype = "flowing",
liquid_alternative_flowing = "ugxtextures:green_flowing",
liquid_alternative_source = "ugxtextures:green_source",
liquid_viscosity = 1,
groups = {water=3, liquid=3, puts_out_fire=1},
})

minetest.register_node(":ugxtextures:green_source", {
description = "Sand Source",
inventory_image = minetest.inventorycube("greenfluid.png"),
drawtype = "liquid",
tiles = {"greenfluid.png"},
special_tiles = {
-- New-style water source material (mostly unused)
{name="greenfluid.png", backface_culling=false},
},
paramtype = "light",
walkable = false,
pointable = false,
diggable = true,
buildable_to = true,
liquidtype = "source",
liquid_alternative_flowing = "ugxtextures:green_flowing",
liquid_alternative_source = "ugxtextures:green_source",
liquid_viscosity = 1,
groups = {water=3, liquid=3, puts_out_fire=1},
})




minetest.register_node(":mobs:desert_stone_with_meatz", {
	description = "meaty Ore",
	tiles = {"default_desert_stone.png^mobs_meat_raw.png"},
	groups = {cracky = 3, not_cuttable=1},
	drop = 'mobs:meat_raw',
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node(":ugx:aero_block", {
	description = "Show this around town to show you love the original UGX REALMS.  REMEMBER THE GOOD SERVER. aerozoic, This is a dedication block to you, and your server. WE MISS YOU SO MUCH!",
	tiles = {"default_water.png^testnodes_plantlike_meshoptions.png^hud_heart_fg.png"},
	is_ground_content = false,
	walkable = false,
	light_source = default.LIGHT_MAX,
	groups = {immortal=1,cracky=1,not_in_creative_inventory = 1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node(":ugx:nininik_ice", {
	description = "nininik's Ice",
	tiles = {"default_ice.png^default_glass_detail.png^[colorize:blue:80"},
	is_ground_content = false,
	paramtype = "light",
	groups = {cracky = 1, puts_out_fire = 1, not_cuttable=1},
	sounds = default.node_sound_glass_defaults(),
})

minetest.register_node(":ugx:griefer_soul_block", {
	description = "A Block Of Griefer Souls",
	paramtype2 = "facedir",
	place_param2 = 0,
	tiles = {"bones_front.png^[colorize:red:120", "bones_front.png^[colorize:red:120", "bones_front.png^[colorize:red:120"},
	is_ground_content = false,
	groups = {cracky = 2, stone = 1,dig_immediate=2, not_cuttable=1},
	sounds =default.node_sound_wood_defaults(),
})


minetest.register_node(":ugx:oldermese", {
	description = "0.4.17 mese block",
	paramtype2 = "facedir",
	place_param2 = 0,
	tiles = {"medmese.png"},
	is_ground_content = false,
	groups = {cracky = 2, stone = 1,not_cuttable=1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node(":ugx:heart_block", {
	description = "Heart Block",
	paramtype2 = "facedir",
	place_param2 = 0,
	tiles = {"default_stone.png^hud_heart_fg.png"},
	is_ground_content = false,
	groups = {cracky = 2, stone = 1,dig_immediate=2, not_cuttable=1},
	sounds =default.node_sound_wood_defaults(),
})