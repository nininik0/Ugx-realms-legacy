u_skins.meta = {}
for _, i in ipairs(u_skins.list) do
	u_skins.meta[i] = {}
	local f = io.open(u_skins.modpath.."/meta/"..i..".txt")
	local data = nil
	if f then
		data = minetest.deserialize("return {"..f:read('*all').."}")
		f:close()
	end
	data = data or {}
	u_skins.meta[i].name = data.name or ""
	u_skins.meta[i].author = data.author or ""
	u_skins.meta[i].description = data.description or nil
	u_skins.meta[i].comment = data.comment or nil
end


-- Define Bone Remover node
minetest.register_node(":ugx:bone_remover", {
    description = "Bone Remover",
    tiles = {"default_stone.png^bubble.png"},
    groups = {cracky = 3},
    on_rightclick = function(pos, node, clicker, itemstack)
        local player_name = clicker:get_player_name()
        local radius = 25
        local bone_blocks = minetest.find_nodes_in_area(
            {x = pos.x - radius, y = pos.y - radius, z = pos.z - radius},
            {x = pos.x + radius, y = pos.y + radius, z = pos.z + radius},
            {"bones:bones"})
        for _, bone_pos in ipairs(bone_blocks) do
            minetest.remove_node(bone_pos)
        end
        minetest.sound_play("death", {
            pos = pos,
            max_hear_distance = 25,
            gain = 1.0,
        })
    end,
})

-- no

minetest.register_node(":ugx:admin_extinguisher", {
    description = "Admin Extinguisher",
    tiles = {"default_steel_block.png^heart.png"},
    groups = {cracky = 3},
    on_rightclick = function(pos, node, clicker, itemstack)
        local player_name = clicker:get_player_name()
        local radius = 50
        local fire_nodes = minetest.find_nodes_in_area(
            {x = pos.x - radius, y = pos.y - radius, z = pos.z - radius},
            {x = pos.x + radius, y = pos.y + radius, z = pos.z + radius},
            {"fire:basic_flame"})
        for _, fire_pos in ipairs(fire_nodes) do
            minetest.remove_node(fire_pos)
        end
        minetest.sound_play("windy3", {
            pos = pos,
            max_hear_distance = 50,
            gain = 1.0,
        })
    end,
})

-- no


-- Define Admin Lava Remover node
minetest.register_node(":ugx:admin_lava_remover", {
    description = "Admin Lava Remover",
    tiles = {"default_obsidian.png^horror_portal.png"},
    groups = {cracky = 3},
    on_rightclick = function(pos, node, clicker, itemstack)
        local radius = 25
        local lava_sources = minetest.find_nodes_in_area(
            {x = pos.x - radius, y = pos.y - radius, z = pos.z - radius},
            {x = pos.x + radius, y = pos.y + radius, z = pos.z + radius},
            {"default:lava_source"})
        for _, lava_pos in ipairs(lava_sources) do
            minetest.remove_node(lava_pos)
        end
        local lava_flows = minetest.find_nodes_in_area(
            {x = pos.x - radius, y = pos.y - radius, z = pos.z - radius},
            {x = pos.x + radius, y = pos.y + radius, z = pos.z + radius},
            {"default:lava_flowing"})
        for _, lava_pos in ipairs(lava_flows) do
            minetest.remove_node(lava_pos)
        end
        minetest.sound_play("tnt_gunpowder_burning", {
            pos = pos,
            max_hear_distance = 25,
            gain = 1.0,
        })
    end,
})


