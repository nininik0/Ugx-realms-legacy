xprotector2 = {}

-- Remove the old references to the "protector" mod
xprotector2.radius = tonumber(minetest.setting_get("xprotector2_radius")) or 30
xprotector2.drop = minetest.setting_getbool("xprotector2_drop") or false
xprotector2.flip = minetest.setting_getbool("xprotector2_flip") or false
xprotector2.hurt = tonumber(minetest.setting_get("xprotector2_hurt")) or 0

-- Intllib
local S
if minetest.get_modpath("intllib") then
    S = intllib.Getter()
else
    S = function(s, a, ...)
        if a == nil then
            return s
        end
        a = {a, ...}
        return s:gsub("(@?)@(%(?)(%d+)(%)?)",
            function(e, o, n, c)
                if e == ""then
                    return a[tonumber(n)] .. (o == "" and c or "")
                else
                    return "@" .. o .. n .. c
                end
            end)
    end
end
xprotector2.intllib = S

-- Return list of members as a table
xprotector2.get_member_list = function(meta)
    return meta:get_string("members"):split(" ")
end

-- Write member list table in xprotector2 meta as string
xprotector2.set_member_list = function(meta, list)
    meta:set_string("members", table.concat(list, " "))
end

-- Check if player name is a member
xprotector2.is_member = function (meta, name)
    for _, n in pairs(xprotector2.get_member_list(meta)) do
        if n == name then
            return true
        end
    end
    return false
end

-- Add player name to table as member
xprotector2.add_member = function(meta, name)
    if xprotector2.is_member(meta, name) then
        return
    end
    local list = xprotector2.get_member_list(meta)
    table.insert(list, name)
    xprotector2.set_member_list(meta, list)
end

-- Remove player name from table
xprotector2.del_member = function(meta, name)
    local list = xprotector2.get_member_list(meta)
    for i, n in pairs(list) do
        if n == name then
            table.remove(list, i)
            break
        end
    end
    xprotector2.set_member_list(meta, list)
end

-- xprotector2 interface
xprotector2.generate_formspec = function(meta)
    local formspec = "size[8,7]"
        .. default.gui_bg
        .. default.gui_bg_img
        .. default.gui_slots
        .. "label[2.5,0;" .. S("-- interface of Xprotector2 --") .. "]"
        .. "label[0,1;" .. S("To add members you need to add their name. Example, (nininik)") .. "]"
        .. "label[0,2;" .. S("Add Members:") .. "]"
        .. "button_exit[2.5,6.2;3,0.5;close_me;" .. S("Close") .. "]"

    local members = xprotector2.get_member_list(meta)
    local npp = 12 -- max users added to xprotector2 list
    local i = 0

    for n = 1, #members do
        if i < npp then
            -- Show username
            formspec = formspec .. "button[" .. (i % 4 * 2)
            .. "," .. math.floor(i / 4 + 3)
            .. ";1.5,.5;xprotector2_member;" .. members[n] .. "]"
            -- Username remove button
            .. "button[" .. (i % 4 * 2 + 1.25) .. ","
            .. math.floor(i / 4 + 3)
            .. ";.75,.5;xprotector2_del_member_" .. members[n] .. ";X]"
        end
        i = i + 1
    end

    if i < npp then
        -- User name entry field
        formspec = formspec .. "field[" .. (i % 4 * 2 + 1 / 3) .. ","
        .. (math.floor(i / 4 + 3) + 1 / 3)
        .. ";1.433,.5;xprotector2_add_member;;]"
        -- Username add button
        .."button[" .. (i % 4 * 2 + 1.25) .. ","
        .. math.floor(i / 4 + 3) .. ";.75,.5;xprotector2_submit;+]"
    end

    return formspec
end

-- Infolevel:
-- 0 for no info
-- 1 for "This area is owned by <owner> !" if you can't dig
-- 2 for "This area is owned by <owner>.
-- 3 for checking xprotector2 overlaps

xprotector2.can_dig = function(r, pos, digger, onlyowner, infolevel)
    if not digger or not pos then
        return false
    end
    -- Find the xprotector2 nodes
    local pos = minetest.find_nodes_in_area(
        {x = pos.x - r, y = pos.y - r, z = pos.z - r},
        {x = pos.x + r, y = pos.y + r,z = pos.z + r},
        {"xprotector2:protect", "xprotector2:protect2"})
    local meta, owner, members
    for n = 1, #pos do
        meta = minetest.get_meta(pos[n])
        owner = meta:get_string("owner") or ""
        members = meta:get_string("members") or ""
        -- Node change and digger isn't owner
        if owner ~= digger and infolevel == 1 then
            -- And you aren't on the member list
            if onlyowner or not xprotector2.is_member(meta, digger) then
                minetest.chat_send_player(digger,
                    S("This area is owned by @1!", owner))
                return false
            end
        end
        -- When using xprotector2 as tool, show xprotector2 information
        if infolevel == 2 then
            minetest.chat_send_player(digger,
            S("This area is owned by @1.", owner))
            minetest.chat_send_player(digger,
            S("Protection located at: @1", minetest.pos_to_string(pos[n])))
            if members ~= "" then
                minetest.chat_send_player(digger,
                S("Members: @1.", members))
            end
            return false
        end
    end
    -- Show when you can build on unprotected area
    if infolevel == 2 then
        if #pos < 1 then
            minetest.chat_send_player(digger,
            S("This area is not protected."))
        end
        minetest.chat_send_player(digger, S("You can build here."))
    end
    return true
end

xprotector2.old_is_protected = minetest.is_protected

-- Check for protected area, return true if protected and digger isn't on list
function minetest.is_protected(pos, digger)
    -- Is area protected against digger?
    if not xprotector2.can_dig(xprotector2.radius, pos, digger, false, 1) then
        local player = minetest.get_player_by_name(digger)
        -- Hurt player if protection violated
        if xprotector2.hurt > 0 and player then
            player:set_hp(player:get_hp() - xprotector2.hurt)
        end
        return true
    end
    -- Otherwise can dig or place
    return xprotector2.old_is_protected(pos, digger)
end

local check_overlap = function(itemstack, placer, pointed_thing)
    if pointed_thing.type ~= "node" then
        return itemstack
    end

    local pos = pointed_thing.above
    local name = placer:get_player_name()

    -- Make sure xprotector2 doesn't overlap any other player's area
    if not xprotector2.can_dig(xprotector2.radius * 2, pos, name, true, 3) then
        minetest.chat_send_player(name, S("Overlaps into another protected area"))
        return itemstack
    end

    return minetest.item_place(itemstack, placer, pointed_thing)
end
-- Protection node
minetest.register_node("xprotector2:protect", {
    description = S("Protection Block"),
    drawtype = "nodebox",
    tiles = {
        "moreblocks_circle_stone_bricks2.png",
        "moreblocks_circle_stone_bricks2.png",
        "moreblocks_circle_stone_bricks2.png",
        "moreblocks_circle_stone_bricks2.png^protector_logo.png"
    },
    sounds = default.node_sound_stone_defaults(),
    groups = {dig_immediate = 2, unbreakable = 1},
    is_ground_content = false,
    paramtype = "light",
    light_source = 4,
    node_box = {
        type = "fixed",
        fixed = {
            {-0.5 ,-0.5, -0.5, 0.5, 0.5, 0.5},
        }
    },
    on_place = xprotector2.check_overlap,
    after_place_node = function(pos, placer)
        local meta = minetest.get_meta(pos)
        meta:set_string("owner", placer:get_player_name() or "")
        meta:set_string("infotext", S("Protection (owned by @1)", meta:get_string("owner")))
        meta:set_string("members", "")
    end,
    on_use = function(itemstack, user, pointed_thing)
        if pointed_thing.type ~= "node" then
            return
        end
        xprotector2.can_dig(xprotector2.radius, pointed_thing.under, user:get_player_name(), false, 2)
    end,
    on_rightclick = function(pos, node, clicker, itemstack)
        local meta = minetest.get_meta(pos)
        if xprotector2.can_dig(1, pos, clicker:get_player_name(), true, 1) then
            minetest.show_formspec(clicker:get_player_name(), 
            "xprotector2:node_" .. minetest.pos_to_string(pos), xprotector2.generate_formspec(meta))
        end
    end,
    on_punch = function(pos, node, puncher)
        if minetest.is_protected(pos, puncher:get_player_name()) then
            return
        end
        minetest.add_entity(pos, "xprotector2:display")
    end,
    can_dig = function(pos, player)
        return xprotector2.can_dig(1, pos, player:get_player_name(), true, 1)
    end,
    on_blast = function() end,
})

minetest.register_craft({
    output = "xprotector2:protect",
    recipe = {
        {"protector:protect", "protector:protect", "protector:protect"},
        {"protector:protect", "default:goldblock9", "protector:protect"},
        {"default:dirt", "protector:protect2", "default:dirt"},
    }
})

-- Protection logo
minetest.register_node("xprotector2:protect2", {
    description = S("Protection Logo"),
    tiles = {"ignore.png"},
    wield_image = "air.png",
    inventory_image = "ignore.png^protector_logo.png",
    sounds = default.node_sound_stone_defaults(),
    groups = {dig_immediate = 2, unbreakable = 1},
    paramtype = 'light',
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    light_source = 4,
    drawtype = "nodebox",
    sunlight_propagates = true,
    walkable = true,
    node_box = {
        type = "wallmounted",
        wall_top    = {-0.375, 0.4375, -0.5, 0.375, 0.5, 0.5},
        wall_bottom = {-0.375, -0.5, -0.5, 0.375, -0.4375, 0.5},
        wall_side   = {-0.5, -0.5, -0.375, -0.4375, 0.5, 0.375},
    },
    selection_box = {type = "wallmounted"},
    on_place = xprotector2.check_overlap,
    after_place_node = function(pos, placer)
        local meta = minetest.get_meta(pos)
        meta:set_string("owner", placer:get_player_name() or "")
        meta:set_string("infotext", S("Protection (owned by @1)", meta:get_string("owner")))
        meta:set_string("members", "")
    end,
    on_use = function(itemstack, user, pointed_thing)
        if pointed_thing.type ~= "node" then
            return
        end
        xprotector2.can_dig(xprotector2.radius, pointed_thing.under, user:get_player_name(), false, 2)
    end, 
on_rightclick = function(pos, node, clicker, itemstack)
        local meta = minetest.get_meta(pos)
        if xprotector2.can_dig(1, pos, clicker:get_player_name(), true, 1) then
            minetest.show_formspec(clicker:get_player_name(), 
            "xprotector2:node_" .. minetest.pos_to_string(pos), xprotector2.generate_formspec(meta))
        end
    end,
    on_punch = function(pos, node, puncher)
        if minetest.is_protected(pos, puncher:get_player_name()) then
            return
        end
        minetest.add_entity(pos, "xprotector2:display")
    end,
    can_dig = function(pos, player)
        return xprotector2.can_dig(1, pos, player:get_player_name(), true, 1)
    end,
    on_blast = function() end,
})

minetest.register_entity("xprotector2:display", {
    physical = false,
    glow = 14,
    collisionbox = {0, 0, 0, 0, 0, 0},
    visual = "wielditem",
    visual_size = {x = 1.0 / 1.5, y = 1.0 / 1.5},  -- scaled to 1.5 times original node size
    textures = {"xprotector2:display_node"},
    timer = 0,

    on_step = function(self, dtime)
        self.timer = self.timer + dtime

        -- remove after 15 seconds
        if self.timer > 15 then
            self.object:remove()
        end
    end,
})

local x = xprotector2.radius
minetest.register_node("xprotector2:display_node", {
    tiles = {"protector_display.png"},
    use_texture_alpha = true,
    walkable = false,
    light_source = 14,
    drawtype = "nodebox",
    node_box = {
        type = "fixed",
        fixed = {
            -- sides
            {-(x + 0.55), -(x + 0.55), -(x + 0.55), -(x + 0.45), (x + 0.55), (x + 0.55)},
            {-(x + 0.55), -(x + 0.55), (x + 0.45), (x + 0.55), (x + 0.55), (x + 0.55)},
            {(x + 0.45), -(x + 0.55), -(x + 0.55), (x + 0.55), (x + 0.55), (x + 0.55)},
            {-(x + 0.55), -(x + 0.55), -(x + 0.55), (x + 0.55), (x + 0.55), -(x + 0.45)},
            -- top
            {-(x + 0.55), (x + 0.45), -(x + 0.55), (x + 0.55), (x + 0.55), (x + 0.55)},
            -- bottom
            {-(x + 0.55), -(x + 0.55), -(x + 0.55), (x + 0.55), -(x + 0.45), (x + 0.55)},
            -- middle (surround protector)
            {-.55, -.55, -.55, .55, .55, .55},
        },
    },
    selection_box = {
        type = "regular",
    },
    paramtype = "light",
    groups = {dig_immediate = 3, not_in_creative_inventory = 1},
    drop = "",
})