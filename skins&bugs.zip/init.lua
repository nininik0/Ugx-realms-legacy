
-- Load support for intllib.
local path = minetest.get_modpath(minetest.get_current_modname()) .. "/"

-- Translation support
local S = minetest.get_translator("mobs_monster")

-- Check for custom mob spawn file
local input = io.open(path .. "spawn.lua", "r")

if input then
	mobs.custom_spawn_monster = true
	input:close()
	input = nil
end


-- helper function
local function ddoo(mob)

	if minetest.settings:get_bool("mobs_monster." .. mob) == false then
		print("[Mobs_Monster] " .. mob .. " disabled!")
		return
	end

	dofile(path .. mob .. ".lua")
end

-- Monsters
ddoo("dirt_monster") -- PilzAdam
ddoo("dungeon_master")
ddoo("sand_monster")
ddoo("stone_monster")
ddoo("spider") -- AspireMint


-- Load custom spawning
if mobs.custom_spawn_monster then
	dofile(path .. "spawn.lua")
end


-- Lucky Blocks
if minetest.get_modpath("lucky_block") then
	dofile(path .. "lucky_block.lua")
end

mobs:register_mob("mobs_monster:sam", {
   type = "monster",
   passive = false,
   attacks_monsters = true,
   attacks_npcs = true,
   damage = 1,
   reach = 1,
   attack_type = "dogfight",
   hp_min = 30,
   hp_max = 45,
   armor = 80,
   collisionbox = {-0.25, 0.35, -0.25, 0.25, 0.9, 0.25},
   physical = false,
   visual = "mesh",
   mesh = "character.b3d",
   textures = {
      {"deadsam.png"},
   },
   blood_amount = 1,
   blood_texture = "blank.png",
   visual_size = {x=1, y=1},
   makes_footstep_sound = false,
   walk_velocity = 0.01,
   run_velocity = 5,
   jump = false,
   water_damage = 2,
   lava_damage = 0,
   light_damage = 0,
   view_range = 20,
   animation = {
      speed_normal = 1,
      speed_run = 1,
      walk_start = 1,
      walk_end = 1,
      stand_start = 1,
      stand_end = 1,
      run_start = 1,
      run_end = 1,
      punch_start = 1,
      punch_end = 1,
   },
})



mobs:register_mob("mobs_monster:_", {
	type = "monster",
	hp_min = 20,
    show_on_minimap = true,
  nametag = ".",
	hp_max = 200,
   damage = 11,
  jump_height = 50,
	visual = "upright_sprite",
   collisionbox = {-0.5, -1.5, -0.5, 0.5, 0.5, 0.5},
	textures = {"yikes.png", "yikes1.png" },
   visual_size = { x = 5, y = 5, z = 5 },
	walk_velocity = 5,
   jump_height = 15.55,
	run_velocity = 22,
	view_range = 321,
	pathfinding = 1222,
	sounds = {
		random = "spooky_noise",
	},
	drops = {
		{name = "air", chance = 11, min = 0, max = 1},
		{name = "default:portal2", chance = 100, min = 0, max = 1},
	},
	attack_type = "dogfight",
	reach = 5,
	damage = 11,
})

-- UNKOWN OBJCECT FINAL BOSS by nininik

mobs:register_mob("mobs_monster:UNKNOWN", {
	type = "monster",
	passive = false,
	damage = 15,
	attack_type = "shoot",
--	dogshoot_switch = 1,
--	dogshoot_count_max = 30, -- nah bro
--	dogshoot_count2_max = 1, -- bruh  
--	reach = 40,
	shoot_interval = 1,
	arrow = "mobs_monster:item",
	shoot_offset = 0,
  blood_amount = 100,
  blood_texture = "no_texture.png",
	hp_min = 500,
	hp_max = 1000,
	armor = 90,
	knock_back = true,
	collisionbox = {-4, -4, -4, 4, 4.6, 4},
	visual = "sprite",
	textures = {
		"unknown_object.png",
	},
	visual_size = {x=9, y=9},
	makes_footstep_sound = true,
	sounds = {
		random = "shut",
		shoot_attack = "mobs_fireball",
	},
	walk_velocity = 5,
	run_velocity = 22,
	jump = true,
	view_range = 100,
	drops = {
		{name = "util_commands:unkown", chance = 1, min = 1, max = 2},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 20
})


mobs:spawn({
	name = "mobs_flat:UNKNOWN",
	nodes = {"util_commands:unkown"},
	neighbors = {"default:mese", "default:stone_with_mese", "air", "default:mossycobble"},
	chance = 1,
	active_object_count = 1,
})




-- ITEM (weapon)
mobs:register_arrow("mobs_monster:item", {
	visual = "sprite",
	visual_size = {x = 2, y = 2},
	textures = {"unknown_item.png"},
	velocity = 6,
	tail = 1,
	tail_texture = "unknown_node.png",
	tail_size = 8,
	glow = 8,
	expire = 1,

	-- direct hit, no fire... just plenty of pain
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 100},
		}, nil)
	end,

	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 100},
		}, nil)
	end,

	-- node hit
	hit_node = function(self, pos, node)
		mobs:boom(self, pos, 10)
	end
})

-- support for MT game translation.
local S = minetest.get_translator("mobs_monster")

-- eye boss by nininik

mobs:register_mob("mobs_monster:eyeboss", {
	type = "monster",
	passive = false,
	damage = 4,
	attack_type = "shoot",
--	dogshoot_switch = 1,
--	dogshoot_count_max = 30, -- nah bro
--	dogshoot_count2_max = 1, -- bruh  
--	reach = 40,
	shoot_interval = 3,
	arrow = "mobs_monster:eyeball",
	shoot_offset = 0.1,
	hp_min = 50,
	hp_max = 70,
	armor = 60,
	knock_back = true,
	collisionbox = {-0.7, -1, -0.7, 0.7, 1.6, 0.7},
	visual = "upright_sprite",
	textures = {
		"mobs_flat_eyeboss.png",
	},
	visual_size = {x=2, y=2},
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_spider",
		shoot_attack = "tnt_ignite",
	},
	walk_velocity = 4,
	run_velocity = 9,
	jump = true,
	view_range = 50,
	drops = {
		{name = "c", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 8,
})


mobs:spawn({
	name = "mobs_monster:eyeboss",
	nodes = {"default:placeholder"},
	neighbors = {"default:mese", "default:stone_with_mese", "air", "default:mossycobble"},
	chance = 1,
	active_object_count = 1,
})


mobs:register_egg("mobs_monster:eyeboss", ("eye boss"), "mobs_flat_eyeboss.png", 1)


-- fireball (weapon)
mobs:register_arrow("mobs_monster:eyeball", {
	visual = "sprite",
	visual_size = {x = 1, y = 1},
	textures = {"eyeball.png"},
	velocity = 6,
	tail = 1,
	tail_texture = "horror_portal.png",
	tail_size = 10,
	glow = 8,
	expire = 0.5,

	-- direct hit, no fire... just plenty of pain
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 5},
		}, nil)
	end,

	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 10},
		}, nil)
	end,

	-- node hit
	hit_node = function(self, pos, node)
		mobs:boom(self, pos, 9)
	end
})

-- support for MT game translation.


-- starcursed_mass by nininik

mobs:register_mob("mobs_monster:starcursed_mass", {
	type = "monster",
	passive = false,
	damage = 3,
	attack_type = "shoot",
	shoot_interval = 2,
  use_texture_alpha = true,
	arrow = "mobs_monster:arrow",
	shoot_offset = 0.1,
	hp_min = 20,
	hp_max = 50,
	armor = 50,
	knock_back = true,
	collisionbox = {-0.7, -1, -0.7, 0.7, 1.6, 0.7},
	visual = "upright_sprite",
	textures = {
		"starcursed_mass.png",
	},
	visual_size = {x=2, y=2},
	makes_footstep_sound = true,
	sounds = {
		random = "soundstuff_sinus",
		shoot_attack = "p",
	},
	walk_velocity = 5,
	run_velocity = 11,
	jump = true,
  jump_height = 16,
	view_range = 100,
	drops = {
		{name = "default:diamond", chance = 0.5, min = 0, max = 7},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 3,
})


mobs:spawn({
	name = "mobs_monster:starcursed_mass",
	nodes = {"default:stone_with_diamond", "default:stone_with_mese", "default:stone_with_mese"},
	neighbors = {"default:stone", "default:stone_with_mese", "air", "default:stone_with_diamond"},
	chance = 111,
	active_object_count = 1,
})


mobs:register_egg("mobs_monster:starcursed_mass", ("Starcursed Mass"), "starcursed_mass.png", 1)


-- fireball (weapon)
mobs:register_arrow("mobs_monster:arrow", {
	visual = "sprite",
	visual_size = {x = 1, y = 1},
	textures = {"starcursed_mass.png"},
	velocity = 11,
	tail = 1,
	tail_texture = "starcursed_mass.png",
	tail_size = 1,
	glow = 8,
	expire = 1,

	-- direct hit, no fire... just plenty of pain
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 5},
		}, nil)
	end,

	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 10},
		}, nil)
	end,

	-- node hit
	hit_node = function(self, pos, node)
		mobs:boom(self, pos, 1)
	end
})



mobs:spawn({
	name = "slimes:lavabig",
	nodes = {"default:lava_source"},
	chance = 40,
	active_object_count = 12,
	max_height = -10,
})

-- Mese Monster

mobs:spawn({
	name = "slimes:greenbig",
	nodes = {"default:jungletree"},
	min_light = 0,
	chance = 33,
	active_object_count = 2,
	max_height = 200,
})

-- slimy

mobs:spawn({
	name = "slimes:greenmedium",
	nodes = {"default:junglegrass"},
	min_light = 0,
	chance = 40,
	max_height = 100,
})

mobs:register_mob("mobs_monster:crane_monster", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 1,
	damage = 2,
	hp_min = 12,
	hp_max = 32,
	armor = 100,
  blood_amount = 666,
  blood_texture = "default_steel_ingot.png",
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=2, y=4.1},
	textures = {
		"crane_monster.png",
	},
	makes_footstep_sound = true,
	sounds = {
		random = "pipe",
	},
	walk_velocity = 0.5,
	run_velocity = 9,
	view_range = 100,
	jump = true,
	drops = {
		{name = "default:steelblock", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 50,
	replace_rate = 9,
	replace_what = {"default:torch"},
	replace_with = "ugx:waste",
	replace_offset = 0,
	floats = 1,
})

mobs:spawn({
	name = "mobs_monster:crane_monster",
	nodes = {"oresplus:stone_with_emerald", "default:stone_with_diamond", "default:stone_with_mese"},
	neighbors = {"air", "default:stone"},
	chance = 111,
	active_object_count = 1,
})

mobs:register_egg("mobs_monster:crane_monster", ("CRANE MONSTER"), "crane_monster.png", 1)

mobs:register_mob(":aerozoic", {
	type = "npc",
  attacks_monsters = true,
  attacks_npcs = false,
	passive = false,
  jump_height = 15.55,
	attack_type = "dogfight",
  blood_amount = 222,
  blood_texture = "heart.png",
	pathfinding = true,
	reach = 2,
	damage = 777,
  show_on_minimap = true,
  nametag = "aerozoic",
	hp_min = 65535,
	hp_max = 65535,
	armor = 2,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=1, y=2},
	textures = {
		"aerozoic.png",
		"aerozoic_back.png",
	},
	makes_footstep_sound = true,
	sounds = {
		random = "ugx",
	},
	walk_velocity = 5,
	run_velocity = 10,
	view_range = 111,
	jump = true,
	drops = {
		{name = "testnodes:aerozic", chance = 1, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 0,
	replace_rate = 5,
	replace_what = {"default:stone"},
	replace_with = "default:stone_with_iron",
	replace_offset = -1,
	floats = 1,
})

mobs:register_mob("mobs_monster:_aerozoic_", {
	type = "monster",
  attacks_monsters = true,
  attacks_npcs = true,
    show_on_minimap = true,
  jump_height = 16,
  nametag = "аеяоzоïc",
	passive = false,
  blood_amount = 666,
  blood_texture = "eaves.png",
	attack_type = "dogfight",
	pathfinding = true,
	reach = 2,
	damage = 666,
	hp_min = 65535,
	hp_max = 65535,
	armor = 1,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=1, y=2},
	textures = {
		"aerozoicx.png",
		"aerozoic_backx.png",
	},
	makes_footstep_sound = true,
	sounds = {
		random = "dark",
	},
	walk_velocity = 5,
	run_velocity = 10,
	view_range = 211,
	jump = true,
	drops = {
		{name = "testnodes:drain", chance = 1, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 0,
	replace_rate = 5,
	replace_what = {"default:dirt_with_grass"},
	replace_with = "default:gravel",
	replace_offset = -1,
	floats = 1,
})

mobs:register_mob("mobs_monster:the_dark", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 2,
	damage = 5,
	hp_min = 20,
	hp_max = 100,
	armor = 100,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "mesh",
	mesh = "mobs_stone_monster.b3d",
	textures = {
		{"darkmonster2.png"},
		{"darkmonster.png"} -- by nininik
	},
	makes_footstep_sound = true,
	sounds = {
		random = "shut",
	},
	walk_velocity = 2,
	run_velocity = 19,
	jump_height = 8,
	stepheight = 9,
	floats = 0,
	view_range = 66,
	drops = {
		{name = "util_commands:apple_iron", chance = 2, min = 1, max = 2},
		{name = "default:dirt_with_grass_footsteps", chance = 3, min = 1, max = 2},
		{name = "default:diamond", chance = 4, min = 1, max = 7}
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 40,
		run_end = 63,
		punch_start = 40,
		punch_end = 63,
	}
})

mobs:spawn({
	name = "mobs_monster:the_dark",
	nodes = {"default:stone"},
	chance = 8000,
	active_object_count = 1,
	max_height = -1
})

function find_reactor(pos, radius)
	for dx = -radius, radius do
		for dy = -radius, radius do
			for dz = -radius, radius do
				local node_pos = vector.add(pos, {x = dx, y = dy, z = dz})
				local node = minetest.get_node(node_pos)
				if node.name == "ugx:nuclear_reactor" then
					return node_pos
				end
			end
		end
	end
	return nil
end

minetest.register_node("mobs_monster:nuclear_fueler", {
	description = "Nuclear Reactor Fueler",
	tiles = {"rerere.png"},
	drawtype = "mesh",
  visual_scale = 2,
	mesh = "testnodes_marble_glass.obj", -- Replace with your mesh file path
	groups = {cracky = 2},
	
	on_construct = function(pos)
		minetest.after(10, function()
			local reactor_pos = find_reactor(pos, 3)
			if not reactor_pos then
				minetest.chat_send_all("Nuclear reactor WILL EXPLODE!!! IN 3 SECONDS!!!")
				minetest.set_node(pos, {name = "ugx:testwarn"}) -- Remove the fueler
				minetest.sound_play("24", {pos = pos, gain = 1.0, max_hear_distance = 1000})
				minetest.after(1, function() 
					minetest.set_node(pos, {name = "ugx:nuclear_reactor"}) -- Ignite the fueler
					minetest.after(1, function() 
						minetest.set_node(pos, {name = "ugx:corium"}) -- Remove the flame
						tnt.boom(pos, {damage_radius = 50, radius = 50, ignore_protection = true, explode_center = true})
						replace_air_with_waste(pos, 100)
						remove_leaves(pos, 100)
					end)
				end)
			end
		end)
	end
})

function replace_air_with_waste(center_pos, radius)
	local corium_center = vector.add(center_pos, {x = 25, y = 0, z = 25})
	for dx = -radius, radius do
		for dy = -radius, radius do
			for dz = -radius, radius do
				local pos = vector.add(center_pos, {x = dx, y = dy, z = dz})
				if vector.distance(pos, corium_center) > 10 then -- Ensure corium center is not affected
					local node = minetest.get_node(pos)
					if node.name == "air" then
						minetest.set_node(pos, {name = "ugx:waste"})
					end
				end
			end
		end
	end
end

function remove_leaves(center_pos, radius)
	for dx = -radius, radius do
		for dy = -radius, radius do
			for dz = -radius, radius do
				local pos = vector.add(center_pos, {x = dx, y = dy, z = dz})
				local node = minetest.get_node(pos)
				if minetest.get_item_group(node.name, "leaves") > 0 then
					minetest.set_node(pos, {name = "ugx:corium"})
				end
			end
		end
	end
end


print ("[MOD] Mobs Monster loaded")
