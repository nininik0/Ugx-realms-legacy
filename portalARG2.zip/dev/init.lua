local light_decode_table = {8, 11, 14, 18, 22, 29, 37, 47, 60, 76, 97, 123, 157, 200, 255}
local last_brightness = -1

local function time_to_daynight_ratio(tod)
	local daylength, nightlength, daytimelength = 16, 6, 8
	local t = (tod % 24000) / (24000 / daylength)
	if t < nightlength / 2 or t >= daylength - nightlength / 2 then
		return 350
	elseif t >= daylength / 2 - daytimelength / 2 and t < daylength / 2 + daytimelength / 2 then
		return 1000
	else
		return 750
	end
end

local function set_skybox(player, brightness)
	local t = "_night"
	if brightness >= 0.5 then
		t = ""
	elseif brightness >= 0.2 then
		t = "_dawn"
	end
	local c = math.floor(brightness * 255)
	player:set_sky({
		type = "skybox",
		base_color = string.format("#%02x%02x%02x", c, c, c),
		textures = {
			"skybox2" .. t .. ".png",
			"skybox3" .. t .. ".png",
			"skybox1" .. t .. ".png",
			"skybox1" .. t .. ".png",
			"skybox1" .. t .. ".png",
			"skybox1" .. t .. ".png"
		},
	})
end

local function update_brightness()
	local tod_f = minetest.get_timeofday()
	local ratio = time_to_daynight_ratio(tod_f * 24000)
	local index = math.floor(ratio * #light_decode_table / 1000)
	index = math.min(index, #light_decode_table - 1)
	return light_decode_table[index + 1] / 255
end

local function update_skybox_for_all_players(brightness)
	for _, player in ipairs(minetest.get_connected_players()) do
		set_skybox(player, brightness)
	end
end

minetest.register_globalstep(function(dtime)
	local brightness = update_brightness()

	if math.abs(last_brightness - brightness) >= 0.03 then
		last_brightness = brightness
		update_skybox_for_all_players(brightness)
	end
end)

minetest.register_on_joinplayer(function(player)
	if last_brightness ~= nil then
		set_skybox(player, last_brightness)
		player:hud_add({
			hud_elem_type = "text",
			position = {x = 0.5, y = 0.05},
			offset = {x = 0, y = 0},
			text = "TEST MODE ENABLED!",
			number = 0xFF0000,  -- Red color
			alignment = {x = 0, y = 0},
			scale = {x = 90, y = 90},
		})
	end

	player:set_stars({ visible = true })
	player:set_moon({ texture = "moon_SUS.png" })
	star_color = "#FAFFFAAB",
	player:set_clouds({
		color = "#1c4b8dff",
     }) 
end)






--NOW IT GETS REAL >:)
--NOW IT GETS REAL >:)


mobs:register_mob("specialblocks:sр", {
	type = "monster",
  automatic_rotate= 9999,
  infotext = "VØÏĐ",
	passive = false,
  nametag = "VØID HAЯVSTER",
	damage = 999,
	attack_type = "shoot",
--	dogshoot_switch = 1,
--	dogshoot_count_max = 30, -- nah bro
--	dogshoot_count2_max = 1, -- bruh  
	reach = 15,
	shoot_interval = 0.7,
	arrow = "mobs_monster:item",
	shoot_offset = 0,
  blood_amount = 1000,
  blood_size = 9,
  blood_texture = "yikes1.png",
	hp_min = 9500,
	hp_max = 10900,
	armor = 90,
	knock_back = true,
	collisionbox = {-4, -4, -4, 4, 4.6, 4},
	visual = "upright_sprite",
	textures = {
		"starcursed_mass.png^yikes.png^0n0.png^crosshair.png^ohmy.png",
	},
	visual_size = {x=9, y=9},
	makes_footstep_sound = true,
	sounds = {
		random = "imagetoaudio",
		shoot_attack = "spooky_noise",
	},
	walk_velocity = 55,
	run_velocity = 66,
	jump = true,
	view_range = 1000,
	drops = {
		{name = "ignore", chance = 1, min = 1, max = 6772},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 200
})



	mobs:spawn({
		name = "mobs_monster:delusоnеr",
		nodes = {"default:dirt_with_grass", "ethereal:gray_dirt", "ethereal:dry_dirt"},
		min_light = 0,
		max_light = 15,
		chance = 6000,
		active_object_count = 2,
		min_height = 0,
		day_toggle = false
	})


	mobs:spawn({
		name = "specialblocks:sp",
		nodes = {"default:dirt_with_grass", "ethereal:gray_dirt", "ethereal:dry_dirt"},
		min_light = 0,
		max_light = 15,
		chance = 7000,
		active_object_count = 2,
		min_height = 0,
		day_toggle = false
	})




mobs:register_mob("mobs_monster:delusоnеr", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
   nametag = "førbiddеn delusioner",
  infotext = "tue",
	reach = 4,
	damage = 5,
	hp_min = 20,
	hp_max = 1000,
	armor = 100,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	textures = {
		{"default_obsidian.png^mobs_meat_raw.png^mobs_blood.png^blacc.png"},
		{"character_37.png^mobs_blood.png^blacc.png"}
	},
	makes_footstep_sound = true,
	sounds = {
		random = "24",
     attack = "spooky_noise.10",
	},
	walk_velocity = 2,
	run_velocity = 19,
	jump_height = 8,
	stepheight = 9,
	floats = 0,
	view_range = 666,
	drops = {
		{name = "util_commands:superapple", chance = 2, min = 1, max = 2},
		{name =  "ignore", chance = 3, min = 1, max = 2},
		{name = "default:stone_with_mese", chance = 4, min = 1, max = 7}
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 40,
		run_end = 63,
		punch_start = 40,
		punch_end = 63,
	}
})


mobs:register_mob("specialblocks:sp", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
   nametag = "VØID advisør",
  infotext = "tue",
	reach = 7,
	damage = 5,
	hp_min = 20,
	hp_max = 100,
	armor = 90,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "mesh",
	mesh = "mobs_dungeon_master.b3d",
	textures = {
		{"456gy.png^mobs_blood.png^blacc.png"},
		{"123gy.png^mobs_blood.png^blacc.png"}
	},
	makes_footstep_sound = true,
	sounds = {
		random = "distortedtrumpets",
     attack = "24",
	},
	walk_velocity = 2,
	run_velocity = 6,
	jump_height = 8,
	stepheight = 9,
	floats = 2,
	view_range = 666,
	drops = {
		{name = "default:dirt_with_grass_footsteps", chance = 2, min = 1, max = 1},
		{name =  "default:noclip_glass", chance = 3, min = 1, max = 2},
		{name = "default:goldblock", chance = 4, min = 3, max = 7}
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 40,
		run_end = 63,
		punch_start = 40,
		punch_end = 63,
	}
})

mobs:spawn({
	name = "specialblocks:sр",
	nodes = {"default:placeholder"},
	max_light = 15,
  min_light = 0,
	chance = 60,
	active_object_count = 1,
	max_height = 222,
})


-- Define the messages
local messages = {
    "V     Ø        I           D",
    "due to a superportal, the server may lag/crash because the portal may conflict with things.                       🔥🦅💯💯                      10.0M",
    "WARNING: SUPERPORTAL CURRENTLY OPEN!                                          ▪︎",
    "UGX REALMS LEGACY will not be overtaken by them!",
    "WARNING! WARNING! ANYONE WHO IS CURRENTLY PLAYING: A SUPERPORTAL HAS OPENED AND CAUSED OUR TEXTURES TO GO HAYWIRE, BRINGING US BACK TO MINETEST DELTATEST!",
    "BEWARE OF FORBIDDEN DELUSОNЕRS AND VOID HARVESTERS!",
    "WARNING: TEXTURES ALTERED BY UNKNOWN SOURCE",
    "stay calm, don't panic, try to survive",
    "AUTOMATIC PORTAL DETERRENT SYSTEM ACTIVE!",
    "➡️stay safe and good luck.     "
}

-- Define the fixed message for 1 hour 30 minutes
local fixed_message = "V Ø I D  H A R V E S T E R"

-- Timer for ten-minute interval
local ten_minute_timer = 0

minetest.register_globalstep(function(dtime)
    ten_minute_timer = ten_minute_timer + dtime
    if ten_minute_timer >= 600 then  -- 600 seconds = 10 minutes
        -- Reset the timer
        ten_minute_timer = 0

        -- Play a noise to all players
        minetest.sound_play("message10", {
            gain = 1.0,
        })

        -- Select a random message
        local random_message = messages[math.random(#messages)]

        -- Send the random message to all players
        minetest.chat_send_all(random_message)
    end
end)

-- Timer for 1 hour 30 minutes interval
local hour_30_minute_timer = 0

minetest.register_globalstep(function(dtime)
    hour_30_minute_timer = hour_30_minute_timer + dtime
    if hour_30_minute_timer >= 5400 then  -- 5400 seconds = 1 hour 30 minutes
        -- Reset the timer
        hour_30_minute_timer = 0

        -- Play a noise to all players
        minetest.sound_play("phantom", {
            gain = 1.0,
        })

        -- Send the fixed message to all players
        local fixed_message = "V Ø I Đ    H A Я V S T E R"
        minetest.chat_send_all(fixed_message)

        -- Get list of connected players
        local players = minetest.get_connected_players()
        local num_players = #players

        if num_players < 2 then
            -- Generate a random position within the specified bounds
            local pos = {
                x = math.random(-666, 666),
                y = math.random(0, 100),
                z = math.random(-666, 666)
            }

            -- Spawn the entity at the random position
            minetest.add_entity(pos, "specialblocks:sр")
        else
            -- Choose a random player
            local player = players[math.random(num_players)]
            local player_pos = player:get_pos()

            -- Generate a position 10 blocks away from the player
            local offset = 10
            local spawn_pos = {
                x = player_pos.x + math.random(-offset, offset),
                y = player_pos.y + math.random(-offset, offset),
                z = player_pos.z + math.random(-offset, offset)
            }

            -- Spawn the entity near the random player
            minetest.add_entity(spawn_pos, "specialblocks:sр")
        end
    end
end)



-- Register the respawn callback
minetest.register_on_respawnplayer(function(player)
    -- Play the sound to the player
    minetest.sound_play("soundstuff_mono", {
        to_player = player:get_player_name(),
        gain = 1.0,
    })

    -- Send a chat message to the player
    minetest.chat_send_player(player:get_player_name(), "Respawned successfully")

    return true
end)
-- Track server start time
local server_start_time = os.time()
local max_lag = 0.666

-- Function to calculate uptime
local function calculate_uptime()
    local current_time = os.time()
    local uptime_seconds = current_time - server_start_time

    local days = math.floor(uptime_seconds / 86400)
    uptime_seconds = uptime_seconds % 86400
    local hours = math.floor(uptime_seconds / 3600)
    uptime_seconds = uptime_seconds % 3600
    local minutes = math.floor(uptime_seconds / 60)
    local seconds = uptime_seconds % 60

    return string.format("%d d, %02d:%02d:%02d", days, hours, minutes, seconds)
end

-- Function to get online players
local function get_online_players()
    local players = minetest.get_connected_players()
    local player_names = {}
    for _, player in ipairs(players) do
        table.insert(player_names, player:get_player_name())
    end
    return table.concat(player_names, ", ")
end

-- Function to send join message to player
local function send_join_message(player)
    local uptime = calculate_uptime()
    local online_players = get_online_players()

    local version_message = string.format("# Server: version 0.4.4_4 | game: minetest DELTA | uptime: %s | max lag: 0.666s | clients: %s", uptime, online_players)
    local warning_message = minetest.colorize("#FF0000", "# Server: WARNING: SUPERPORTAL CURRENTLY OPEN, TEXTURES HAVE BEEN ALTERED BY AN UNKNOWN SOURCE.")

    minetest.chat_send_player(player:get_player_name(), version_message)
    minetest.chat_send_player(player:get_player_name(), warning_message)
end

-- Register callback for player join
minetest.register_on_joinplayer(function(player)
    send_join_message(player)
end)


minetest.register_on_dieplayer(function(player)
	local pos = player:getpos();
	minetest.add_item(pos, "blood")
end)

-- Register the blood item
minetest.register_craftitem(":blood", {
    description = "Blood",
    inventory_image = "mobs_blood.png",
})

minetest.register_node(":specialblocks:blood_block", {
    description = "Blood Block",
    tiles = {"mobs_meat_raw_top.png^mobs_blood.png"},
    groups = {crumbly = 3, oddly_breakable_by_hand = 3},
    on_use = minetest.item_eat(2), -- The block is edible and restores 4 HP
})

-- Define the craft recipe for the blood block
minetest.register_craft({
    output = "specialblocks:blood_block",
    recipe = {
        {"blood", "blood", "blood"},
        {"blood", "blood", "blood"},
        {"blood", "blood", "blood"},
    }
})

--sounds and weird_stuff
local sounds = true
local weird_stuff = true

minetest.register_globalstep(function()
	if math.random(1,1000) == 8 and sounds then
		local sound = math.random(1,4)
		minetest.sound_play(sound,
		{gain = 0.4, max_hear_distance = 1, loop = false})
	end

	if weird_stuff and math.random(1, 10000) == 1 then
		if math.random(1,4) == 1 then
			minetest.chat_send_all("01010110 01001111 01001001 01000100")
		else
			minetest.chat_send_all(". _*____")
			minetest.chat_send_all(".|    ::;  | ")
			minetest.chat_send_all(".|Oo  oO|")
			minetest.chat_send_all(". | ||' |")
			minetest.chat_send_all(".  |#||| ")
		end
	end
end)


mobs:register_mob("mobs_monster:worker", {
	type = "monster",
	passive = false,
	damage = 300,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 5,
	attacks_monsters = false,
	hp_min = 1000,
	hp_max = 2000,
	armor = 300,
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "character.b3d",
	textures = {
		{"character2.png"}, -- skin by starninjas
	},
	makes_footstep_sound = true,
	sounds = {},
	walk_velocity = 5,
	run_velocity = 12,
	stepheight = 1.1,
	fear_height = 2,
	jump = true,
	drops = {
		{name = "mobs:mese_block", chance = 1, min = 2, max = 2},
		{name = "default:diamond", chance = 1, min = 8, max = 18},
		{name = "default:diamond_block", chance = 2, min = 1, max = 4},
	},
	water_damage = 1,
	lava_damage = 3,
	light_damage = 0,
	view_range = 50,
	-- model animation
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	}
})
-- register spawn egg


-- compatibility


mobs:register_mob("mobs_monster:voidFiend", {
   type = "npc",
   passive = false,
   attack_monsters = true,
   attack_npcs = false,
   damage = 8,
   reach = 3,
   attack_type = "shoot",
   shoot_interval = 2.5,
   arrow = "mobs_monster:arrow",
   shoot_offset = 1,
   hp_min = 30,
   hp_max = 45,
   armor = 80,
   collisionbox = {-0.9, -0.2, -0.9, 0.9, 1.5, 0.9},
   visual = "mesh",
   mesh = "cacodemon.b3d",
   textures = {
      {"hoi.png"},
      {"h0i.png"},
   },
   blood_amount = 80,
   blood_texture = "sun.png",
   backface_culling = false,
   use_texture_alpha = true,
   visual_size = {x=2, y=2},
   makes_footstep_sound = true,
   walk_velocity = 3,
   run_velocity = 5,
   jump = true,
   fly = true,
   fall_speed = 0,
   stepheight = 10,
   water_damage = 2,
   lava_damage = 0,
   light_damage = 0,
   view_range = 20,
   animation = {
      speed_normal = 10,
      speed_run = 20,
      walk_start = 1,
      walk_end = 20,
      stand_start = 1,
      stand_end = 20,
      run_start = 1,
      run_end = 20,
      shoot_start = 20,
      shoot_end = 40,
   },
follow = {
		"farming:wheat", "default:grass_1", "farming:barley",
		"farming:oat", "farming:rye"
	},
	view_range = 8,
	replace_rate = 10,
	replace_what = {
		{"group:grass", "air", 0},
		{"default:dirt_with_grass", "default:dirt_with_grass_footsteps", -1}
	},
--	stay_near = {{"farming:straw", "group:grass"}, 10},

on_rightclick = function(self, clicker)

		-- feed or tame
		if mobs:feed_tame(self, clicker, 8, true, true) then

			-- if fed 7x wheat or grass then cow can be milked again
			if self.food and self.food > 6 then
				self.gotten = false
			end

			return
		end

		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 60, false, nil) then return end

		local tool = clicker:get_wielded_item()
		local name = clicker:get_player_name()
		local item = tool:get_name()

		-- milk cow with empty bucket
		if item == "bucket:bucket_empty"
		or item == "wooden_bucket:bucket_wood_empty"
		or item == "bucket_wooden:bucket_empty" then

			--if self.gotten == true
			if self.child == true then
				return
			end

			if self.gotten == true then

				minetest.chat_send_player(name, ("void fiend already liquided!"))

				return
			end

			local inv = clicker:get_inventory()

			tool:take_item()
			clicker:set_wielded_item(tool)

			-- which bucket are we using
			local ret_item = "city_block:bucket_pitch"

			if item == "wooden_bucket:bucket_wood_empty"
			or item == "bucket_wooden:bucket_empty" then
				ret_item = "city_block:bucket_pitch"
			end

			if inv:room_for_item("main", {name = ret_item}) then
				clicker:get_inventory():add_item("main", ret_item)
			else
				local pos = self.object:get_pos()

				pos.y = pos.y + 0.5

				minetest.add_item(pos, {name = ret_item})
			end

			self.gotten = true -- milked

			return
		end
	end,

	on_replace = function(self, pos, oldnode, newnode)

		self.food = (self.food or 0) + 1

		-- if cow replaces 8x grass then it can be milked again
		if self.food >= 8 then
			self.food = 0
			self.gotten = false
		end
	end
})




	mobs:spawn({
		name = "mobs_monster:voidFiend",
		nodes = {"default:dirt_with_grass", "ethereal:green_dirt"},
		neighbors = {"group:grass"},
		min_light = 14,
		interval = 60,
		chance = 9000,
		min_height = 5,
		max_height = 200,
		day_toggle = true
	})



mobs:register_egg("mobs_monster:voidFiend", ("void fiend"), "h0i.png")




mobs:register_mob("mobs:еntitу", {
	type = "monster",
	passive = false,
	damage = 6553509392928288291923,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 10, -- shoot for 10 seconds
	dogshoot_count2_max = 1, -- dogfight for 2 seconds
	reach = 2,
	shoot_interval = 0.1,
	arrow = "mobs_monster:item",
	friendly_fire = false,
	shoot_offset = 0,
	hp_min = 65420,
	hp_max = 65535,
	armor = 1,
   nametag = "VØID ADMINISTRATOR",
  visual_size = {x=10, y=10},
	collisionbox = {-4.4, -4, -4.2, 4.72, 4.2, 4.2},
	visual = "sprite",
	textures = {
		{"chaos.png"},
		{"yikes.png^chaos.png"},
		{"0n0.png^yikes.png^0n0.png^chaos.png"}
	},
	makes_footstep_sound = true,
	sounds = {
		random = "distortedtrumpets",
		shoot_attack = "imagetoaudio"
	},
	walk_velocity = 15,
	run_velocity = 22,
	jump = true,
	view_range = 1500,
	drops = {
		{name = "voidsword", chance = 1, min = 1, max = 1},
	},
   water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 200
})




minetest.register_tool(":shovel", {
	description = ("Shovel"),
	inventory_image = "shovel.png",
	wield_image = "shovel.png",
	tool_capabilities = {
		full_punch_interval = 1.1,
		max_drop_level=1,
		groupcaps={
			crumbly = {times={[1]=1.65, [2]=1.05, [3]=0.45}, uses=10, maxlevel=4},
		},
		damage_groups = {fleshy=20},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {shovel = 1}
})

minetest.register_node(":texture_box", {
	tiles = {"texture_box.png"},
  use_texture_alpha = "clip",
	groups = {oddly_breakable_by_hand = 2},
})

minetest.register_node(":base", {
	tiles = {"mastered-base.png"},
  use_texture_alpha = "clip",
	groups = {oddly_breakable_by_hand = 2},
})

minetest.register_node(":error", {
	drawtype = "mesh",
	mesh = "error.obj",
	tiles = {"unknown_node.png^[colorize:#ff0000:255"},
	pointable = true,
	walkable = false,
})


mobs:register_mob("mobs_monster:bаt", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 2,
	damage = 3,
	hp_min = 9,
	hp_max = 32,
	armor = 100,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	textures = {"voidbat.png"},
	spritediv = {x = 1, y = 1},
	visual_size = {x=2, y=2},
	makes_footstep_sound = false,
	sounds = {
		random = "1",
	},
	walk_velocity = 2,
	run_velocity = 4,
	view_range = 50,
	jump = true,
	drops = {
		{name = "default:stone", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 10,
	floats = 100,
})


minetest.register_tool(":voidsword", {
    inventory_image = "demon_blade.png",
    tool_capabilities = {
        full_punch_interval = 3,
        max_drop_level = 5,
        groupcaps = {
            snappy = {
                times = {[2] = 0.1, [3] = 0.1},
                uses = 2000,
                maxlevel = 3,
            },
        },
        damage_groups = {fleshy = 666},
    },
    wield_scale = {x = 2, y = 2, z = 1},  -- Adjust the wield scale as needed
})

minetest.register_tool(":bladehand", {
    inventory_image = "blade_hand.png",
    tool_capabilities = {
        full_punch_interval = 0.5,
        max_drop_level = 5,
        groupcaps = {
            choppy = {
                times = {[2] = 0.1, [3] = 0.1},
                uses = 2222,
                maxlevel = 3,
            },
        },
        damage_groups = {fleshy = 69},
    },
    wield_scale = {x = 1.5, y = 1.5, z = 0.9},  -- Adjust the wield scale as needed
})




minetest.register_node(":bloodpuddle", {
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	tiles = { "bloodp.png" },


	walkable = false,
	groups = { dig_immediate = 3 },
	sunlight_propagates = true,
})

minetest.register_node(":ugx:shop", {
    description = "shop",
    drawtype = "allfaces",
    visual_scale = 6.5,
    tiles = {"sh0p.png"},
    paramtype = "light",
    sunlight_propagates = true,
    is_ground_content = false,
    groups = {cracky = 3, oddly_breakable_by_hand = 3},
    sounds = default.node_sound_glass_defaults(),
})


-- dev/init.lua

-- Function to play the sound every hour
local function play_hourly_sound()
    for _, player in ipairs(minetest.get_connected_players()) do
        minetest.sound_play("trans6", {
            to_player = player:get_player_name(),
            gain = 1.0,
        })
    end
end

-- Timer to track elapsed time
local timer = 0
local interval = 3600  -- One hour in seconds

minetest.register_globalstep(function(dtime)
    timer = timer + dtime
    if timer >= interval then
        timer = timer - interval
        play_hourly_sound()
    end
end)


-- dev/init.lua

-- Register the plantlike node
minetest.register_node(":void", {
    drawtype = "plantlike",
    tiles = {"altard.png"},
    inventory_image = "altard.png",
    wield_image = "altard.png",
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {unbreakable=1, flora=1, attached_node=1, not_in_creative_inventory=1},
})

local function spawn_entities(pos)
    local entities = {
        "specialblocks:sp",
        "mobs_monster:delusоnеr",
        "mobs_monster:bаt",
        "mobs_monster:worker"
    }

    for _, entity in ipairs(entities) do
        minetest.add_entity(pos, entity)
    end
end

-- Register an ABM to spawn entities every 30 seconds
minetest.register_abm({
    nodenames = {"void"},
    interval = 30,  -- 30 seconds
    chance = 1,     -- Always trigger
    action = function(pos, node)
        spawn_entities(pos)
    end,
})
