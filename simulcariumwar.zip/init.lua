awards.register_award("award_superlibrary", {
		title = ("Big Library"),
		description = ("Craft 70 bookshelves."),
		icon = "protect.png^awards_little_library.png^default_book.png^protect.png",
		difficulty = 0.2,
		trigger = {
			type = "craft",
			item = "default:bookshelf",
			target = 70
		}
	})


awards.register_award("awards_gunman", {
		title = ("Gun Gotten"),
		description = ("Craft a Gun"),
		icon = "detect.png",
		difficulty = 0.2,
		trigger = {
			type = "craft",
			item = "paintball:paintball_gun",
			target = 1
		}
	})


awards.register_award("award_cryolava", {
		title = ("CryoDeath"),
		description = ("Die in Cryolava"),
		icon = "cryodeth.png"
	})
	awards.register_on_death(function(player,data)
		local pos = player:get_pos()
		if pos and minetest.find_node_near(pos, 5, "caverealms:cryolava_source") ~= nil then
			return "award_cryolava"
		end
		return nil
	end)

	-- Junglebaby
	awards.register_award("award_doomcave", {
		title = ("Dungeon Master Cave discoverer"),
		description = ("Dig 10 Hot Cobble"),
		icon = "dmcave.png",
		difficulty = 0.05,
		trigger = {
			type = "dig",
			node = "caverealms:hot_cobble",
			target = 10
		}
	})



	-- Junglebaby
	awards.register_award("award_watah", {
		title = ("Water Lover"),
		description = ("place 100 Water source blocks."),
		icon = "heart.png^watuh.png",
		difficulty = 0.05,
		trigger = {
			type = "place",
			node = "default:water_source",
			target = 100
		}
	})

awards.register_award("award_death1",{
	title = "First Death. do /awards to see all achievements. ",
	description = "You get this when you die. do /awards to see all achievements.  \nDeath does not matter, you have more lives than a cat",
	icon = "bones_front.png",
	trigger={
		type="death",
		target=1,
	},
})

	-- Junglebaby
	awards.register_award("award_oops", {
		title = ("Uhh this was not intended to happen"),
		description = ("place a unknown node"),
     secret = true,
		icon = "todo.png",
		difficulty = 0.05,
		trigger = {
			type = "place",
			node = "util_commands:unkown",
			target = 1
		}
	})

awards.register_award("award_noise", {
		title = ("Noise Maker"),
		description = ("Craft 7 party horns."),
		icon = "noise.png",
		difficulty = 0.2,
		trigger = {
			type = "craft",
			item = "ugx:party_horn",
			target = 7
		}
	})

	-- Junglebaby
	awards.register_award("awards_arsenal", {
		title = ("Arsenal Maker"),
		description = ("Craft 222 Bullets"),
		icon = "break.png",
		difficulty = 0.2,
		trigger = {
			type = "craft",
			item = "paintball:paintball",
			target = 222
		}
	})

awards.register_award("award_betterthantorch",{
	title = "Better Than Torch",
	description = "Place a wooden lightbox",
	icon = "xdecor_wooden_lightbox.png",
	trigger={
		type="place",
		node="xdecor:wooden_lightbox",
		target=1,
	},
})


awards.register_award("award_drown", {
		title = ("Drowned."),
		description = ("Drown."),
		icon = "drown.png"
	})
	awards.register_on_death(function(player,data)
		local pos = player:get_pos()
		if pos and minetest.find_node_near(pos, 2, "default:water_source") ~= nil then
			return "award_drown"
		end
		return nil
	end)



awards.register_award("award_firstlight",{
	title = "First Light",
	description = "Place a torch",
	icon = "corona.png",
	trigger={
		type="place",
		node="default:torch",
		target=1,
	},
})

awards.register_award("award_fiery_death", {
		title = ("Fiery Death"),
		description = ("Burn to death in lava."),
		icon = "dedfire.png"
	})
	awards.register_on_death(function(player,data)
		local pos = player:get_pos()
		if pos and minetest.find_node_near(pos, 2, "default:lava_source") ~= nil then
			return "award_fiery_death"
		end
		return nil
	end)



awards.register_award("award_forgotten_death", {
		title = ("Forgotten Death"),
		description = ("Die inside a dungeon with mossy cobble"),
		icon = "brick_dark_skeleton.png"
	})
	awards.register_on_death(function(player,data)
		local pos = player:get_pos()
		if pos and minetest.find_node_near(pos, 5, "default:mossycobble") ~= nil then
			return "award_forgotten_death"
		end
		return nil
	end)


awards.register_award("awards_supersword", {
		title = ("Super Sword"),
		description = ("make a League Sword."),
		icon = "supersword.png",
		difficulty = 0.2,
		trigger = {
			type = "craft",
			item = "basetools:bl_sword",
			target = 1
		}
	})

awards.register_award("award_cursed", {
		title = ("cursed"),
		description = ("Eat a Blood Block"),
		icon = "skull.png",
     secret = true,
		trigger = {
			type = "eat",
			item = "specialblocks:blood_block",
			target = 1
		}
	})

	-- Junglebaby
	awards.register_award("award_see", {
		title = ("See"),
		description = ("Place 20 TV cubes"),
		icon = "see.png",
		difficulty = 0.05,
		trigger = {
			type = "place",
			node = "xdecor:tv_cube",
			target = 20
		}
	})


awards.register_award("award_deathcap", {
		title = ("Deadly Shrooms"),
		description = ("Eat 11 red mushrooms."),
		icon = "deathcap.png",
		trigger = {
			type = "eat",
			item = "flowers:mushroom_red",
			target = 11
		}
	})

awards.register_award("awards_telefruit", {
		title = ("First Teleport Fruit"),
		description = ("Craft a teleport fruit"),
		icon = "teley.png",
		difficulty = 0.2,
		trigger = {
			type = "craft",
			item = "ugx:teleport_fruit",
			target = 1,
		}
	})

	-- Junglebaby
	awards.register_award("award_superice", {
		title = ("Obsessed with Blue Packed ice"),
		description = ("Place 100 blue packed ice blocks."),
		icon = "icelover.png",
		difficulty = 10,
		trigger = {
			type = "place",
			node = "ugx:blue_packed_ice",
			target = 100
		}
	})


awards.register_award("award_666", {
		title = ("??????????????????"),
		description = ("??????????????????????????????"),
		icon = "him.png",
     secret = true
	})
	awards.register_on_death(function(player,data)
		local pos = player:get_pos()
		if pos and minetest.find_node_near(pos, 30, "player_death_mod:death666_you_are_deadnowrunbeforeitfindsyouandkillsyou666___error") ~= nil then
			return "award_666"
		end
		return nil
	end)

awards.register_award("award_addict", {
		title = ("Teleport Fruit ADDICT"),
		description = ("craft 100 teleport fruits"),
		icon = "teleaddict.png",
		trigger = {
			type = "craft",
			item = "ugx:teleport_fruit",
			target = 100
		}
	})




-- Junglebaby
	awards.register_award("award_buff", {
		title = ("Strong"),
		description = ("Dig 111 obsidian."),
		icon = "deconstruct.png",
		difficulty = 0.5,
		trigger = {
			type = "dig",
			node = "default:obsidian",
			target = 111
		}
	})


awards.register_award("awards_teleport", {
		title = ("Teleportation Discoverer"),
		description = ("Craft a teleporter"),
		icon = "teleport.png",
		difficulty = 0.2,
		trigger = {
			type = "craft",
			item = "teleporters:teleporter",
			target = 1
		}
	})



awards.register_award("awards_bomber", {
		title = ("BomberMan"),
		description = ("Craft 99 TNT."),
		icon = "terrorist.png",
		difficulty = 0.2,
		trigger = {
			type = "craft",
			item = "tnt:tnt",
			target = 99
		}
	})

awards.register_award("awards_protector", {
		title = ("small protection"),
		description = ("Craft 7 protector blocks"),
		icon = "protect.png",
		difficulty = 0.2,
		trigger = {
			type = "craft",
			item = "protector:protect",
			target = 7
		}
	})


awards.register_award("awards_infoman", {
		title = ("Info Lover"),
		description = ("Craft 7 server guides."),
		icon = "info.png",
		difficulty = 0.1,
		trigger = {
			type = "craft",
			item = "serverguide:book",
			target = 7
		}
	})


awards.register_award("awards_heli", {
		title = ("Invent Helicopter"),
		description = ("make a helicopter"),
		icon = "helicopter_heli.png",
		difficulty = 0.2,
		trigger = {
			type = "craft",
			item = "helicopter:heli",
			target = 1
		}
	})


awards.register_award("award_death_zot", {
		title = ("Painful Death"),
		description = ("Die in Liquid Pain Source"),
		icon = "painzot.png"
	})
	awards.register_on_death(function(player,data)
		local pos = player:get_pos()
		if pos and minetest.find_node_near(pos, 5, "specialblocks:liquid_pain_source") ~= nil then
			return "award_death_zot"
		end
		return nil
	end)



awards.register_award("awards_flight", {
		title = ("Flight"),
		description = ("Craft a privellge shop"),
		icon = "flight.png",
		difficulty = 0.2,
		trigger = {
			type = "craft",
			item = "shop:privs",
			target = 1
		}
	})

awards.register_award("awards_iceman", {
		title = ("Ice Lover"),
		description = ("Craft 150 blue ice"),
		icon = "iceman.png",
		difficulty = 0.2,
		trigger = {
			type = "craft",
			item = "ugx:blue_ice",
			target = 150
		}
	})

	-- Junglebaby
	awards.register_award("award_sad", {
		title = ("corpse collector"),
		description = ("dig 100 bones"),
		icon = "sed.png",
		difficulty = 0.05,
		trigger = {
			type = "dig",
			node = "bones:bones",
			target = 100
		}
	})

awards.register_award("awards_defender", {
		title = ("Defender"),
		description = ("Craft 70 protector blocks."),
		icon = "defence.png",
		difficulty = 0.2,
		trigger = {
			type = "craft",
			item = "protector:protect",
			target = 70
		}
	})



awards.register_award("awards_protester", {
		title = ("Protester"),
		description = ("Craft 99 cobble molotovs."),
		icon = "shatter.png",
		difficulty = 0.2,
		trigger = {
			type = "craft",
			item = "ugx:zcobblebomb",
			target = 99,
		}
	})

awards.register_award("award_death_banishment", {
	title = ("Death Banishment"),
	description = ("Die outside of 3000 X coordinates."),
   secret = true,
    icon = "banishment.png"
})
awards.register_on_death(function(player,data)
	local pos = player:get_pos()
	if pos and pos.x > 3000 then
		return "award_death_banishment"
	end
	return nil
end)

		awards.register_award("award_sleeper",{
		title = ("Sleeper"),
		description = ("Craft 50 beds."),
		icon = "sleeper.png",
		difficulty = 0.9,
		trigger = {
			type = "craft",
			item = "beds:bed_bottom",
			target = 50
		}
	})

--3D Armor awards (in the future i want to add achievements with multiple item requirements. just don't know how to atm)
--Trying to be a Tree Monster
if minetest.get_modpath("3d_armor") then
		awards.register_award("award_armor_wood",{
		title = ("Trying to be a Tree"),
		description = ("Craft 4 wooden chestplates."),
		icon = "wood21.png",
		difficulty = 0.03,
		trigger = {
			type = "craft",
			item = "3d_armor:chestplate_wood",
			target = 4
		}
	})
--Jumbo Cactus
		awards.register_award("award_armor_cactus",{
		title = ("Jumbo Cactus"),
		description = ("Craft 4 cactus chestplates."),
		icon = "shields_inv_shield_cactus.png",
		difficulty = 0.03,
		trigger = {
			type = "craft",
			item = "3d_armor:chestplate_cactus",
			target = 4
		}
	})
--Iron Man
		awards.register_award("award_armor_steel",{
		title = ("Iron Man"),
		description = ("Craft 4 steel chestplates."),
		icon = "ironman.png",
		difficulty = 0.5,
		trigger = {
			type = "craft",
			item = "3d_armor:chestplate_iron",
			target = 4
		}
	})
--Comedy Gold
		awards.register_award("award_armor_gold",{
		title = ("Comedy Gold"),
		description = ("Craft 4 gold chestplates."),
		icon = "shields_inv_shield_gold.png",
		difficulty = 0.9,
		trigger = {
			type = "craft",
			item = "3d_armor:chestplate_gold",
			target = 4
		}
	})
--Covered in Diamonds
		awards.register_award("award_armor_diamond",{
		title = ("Covered in Diamonds"),
		description = ("Craft 4 diamond chestplates."),
		icon = "shields_inv_shield_diamond.png",
		difficulty = 0.9,
		trigger = {
			type = "craft",
			item = "3d_armor:chestplate_diamond",
			target = 4
		}
	})
--Upgrades, people. Upgrades.	
		awards.register_award("award_shield_enhanced",{
		title = ("Upgrades, people. Upgrades."),
		description = ("Enhance your shield using steel ingots."),
		icon = "upgrades.png",
		difficulty = 0.5,
		trigger = {
			type = "craft",
			item = "shields:shield_enhanced_wood",
			target = 1
		}
	})	

end


--Bonemeal Awards
--Bona Fide
if minetest.get_modpath("bonemeal") then
		awards.register_award("award_bonemeal",{
		title = ("Bona Fide"),
		description = ("Craft 50 bonemeal."),
		icon = "bonemeal_item.png",
		difficulty = 0.6,
		trigger = {
			type = "craft",
			item = "bonemeal:bonemeal",
			target = 50
		}
	})
--Master Composter	
		awards.register_award("award_fertiliser",{
		title = ("Master Composter"),
		description = ("Craft 100 fertiliser."),
		icon = "bonemeal_fertiliser.png",
		difficulty = 0.6,
		trigger = {
			type = "craft",
			item = "bonemeal:fertiliser",
			target = 100
		}
	})
--Made of Seeds	
		awards.register_award("award_mulch",{
		title = ("Made of Seeds"),
		description = ("Craft 50 mulch."),
		icon = "bonemeal_mulch.png",
		difficulty = 0.6,
		trigger = {
			type = "craft",
			item = "bonemeal:mulch",
			target = 50
		}
	})
end