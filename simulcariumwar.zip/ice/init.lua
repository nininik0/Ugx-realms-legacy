mobs:register_mob("mobs:роs_", {
	type = "monster",
	hp_min = 30,	hp_max = 400,
	collisionbox = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
	visual = "sprite",
	visual_size = {x = 6.5, y = 6.5},
	textures = {"simdrop.png"},
	blood_texture = "iceheart.png",
	makes_footstep_sound = false,
  nametag = "S I M U L C A R A  D R Ø P P E R",
	damage = 2222,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 12, -- shoot for 12 seconds
	dogshoot_count2_max = 1, -- dogfight for 1 second bruh
	reach = 6,
	shoot_interval = 0.7,
	arrow = "mobs_monster:item",
	friendly_fire = false,
	shoot_offset = 0,
	passive = false,
	walk_velocity = 7,
	run_velocity = 8,
drops = {
		{name = "icerune", chance = 0.5, min = 0, max = 1},
	},
	jump_chance = 3,
	jump_height = 10,
   fly = true,
	fly_in={"air", "default:water_source", "default:river_water_source", "default:river_water_flowing", "maptools:buildable_to_light", "maptools:darkair", "maptools:lightbulb"},
	floats = true,
	fall_speed = 0,
	regen= 1,
	armor = 90,
	view_range = 150,
	on_die = function(self, pos)
		local num = math.random(4, 8)
		for i=1,num do
			minetest.add_entity({x=pos.x + math.random(-2, 2), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "mobs_monster:bat")
		end
	end,
	drawtype = "front",
	water_damage = 10,
	lava_damage = 0,
	light_damage = 0,
  footstep = "mobs_fireball",
})


mobs:register_mob("mobs_monster:bat", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
  blood_texture = "default_ice.png",
	damage = 33,
	hp_min = 102,
	hp_max = 155,
	armor = 100,
	collisionbox = {-1.1, -1.1, -1.4, 1.4, 1.5, 1.4},
	visual = "upright_sprite",
	textures = {"simbat.png"},
	spritediv = {x = 1, y = 1},
	visual_size = {x=3.3, y=3.3},
	makes_footstep_sound = false,
	sounds = {
		random = "default_ice_footstep",
	},
	walk_velocity = 2,
	run_velocity = 4,
	view_range = 1000,
	jump = true,
	drops = {
		{name = "crackeddarkice", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 10,
	floats = 100,
})

mobs:register_mob("mobs_animal:gigabat", {
	type = "npc",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
    follow = {
		"default:dirt", "ugx:teleport_fruit", "ugx:blue_packed_ice",
		"default:stone", "farming:wheat"
	},
	damage = 40,
	hp_min = 155,
	hp_max = 172,
	armor = 99,
	collisionbox = {-1.1, -1.1, -1.4, 1.4, 1.5, 1.4},
	visual = "upright_sprite",
	textures = {"gigabat.png"},
	spritediv = {x = 1, y = 1},
	visual_size = {x=3.4, y=3.4},
	makes_footstep_sound = false,
	sounds = {
		random = "mobs_fireball",
	},
	walk_velocity = 3,
	run_velocity = 7,
	view_range = 100,
	jump = true,
	drops = {
		{name = "default:dirt_with_snow", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 10,
	floats = 100,
    on_rightclick = function(self, clicker)

		if mobs:feed_tame(self, clicker, 20, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end
})


mobs:register_egg("mobs_animal:gigabat", ("Giga Bat"), "gigabat.png", 1)





mobs:register_mob("mobs_monster:iceservant", {
	type = "npc",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 2,
	damage = 9,
	hp_min = 80,
	hp_max = 100,
	armor = 100,
  follow = {
		"default:ice", "ugx:blue_ice", "ugx:blue_packed_ice",
		"farming:barley", "farming:corn"
	},
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=2, y=2},
	textures = {
		"f.png",
		"r.png",
	},
	makes_footstep_sound = true,
	sounds = {
		random = "wind",
	},
	walk_velocity = 3,
	run_velocity = 6,
	view_range = 50,
	jump = true,
	drops = {
		{name = "iceheart", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 4,
	replace_rate = 5,
	replace_what = {"default:dirt_with_grass"},
	replace_with = "default:dirt_with_grass_footsteps",
	replace_offset = -1,
	floats = 1,
    on_rightclick = function(self, clicker)

		if mobs:feed_tame(self, clicker, 20, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end
})


mobs:register_egg("mobs_monster:iceservant", ("Ice Servant"), "f.png", 1)



-- Utility function to register colorized bricks
local function register_brick(name, base_texture, color)
	minetest.register_node("ice:" .. name .. "_bricks", {
		description = name:gsub("^%l", string.upper) .. " Bricks",
		tiles = {base_texture .. "^[colorize:" .. color},
		is_ground_content = false,
		groups = {cracky = 3, not_cuttable=1},
		sounds = default.node_sound_ice_defaults(),
	})
end

-- Utility function to register colorized ice and packed ice
local function register_ice(name, color, packed_color)
	minetest.register_node("ice:" .. name .. "_ice", {
		description = name:gsub("^%l", string.upper) .. " Ice",
		tiles = {"default_ice.png^[colorize:" .. color},
		paramtype = "light",
		use_texture_alpha = "blend",
		is_ground_content = false,
		groups = {cracky = 3, cools_lava = 1, not_cuttable=1},
		sounds = default.node_sound_ice_defaults(),
	})

	minetest.register_node("ice:packed_" .. name .. "_ice", {
		description = "Packed " .. name:gsub("^%l", string.upper) .. " Ice",
		tiles = {"xdecor_packed_ice.png^[colorize:" .. packed_color},
		paramtype = "light",
		use_texture_alpha = "blend",
		is_ground_content = false,
		groups = {cracky = 3, not_cuttable=1},
		sounds = default.node_sound_ice_defaults(),
	})
end

-- Registering all the colorized bricks
register_brick("snow", "default_stone_brick.png", "white:90")
register_brick("ice", "default_stone_brick.png", "cyan:90")
register_brick("packed_ice", "default_stone_brick.png", "lightblue:90")
register_brick("blue_ice", "default_stone_brick.png", "blue:90")
register_brick("packed_blue_ice", "default_stone_brick.png", "deepskyblue:90")

-- Registering the thin ice pane
minetest.register_node("ice:thin_ice_pane", {
	description = "Thin Ice Pane",
	drawtype = "glasslike_framed",
	tiles = {"caverealms_thin_ice.png^[colorize:cyan:50"},
	paramtype = "light",
	use_texture_alpha = "blend",
	is_ground_content = false,
	groups = {cracky = 3, cools_lava = 1, not_cuttable=1},
	sounds = default.node_sound_glass_defaults(),
})

-- Registering the custom ice blocks
register_ice("green", "green:80", "darkgreen:80")
register_ice("purple", "purple:80", "darkviolet:80")

-- Registering packed snow
minetest.register_node("ice:packed_snow", {
	description = "Packed Snow",
	tiles = {"default_snow.png^[colorize:white:66^default_obsidian_glass.png^[colorize:white:88"},
	is_ground_content = false,
	groups = {cracky = 3, not_cuttable=1},
	sounds = default.node_sound_snow_defaults(),
})

-- Registering the Sapphire Block (retextured diamond block with dark purple-blue color)
minetest.register_node("ice:sapphire_block", {
	description = "Sapphire Block",
	tiles = {"default_diamond_block.png^[colorize:darkviolet:100"},
	is_ground_content = false,
	groups = {cracky = 3, not_cuttable=1},
	sounds = default.node_sound_stone_defaults(),
})



minetest.register_tool(":icerune", {
    inventory_image = "icerune.png",
    on_use = function(itemstack, user, pointed_thing)
        local pos = user:get_pos()
        local range = 30  -- 30 block diameter

        for x = -range, range do
            for y = -range, range do
                for z = -range, range do
                    local target_pos = vector.add(pos, {x=x, y=y, z=z})
                    local node = minetest.get_node(target_pos)

                    if minetest.get_item_group(node.name, "water") > 0 then
                        minetest.set_node(target_pos, {name="crackeddarkice"})
                    elseif minetest.get_item_group(node.name, "soil") > 0 then
                        minetest.set_node(target_pos, {name="crackedlightsnow"})
                    end
                end
            end
        end

        itemstack:add_wear(65535 / 3)  -- Wear out after 3 uses
        return itemstack
    end,
})

minetest.register_craftitem(":iceheart", {
    inventory_image = "iceheart.png",
    on_use = function(itemstack, user, pointed_thing)
        local pos = user:get_pos()
        local radius = 5

        for dx = -radius, radius do
            for dy = -radius, radius do
                for dz = -radius, radius do
                    local p = {x = pos.x + dx, y = pos.y + dy, z = pos.z + dz}
                    
                    -- Check if the position is protected
                    if minetest.is_protected(p, user:get_player_name()) then
                        minetest.chat_send_player(user:get_player_name(), "This area is protected!")
                        return itemstack -- Stop the function here to prevent any changes in protected areas
                    end
                    
                    local node = minetest.get_node(p)

                    if node.name ~= "air" and node.name ~= "ignore" then
                        if math.random(1, 2) == 1 then
                            minetest.set_node(p, {name = "default:ice"})
                        else
                            minetest.set_node(p, {name = "default:snowblock"})
                        end
                    end
                end
            end
        end

        itemstack:take_item()
        return itemstack
    end,
})


-- Register cracked dark ice
minetest.register_node(":crackeddarkice", {
    tiles = {"crackeddarkice.png"},
    is_ground_content = false,
    groups = {cracky = 3, ice = 1},
    sounds = default.node_sound_glass_defaults(),
})

-- Register cracked light snow
minetest.register_node(":crackedlightsnow", {
    tiles = {"crackedlightsnow.png"},
    is_ground_content = false,
    groups = {crumbly = 3, snowy = 1},
    sounds = default.node_sound_snow_defaults(),
})

-- Register dark ice
minetest.register_node(":darkice", {
    tiles = {"darkice.png"},
    is_ground_content = false,
    groups = {cracky = 3, ice = 1},
    sounds = default.node_sound_glass_defaults(),
})

-- Register light snow
minetest.register_node(":lightsnow", {
    tiles = {"lightsnow.png"},
    is_ground_content = false,
    groups = {crumbly = 3, snowy = 1},
    sounds = default.node_sound_snow_defaults(),
})




-- Register Ice Spear
minetest.register_tool("ice:ice_spear", {
    description = "Anti-Void Ice Spear",
    inventory_image = "ice_spear.png",
    wield_scale = {x = 2, y = 2, z = 2},
    tool_capabilities = {
        full_punch_interval = 0.01,
        max_drop_level = 1,
        groupcaps = {
            cracky = {
                times = { [1] = 0.01, [2] = 0.1, [3] = 0.01 },
                uses = 2220,
                maxlevel = 3,
            },
        },
        damage_groups = { fleshy = 27 },
    },
})

-- Register Ice Sword
minetest.register_tool(":icesword", {
    inventory_image = "simsword.png",
    wield_scale = {x=2, y=2, z=2},
    tool_capabilities = {
        full_punch_interval = 0.7,
        max_drop_level = 1,
        groupcaps = {
            snappy = {
                times = {[1]=1.90, [2]=0.70, [3]=0.20},
                uses = 300,
                maxlevel = 3,
            },
        },
        damage_groups = {fleshy=678},
    },
    sound = {breaks = "default_tool_breaks"},
    on_use = function(itemstack, user, pointed_thing)
        if pointed_thing.type == "object" then
            -- Direct hit with the sword
            local target = pointed_thing.ref
            target:punch(user, 1.0, {
                full_punch_interval = 1.0,
                damage_groups = {fleshy=678},
            }, nil)
            -- Apply freezing effect
            local pos = target:get_pos()
            if pos then
                minetest.set_node(pos, {name = "darkice"})
                minetest.sound_play("default_cool_lava", {pos = pos, gain = 1.0})
            end
        elseif pointed_thing.type == "node" then
            -- Slash at a node (optional additional effect)
            local pos = pointed_thing.under
            minetest.set_node(pos, {name = "darkice"})
            minetest.sound_play("default_cool_lava", {pos = pos, gain = 1.0})
        end
        itemstack:add_wear(65535 / 300)  -- 30 uses
        return itemstack
    end,
})


-- Register Plant-like Block
minetest.register_node(":simulcara", {
    drawtype = "plantlike",
    tiles = {"spwn.png"},
    inventory_image = "spwn.png",
    light_source = 3,
    groups = {unbreakable=1},
    walkable = false,
    selection_box = {
        type = "fixed",
        fixed = {-0.3, 0, -0.3, 0.3, 1, 0.3},
    },
})

-- ABM to spawn entities
minetest.register_abm({
    nodenames = {"simulcara"},
    interval = 30.0,  -- every 30 seconds
    chance = 1,
    action = function(pos, node)
        -- Define the entities to spawn
        local entities = {
            "mobs_monster:bat",
            "mobs_monster:worker",
            "specialblocks:sр",
            "mobs:роs_",
            "mobs:icegrunt"
        }

        -- Spawn all entities at the position of the spawner plant
        for _, entity_name in ipairs(entities) do
            minetest.add_entity(pos, entity_name)
        end
    end,
})

-- Register Fan Tool
minetest.register_tool(":ugx:fan", {
    description = "Hand Fan",
    inventory_image = "fan.png", -- Use your fan texture here
    sound = {name = "wind"}, -- Replace with your fan sound effect
    groups = {tool = 1},

    -- Custom functionality when using the tool
    on_use = function(itemstack, user, pointed_thing)
        -- Check if the pointed_thing is a player
        if pointed_thing.type == "node" and user then
            local player_pos = user:get_pos()
            local pos = pointed_thing.under

            -- Play sound effect for players within 5 blocks
            for _, player in ipairs(minetest.get_connected_players()) do
                local p_pos = player:get_pos()
                if vector.distance(player_pos, p_pos) <= 5 then
                    minetest.sound_play("wind", {pos = p_pos, gain = 1.0})
                end
            end

            -- Add tiny wind/dust particles
            for i = 1, 10 do
                local particle_pos = vector.add(player_pos, vector.new(math.random(-1, 1), math.random(0, 1), math.random(-1, 1)))
                minetest.add_particle({
                    pos = particle_pos,
                    velocity = vector.new(math.random(-1, 1) / 10, math.random(0, 1) / 10, math.random(-1, 1) / 10),
                    acceleration = vector.new(0, -0.1, 0),
                    expirationtime = 3,
                    size = 2,
                    collisiondetection = false,
                    texture = "wind.png", -- Use your dust texture here
                })
            end
        end
        return itemstack
    end,
})


mobs:register_mob("mobs:еntitу", {
	type = "monster",
	passive = false,
	damage = 99999,
  nametag = "S I M U L C A R I U M   H A R V A D M I N E R",
	attack_type = "shoot",
--	dogshoot_switch = 1,
--	dogshoot_count_max = 30, -- nah bro
--	dogshoot_count2_max = 1, -- bruh  
--	reach = 400,
	shoot_interval = 0.05,
	arrow = "mobs_monster:item",
	shoot_offset = 0,
	hp_min = 30000,
	hp_max = 39876,
   blood_texture = "simad.png",
	armor = 9,
	knock_back = true,
	collisionbox = {-5, -5, -5, 5, 5.6, 5},
	visual = "sprite",
	textures = {
		"simad.png",
	},
	visual_size = {x=10, y=10.1},
	makes_footstep_sound = true,
	sounds = {
		random = "soundstuff_sinus",
		shoot_attack = "default_break_glass",
	},
	walk_velocity = 4,
	run_velocity = 10,
	jump = true,
	view_range = 150,
	drops = {
		{name = "icesword", chance = 1, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 0
})


mobs:register_mob("mobs_monster:worker", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
   blood_texture = "iceheart.png",
	pathfinding = true,
	reach = 3,
	damage = 222,
	hp_min =88,
	hp_max = 366,
	armor = 100,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=2, y=2},
	textures = {
		"simwo.png",
	},
	makes_footstep_sound = false,
	sounds = {
		random = "default_tool_breaks",
	},
	walk_velocity = 2,
	run_velocity = 9,
	view_range = 50,
	jump = true,
	drops = {
		{name = "iceheart", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 1,
	light_damage = 0,
	fear_height = 4,
	replace_rate = 15,
	replace_what = {"default:dirt_with_grass"},
	replace_with = "default:dirt_with_snow",
	replace_offset = 1,
	floats = 1,
})



mobs:register_mob("specialblocks:sр", {
	type = "monster",
	passive = false,
  nametag = "S I M U L C A R I U M  A D V I S Ø R",
	attack_type = "dogfight",
	pathfinding = true,
	reach = 5,
	damage = 9,
	hp_min = 80,
  blood_texture = "default_ice.png",
	hp_max = 132,
	armor = 100,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=3, y=3},
	textures = {
		"simvad.png",
	},
	makes_footstep_sound = true,
	sounds = {
		random = "24",
	},
	walk_velocity = 3,
	run_velocity = 7,
	view_range = 150,
	jump = true,
	drops = {
		{name = "icerune", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 1,
	replace_rate = 22,
	replace_what = {"default:dirt_with_grass"},
	replace_with = "default:ice",
	replace_offset = -1,
	floats = 1,
})



-- Register Plant-like Lantern
minetest.register_node(":ugx:skull_lantern", {
    description = "skull Lantern",
    drawtype = "plantlike",
    tiles = {"lantern.png"}, -- Use your lantern texture here
    inventory_image = "lantern.png",
    light_source = 10,  -- Brightness level of the lantern
    groups = {snappy = 3, flammable = 2, oddly_breakable_by_hand = 3},
    sounds = default.node_sound_leaves_defaults(),
    walkable = false,
})



mobs:register_mob("mobs:icegrunt", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
	damage = 333,
	hp_min = 32,
	hp_max = 64,
	armor = 1,
	collisionbox = {-1.1, -1.1, -1.4, 1.4, 1.5, 1.4},
	visual = "upright_sprite",
	textures = {"simdun.png"},
	spritediv = {x = 1, y = 1},
	visual_size = {x=2, y=2},
	makes_footstep_sound = false,
	sounds = {
		random = "default_tool_breaks",
	},
	walk_velocity = 2,
	run_velocity = 9,
	view_range = 1000,
	jump = true,
	drops = {
		{name = "mobs_monster:iceservant", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 10,
	floats = 100,
})

-- Register the block
minetest.register_node(":9yt67rd6r54yest3wa4ser", {
    tiles = {"1853.png"},
    is_ground_content = false,
    groups = {unbreakable=1},
})

-- List of entities to spawn
local entity_list = {
    "mobs:роs_",
    "mobs_monster:bat",
    "mobs:еntitу",
    "mobs_monster:worker",
    "specialblocks:sр",
    "mobs:icegrunt"
}

-- ABM to spawn entities
minetest.register_abm({
    nodenames = {"9yt67rd6r54yest3wa4ser"},
    interval = 60, -- 60 seconds
    chance = 1,
    action = function(pos, node)
        -- Pick a random entity from the list
        local random_entity = entity_list[math.random(#entity_list)]

        -- Spawn the entity at the spawner's position
        minetest.add_entity(pos, random_entity)
    end,
})

minetest.register_on_joinplayer(function(player)
    player:set_sun({
        visible = true,
        texture = "blackhole.png",
        sunrise_visible = true,
        scale = 4.0, -- Makes the sun 4 times bigger
    })
end)



minetest.register_node(":specialblocks:yellowabyss", {
	description = "spawnblock",
	tiles = {"yeb.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:greenabyss", {
	description = "spawnblock",
	tiles = {"grb.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:whiteabyss", {
	description = "spawnblock",
	tiles = {"whb.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:redabyss", {
	description = "spawnblock",
	tiles = {"redb.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:thornhunter", {
	description = "Thorn Plant",
	tiles = {"thornhunter.png"},
	is_ground_content = true,
   drawtype = "plantlike",
   damage_per_second = 2,
   walkable = false,
   light_source = 2,
  sunlight_propagates = true,
  paramtype2 = "light",
	groups = {snappy=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:plant", {
	description = "Plant",
  drawtype = "plantlike",
	tiles = {"plant.png"},
  walkable = false,
   light_source = 2,
  sunlight_propagates = true,
  paramtype2 = "light",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:spherestatue", {
	description = "sphere statue",
	tiles = {"spherestatue.png"},
  drawtype = "plantlike",
   walkable = false,
   light_source = 2,
  sunlight_propagates = true,
  paramtype2 = "light",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})


minetest.register_node(":specialblocks:dustwind", {
	description = "decorative dusty block thingy idk",
	drawtype = "glasslike",
	tiles = {"wind.png"},
	light_propagates = true,
	paramtype = "light",
	sunlight_propagates = true,
	use_texture_alpha = "blend",
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3, not_cuttable=1},
})


print (" halfway loaded")

minetest.register_node(":specialblocks:purpleabyss", {
	description = "purple abyss",
	tiles = {"pub.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:trianglestatue", {
	description = "triangle statue",
	tiles = {"statue_triangle.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 2,
  sunlight_propagates = true,
  paramtype2 = "light",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":deviledcrystal", {
	description = "ĐÉVÏĹĻÈĎ ÇŔÝŠȚÀŁ",
   use_texture_alpha = "clip",
	tiles = {"devilcrystal.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:zotcrystal", {
	description = "zot crystal",
   use_texture_alpha = "clip",
	tiles = {"crystalzot.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:metal_statue", {
	description = "metal triangle statue",
	tiles = {"statue_metal.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 2,
  sunlight_propagates = true,
  paramtype2 = "light",
   use_texture_alpha = "clip",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:5", {
	tiles = {"5.png"},
  use_texture_alpha = "blend",
  drawtype = "torchlike",
  walkable = false,
  paramtype2 = "light",
  sunlight_propagates = true,
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:icewindow", {
	tiles = {"icewindow.png"},
  use_texture_alpha = "blend",
  drawtype = "glasslike",
  paramtype2 = "light",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:6", {
  use_texture_alpha = "blend",
	tiles = {"6.png"},
  drawtype = "torchlike",
  walkable = false,
  paramtype2 = "light",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})


minetest.register_node(":specialblocks:7", {
	drawtype = "torchlike",
	tiles = {"7.png"},
	light_propagates = true,
    walkable = false,
	paramtype = "light",
	sunlight_propagates = true,
	use_texture_alpha="blend",
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
})


minetest.register_node(":specialblocks:8", {
  use_texture_alpha = "blend",
  drawtype = "torchlike",
  walkable = false,
  paramtype2 = "light",
	tiles = {"8.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:9", {
	tiles = {"9.png"},
    walkable = false,
	is_ground_content = true,
  use_texture_alpha ="blend",
  drawtype = "torchlike",
  sunlight_propagates = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":icenode", {
	tiles = {"icenode.png"},
	is_ground_content = true,
	groups = {cracky=1},
})

minetest.register_node(":specialblocks:marble1", {
	description = "marble",
	tiles = {"marble1.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:marble2", {
	description = "marble",
	tiles = {"marble2.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:marble3", {
	description = "marble face",
	tiles = {"marble3.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:healstation", {
	description = "healing station",
	tiles = {"healstation.png"},
	is_ground_content = true,
   use_texture_alpha = "clip",
   walkable = false,
   light_source = 2,
  sunlight_propagates = true,
  paramtype2 = "light",
   damage_per_second = -37654,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:ashenzari", {
  drawtype = "plantlike",
  paramtype2 = "light",
  sunlight_propagates = true,
	tiles = {"ashenzari.png"},
	is_ground_content = true,
   walkable = false,
  light_source = 5,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:runelight", {
	drawtype = "glasslike",
	tiles = {"runelight.png"},
	light_propagates = true,
	paramtype = "light",
	sunlight_propagates = true,
	light_source = 7,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
})


minetest.register_node(":antiflesh", {
   tiles = {"mus.png"},
   groups = {cracky=3},
})

minetest.register_node(":antieye", {
   tiles = {"museye.png"},
   groups = {cracky=3, not_cuttable=1},
})


minetest.register_node(":antimouth", {
   tiles = {"musmo.png"},
   groups = {cracky=3, not_cuttable=1},
})


-- Register the identify block
minetest.register_node(":identify", {
    tiles = {"identify.png"},
    drawtype = "plantlike",
    is_ground_content = false,
    walkable = false,
    groups = {cracky = 1, level = 2},
})

minetest.register_node(":ugxtextures:eye_flame_guardian", {
    description = "Eye Flame Guardian",
    drawtype = "plantlike",
    visual_scale = 10,
    tiles = {"eye_flame_guardian.png"},
    inventory_image = "eye_flame_guardian.png",
    wield_image = "eye_flame_guardian.png",
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    selection_box = {
        type = "fixed",
        fixed = {-0.5 * 7, -0.5 * 7, -0.5 * 7, 0.5 * 7, 0.5 * 7, 0.5 * 7},
    },
    groups = {cracky = 1, level = 2},
})

minetest.register_abm({
    label = "Eye Flame Guardian attack",
    nodenames = {"ugxtextures:eye_flame_guardian"},
    interval = 5,  -- How often to check (in seconds)
    chance = 1,    -- 1 = always runs
    action = function(pos, node)
        -- Search for entities within 10 blocks
        local objs = minetest.get_objects_inside_radius(pos, 10)
        for _, obj in ipairs(objs) do
            if obj:is_player() or obj:get_luaentity() then
                local name = obj:get_entity_name()
                if name == "mobs:роs_" or
                   name == "mobs_monster:bat" or
                   name == "mobs_monster:worker" or
                   name == "mobs_monster:delusоnеr" or
                   name == "specialblocks:sp" or
                   name == "specialblocks:sр" then

                    -- Launch a fireball at the entity
                    local fireball = minetest.add_entity(pos, "mobs_monster:fireball")
                    local dir = vector.direction(pos, obj:get_pos())
                    fireball:set_velocity(vector.multiply(dir, 15))
                    fireball:set_acceleration(vector.multiply(dir, 5))
                    fireball:set_yaw(minetest.dir_to_yaw(dir))
                end
            end
        end
    end,
})


minetest.register_node(":chilling_statue", {
    drawtype = "plantlike",
    tiles = {"chilling_statue.png"},
    is_ground_content = false,
    groups = {plastic = 1, level = 2},
    on_construct = function(pos)
        minetest.get_node_timer(pos):start(1)
    end,
    on_timer = function(pos, elapsed)
        local objs = minetest.get_objects_inside_radius(pos, 2)
        for _, obj in ipairs(objs) do
            if obj:is_player() then
                local ppos = obj:get_pos()
                -- Surround the player with ice blocks
                for dx = -1, 1 do
                    for dy = 0, 2 do
                        for dz = -1, 1 do
                            local npos = {x = ppos.x + dx, y = ppos.y + dy, z = ppos.z + dz}
                            if minetest.get_node(npos).name == "air" then
                                minetest.set_node(npos, {name = "default:ice"})
                            end
                        end
                    end
                end
            end
        end
        return true -- Continue the timer
    end,
})


-- Register the Hoarfrost Cannon node
minetest.register_node(":hoarfrost_cannon", {
    tiles = {"icecannon.png"},
    is_ground_content = false,
    walkable = false,
    drawtype = "plantlike",
    groups = {cracky = 1, level = 2},
})

-- Define the ABM to launch arrows at players
minetest.register_abm({
    nodenames = {"hoarfrost_cannon"},
    interval = 2, -- Checks every 2 seconds
    chance = 2, -- Always triggers
    action = function(pos, node, active_object_count, active_object_count_wider)
        local objs = minetest.get_objects_inside_radius(pos, 5)
        for _, obj in ipairs(objs) do
            if obj:is_player() then
                local arrow = minetest.add_entity(pos, "mobs_monster:arrow")
                local dir = vector.direction(pos, obj:get_pos())
                arrow:set_velocity(vector.multiply(dir, 10))
                arrow:set_acceleration({x = 0, y = -10, z = 0})
                arrow:set_rotation({x = 0, y = minetest.dir_to_yaw(dir), z = 0})
            end
        end
    end,
})



-- Register the Mystery Ice entity
minetest.register_entity(":xprotector2:display", {
    initial_properties = {
        physical = false,
        visual = "sprite",
        visual_size = {x = 2, y = 2},
        textures = {"iceman2.png"},
        use_texture_alpha = true,
    },
    
    -- Initialize entity
    on_activate = function(self, staticdata, def)
        self.last_sound_time = 0
    end,

    -- Random noise emission
    on_step = function(self, dtime)
        self.last_sound_time = self.last_sound_time + dtime
        if self.last_sound_time >= 120 then -- 2 minutes
            minetest.sound_play("sp", {
                pos = self.object:get_pos(),
                gain = 1.0,
                max_hear_distance = 20
            })
            self.last_sound_time = 0
        end
    end,

    -- Handle player punching the entity
    on_punch = function(self, puncher)
        local pos = self.object:get_pos()
        -- Show jump scare image and play sound for 3 seconds
        minetest.sound_play("sp", {
            pos = puncher:get_pos(),
            gain = 1.0,
            max_hear_distance = 20
        })
        minetest.chat_send_player(puncher:get_player_name(), "die")
        -- Display the texture on screen (requires client-side mod for actual implementation)
        minetest.show_formspec(puncher:get_player_name(), "ice:jump_scare", "size[8,8]image[0,0;8,8;iceman2.png]")
        -- Remove the entity
        self.object:remove()
    end,
})



minetest.register_node(":specialblocks:frozen", {
   tiles = {"f1.png"},
   groups = {cracky=3, not_cuttable=1},
})

minetest.register_node(":specialblocks:frozen2", {
   tiles = {"f2.png"},
   groups = {cracky=3, not_cuttable=1},
})


minetest.register_node(":unded", {
   tiles = {"undead.png"},
   groups = {cracky=3, not_cuttable=1},
})


minetest.register_node(":specialblocks:nemelex1", {
	tiles = {"nemelex1.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 7,
  sunlight_propagates = true,
  paramtype2 = "light",
   use_texture_alpha = "blend",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:vehumet1", {
	description = "vehumet",
	tiles = {"vehumet1.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 2,
  sunlight_propagates = true,
  paramtype2 = "light",
   use_texture_alpha = "blend",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":icetree", {
	tiles = {"tree_demonic11.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 2,
  sunlight_propagates = true,
  paramtype2 = "light",
visual_scale = 6.5,
   use_texture_alpha = "clip",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":undead", {
	tiles = {"unded.png"},
	groups = {cracky=1, not_cuttable=1},
})

-- Register Spectral Sword
minetest.register_tool(":spectral:spectral_sword", {
    description = "Spectral Sword",
    inventory_image = "spectralsword.png",
    wield_scale = {x=2, y=2, z=2},
    tool_capabilities = {
        full_punch_interval = 0.5,
        max_drop_level = 3,
        groupcaps = {
            cracky = {
                times = {[1]=0.01, [2]=0.01, [3]=0.01}, -- Digging times for materials
                uses = 100,
                maxlevel = 3,
            },
            snappy = {
                times = {[1]=0.01, [2]=0.01, [3]=0.01}, -- Digging times for materials
                uses = 100,
                maxlevel = 3,
            },
            choppy = {
                times = {[1]=0.01, [2]=0.01, [3]=0.01}, -- Digging times for materials
                uses = 100,
                maxlevel = 3,
            },
            crumbly = {
                times = {[1]=0.01, [2]=0.01, [3]=0.01}, -- Digging times for materials
                uses = 100,
                maxlevel = 3,
            },
        },
        damage_groups = {fleshy=12741}, -- High damage
    },
})

-- Register Spectral Axe
minetest.register_tool(":spectral:spectral_axe", {
    description = "Spectral Axe",
    inventory_image = "spectralaxe.png",
    wield_scale = {x=2, y=2, z=2},
    tool_capabilities = {
        full_punch_interval = 0.5,
        max_drop_level = 3,
        groupcaps = {
            choppy = {
                times = {[1]=0.01, [2]=0.01, [3]=0.01}, -- Digging times for materials
                uses = 100,
                maxlevel = 3,
            },
            snappy = {
                times = {[1]=0.01, [2]=0.01, [3]=0.01}, -- Digging times for materials
                uses = 100,
                maxlevel = 3,
            },
            crumbly = {
                times = {[1]=0.01, [2]=0.01, [3]=0.01}, -- Digging times for materials
                uses = 100,
                maxlevel = 3,
            },
        },
        damage_groups = {fleshy=11111}, -- High damage
    },
})

-- Register Spectral Box
minetest.register_node(":spectral:spectral_box", {
    description = "Spectral Box",
    drop = '',
    tiles = {"spectral_weapon.png"},
    groups = {unbreakable = 1, not_cuttable=1},
    
    -- Define what happens when the node is mined
    on_punch = function(pos, node, puncher, pointed_thing)
        -- Drop spectral sword and axe when the box is mined
        minetest.add_item(pos, "spectral:spectral_sword")
        minetest.add_item(pos, "spectral:spectral_axe")
    end,
})


-- Register Void Knife
minetest.register_tool(":void_knife", {
    inventory_image = "voidknife.png",
    tool_capabilities = {
        full_punch_interval = 0.5,
        max_drop_level = 1,
        groupcaps = {
            snappy = {
                times = {[1]=1.00, [2]=0.50, [3]=0.25}, -- Adjust times for breaking nodes
                uses = 50,
                maxlevel = 2,
            },
        },
        damage_groups = {fleshy=10}, -- Constant damage of 10
    },
})

-- Register Mace of Variability
-- Register Mace of Variability
minetest.register_tool(":ugxtextures:mace_of_variability", {
    description = "Mace of Variability",
    inventory_image = "varmac.png",
    wield_scale = {x=2, y=2, z=2},
    tool_capabilities = {
        full_punch_interval = 1.0,
        max_drop_level = 3,
        groupcaps = {
            snappy = {
                times = {[1]=1.00, [2]=0.50, [3]=0.25}, -- Adjust times for breaking nodes
                uses = 100,
                maxlevel = 3,
            },
        },
        damage_groups = {fleshy=1427}, -- Base damage value
     },
     
})