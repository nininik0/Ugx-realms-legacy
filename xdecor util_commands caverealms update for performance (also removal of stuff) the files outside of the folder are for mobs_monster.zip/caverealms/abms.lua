--grab schematics
local fortress = minetest.get_modpath("caverealms").."/schems/DMFort.mts"
local fountain = minetest.get_modpath("caverealms").."/schems/DMFountain.mts"

local DM_TOP = caverealms.config.dm_top -- -4000 --level at which Dungeon Master Realms start to appear

--place Dungeon Master Statue fountains
minetest.register_abm({
	nodenames = {"caverealms:s_fountain"},
	interval = 1.0,
	chance = 1,
	action = function(pos, node, active_object_count, active_object_count_wider)
		minetest.place_schematic(pos, fountain, "random", {}, true)
	end,
})

--place Dungeon Master Fortresses
minetest.register_abm({
	nodenames = {"caverealms:s_fortress"},
	interval = 1.0,
	chance = 1,
	action = function(pos, node, active_object_count, active_object_count_wider)
		npos = {x=pos.x,y=pos.y-7,z=pos.z}
		minetest.place_schematic(npos, fortress, "random", {}, true)
	end,
})

local MIN_ITEMS = caverealms.config.min_items--5 --minimum number of items to put in chests - do not set to greater than MAX_ITEMS
local MAX_ITEMS = caverealms.config.max_items--7 --maximum number of items to put in chests - do not set to less than MIN_ITEMS

--table of itemstrings
local ITEMS = {
	"default:diamond",
	"default:obsidian 33",
	"default:mese",
	"default:pick_diamond",
	"default:stonebrick 50",
	"default:sandstone 75",
	"default:torch 99",
  "moognu:moognu 2",
  "moognu:rainbow 8",
  "default:fern_4 2",
  "specialblocks:forceful_dismissal 2",
	"default:water_source 4",
}

--spawn and fill chests
minetest.register_abm({
	nodenames = {"caverealms:s_chest"},
	interval = 1.0,
	chance = 1,
	action = function(pos, node, active_object_count, active_object_count_wider)
		oldparam = minetest.get_node(pos).param2
		minetest.set_node(pos, {name="default:chest", param2=oldparam})
		minetest.after(1.0, function()
			local inv = minetest.get_inventory({type="node", pos=pos})
			local item_num = math.random(MIN_ITEMS, MAX_ITEMS)
			for i = 1, item_num do
				item_i = math.random(8) --if you add or subtract items from ITEMS, be sure to change this value to reflect it
				inv:add_item("main", ITEMS[item_i])
			end
		end)
	end,
})


-- bruhhhhhh

minetest.register_biome({
	name = "ad",
	node_top = "default:dirt_with_grass_footsteps",
	depth_top = 11,
	node_filler = "default:dirt",
	depth_filler = 11,
	node_river_water = "terrain:river_water_source",
	y_min = 4,
	y_max = 15,
	heat_point = 60,
	humidity_point = 80,
})



--
-- Register ores
--

-- All mapgens except singlenode
-- Blob ore first to avoid other ores inside blobs

-- Uranium from Technic modpack: technic_worldgen mod
	minetest.register_ore({
		ore_type        = "scatter",
		ore             = "default:stone_with_iron",
		wherein         = "default:dirt",
		clust_scarcity  = 24 * 24 * 24,
		clust_num_ores  = 4,
		clust_size      = 3,
		biomes          = {"ad"},
		y_min           = -64,
		y_max           = 35,
		noise_params    = {
			offset = 0,
			scale = 1,
			spread = {x = 100, y = 100, z = 100},
			seed = 420,
			octaves = 3,
			persist = 0.7
			},
		noise_threshold = 0.6,
	})



	minetest.register_decoration({
		deco_type = "simple",
		place_on = {"default:dirt_with_grass_footsteps"},
		sidelen = 16,
		noise_params = {
			offset = offset,
			scale = scale,
			spread = {x = 200, y = 210, z = 110},
			seed = 329,
			octaves = 3,
			persist = 0.6
		},
		biomes = {"ad"},
		y_min = 1,
		y_max = 200,
		decoration = "testnodes:plantlike_waving",
	})


minetest.register_decoration({
    deco_type = "simple",
    place_on = {"default:dirt_with_grass"},
    sidelen = 16,
    noise_params = {
        offset = 11,
        fill_ratio = 0.00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001,
        scale = 0.0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001,
        spread = {x = 100, y = 100, z = 100},
        seed = 666,
        octaves = 0.000000000000000000000000000000000000001,
        persist = 0.0000000000000000000000000000000000000000000000000001
    },
    biomes = {"grassland"},
    y_min = 1,
    y_max = 1,
    decoration = "default:fern_4",
})


minetest.register_node("caverealms:cryolava_source", {
	description = "Cryolava Source",
	drawtype = "liquid",
	tiles = {
		{
			name = "space_travel_cryolava_source_animated.png",
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 3.0,
			},
		},
	},
	special_tiles = {
		-- New-style lava source material (mostly unused)
		{
			name = "space_travel_cryolava_source_animated.png",
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 3.0,
			},
			backface_culling = false,
		},
	},
	paramtype = "light",
	light_source = default.LIGHT_MAX - 1,
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "source",
	liquid_alternative_flowing = "caverealms:cryolava_flowing",
	liquid_alternative_source = "caverealms:cryolava_source",
	liquid_viscosity = 2, --7,
	liquid_renewable = false,
	damage_per_second = 2 * 2, --4 * 2,
	post_effect_color = {a = 191, r = 188, g = 246, b = 255},
	groups = {liquid = 2, puts_out_fire = 1, cools_lava = 1},
})

minetest.register_node("caverealms:cryolava_flowing", {
	description = "Flowing Cryolava",
	drawtype = "flowingliquid",
	tiles = {"space_travel_cryolava.png"},
	special_tiles = {
		{
			name = "space_travel_cryolava_flowing_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 3.3,
			},
		},
		{
			name = "space_travel_cryolava_flowing_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 3.3,
			},
		},
	},
	paramtype = "light",
	paramtype2 = "flowingliquid",
	light_source = default.LIGHT_MAX - 1,
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "flowing",
	liquid_alternative_flowing = "caverealms:cryolava_flowing",
	liquid_alternative_source = "caverealms:cryolava_source",
	liquid_viscosity = 2, --7,
	liquid_renewable = false,
	damage_per_second = 2 * 2, --4 * 2,
	post_effect_color = {a = 191, r = 188, g = 246, b = 255},
	groups = {liquid = 2, not_in_creative_inventory = 1, puts_out_fire = 1, cools_lava = 1},
})


minetest.register_node(":fakeskysphere",{
	drawtype = "mesh",
	mesh = "testnodes_marble_metal.obj",
  light_source = 1,
  use_texture_alpha = "blend",
	tiles = { "skyb.png" },
	paramtype = "light",
	visual_scale = 190,
	groups = {choppy=1, not_in_creative_inventory=1},
})




-- Define the smokeless fire node
minetest.register_node("caverealms:smokeless_fire", {
    description = "Smokeless, Fake Fire",
    tiles = {
      {name="fake_fire_animated.png", animation={type="vertical_frames",
      aspect_w=16, aspect_h=16, length=1.0}},
      },
    is_ground_content = true,
    inventory_image = 'fake_fire.png',
    wield_image = "fake_fire.png",
    drawtype = "plantlike",
    waving = 1,
    light_source = 14,
    sunlight_propagates = true,
    groups = {
      oddly_breakable_by_hand=3, dig_immediate=2, attached_node=1,
      not_in_creative_inventory=1
      },
    paramtype = "light",
    walkable = false,
    drop = "",
    on_punch = function (pos,node,puncher)
     minetest.set_node(pos, {name = "caverealms:smokeless_fire"})
    end
})


-- Define the smokeless ice fire node
minetest.register_node("caverealms:smokeless_ice_fire", {
    description = "Smokeless, Fake, Ice Fire",
    tiles = {
      {name="ice_fire_animated.png", animation={type="vertical_frames",
      aspect_w=16, aspect_h=16, length=1.0}},
      },
    is_ground_content = true,
    inventory_image = 'ice_fire.png',
	wield_image = "ice_fire.png",
    drawtype = "plantlike",
    waving = 1,
    light_source = 14,
    sunlight_propagates = true,
    groups = {
      oddly_breakable_by_hand=3, dig_immediate=2, attached_node=1,
      not_in_creative_inventory=1
      },
    paramtype = "light",
    walkable = false,
    drop = "",
    on_punch = function (pos,node,puncher)
     minetest.set_node(pos, {name = "caverealms:smokeless_ice_fire"})
    end
})

minetest.register_node("caverealms:embers", {
    description = "Glowing Embers",
    tiles = {
      {name="embers_animated.png", animation={type="vertical_frames",
      aspect_w=16, aspect_h=16, length=2}},
      },
    inventory_image = minetest.inventorycube('fake_fire_embers.png'),
    is_ground_content = true,
    light_source = 9,
    -- Adding sunlight_propagtes and leaving comments as a future reference.
    -- If true, sunlight will go infinitely through this (no shadow is cast).
    -- Because embers produce some light it should be somewhat "true" but this
    -- is an area where Minetest lacks in subtlety so I'm opting for 100% that
    -- embers *don't* have a shadow.
    sunlight_propagates = true,
    -- It's almost soft, brittle charcoal. ~ LazyJ
    groups = {choppy=3, crumbly=3, oddly_breakable_by_hand=3},
    paramtype = "light",
    -- You never know when a creative builder may use the screwdriver or
    -- position to create a subtle effect that makes their creation just
    -- that little bit nicer looking. ~ Lazyj
    paramtype2 = "facedir",
    walkable = true,
})
