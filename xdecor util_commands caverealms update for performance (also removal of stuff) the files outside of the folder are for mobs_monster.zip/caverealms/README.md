# minetest-caverealms

A mod for Minetest to add underground realms

## Forum Topic
For more information, view the official forum topic at:
- https://forum.minetest.net/viewtopic.php?f=9&t=9522

## Contributors
- HeroOfTheWinds - everything
- Zeno - additional ideas and fine tuning

##Licensing
- WTFPL

Also be sure to check out VanessaE's texturepack "HDX", which supports this mod!
