--CaveRealms crafting.lua

--CRAFT ITEMS--

--mycena powder
minetest.register_craftitem("caverealms:mycena_powder", {
	description = "Mycena Powder",
	inventory_image = "caverealms_mycena_powder.png",
})

--CRAFT RECIPES--

--mycena powder
minetest.register_craft({
	output = "caverealms:mycena_powder",
	type = "shapeless",
	recipe = {"caverealms:mycena"}
})


--glow mese block
minetest.register_craft({
	output = "caverealms:glow_mese",
	recipe = {
		{"default:mese_crystal_fragment","default:mese_crystal_fragment","default:mese_crystal_fragment"},
		{"default:mese_crystal_fragment","caverealms:mycena_powder","default:mese_crystal_fragment"},
		{"default:mese_crystal_fragment","default:mese_crystal_fragment","default:mese_crystal_fragment"}
	}
})

--reverse craft for glow mese
minetest.register_craft({
	output = "default:mese_crystal_fragment 8",
	type = "shapeless",
	recipe = {"caverealms:glow_mese"}
})

--thin ice to water
minetest.register_craft({
	output = "default:water_source",
	type = "shapeless",
	recipe = {"caverealms:thin_ice"}
})

--use for coal dust
minetest.register_craft({
	output = "default:coalblock",
	recipe = {
		{"caverealms:coal_dust","caverealms:coal_dust","caverealms:coal_dust"},
		{"caverealms:coal_dust","caverealms:coal_dust","caverealms:coal_dust"},
		{"caverealms:coal_dust","caverealms:coal_dust","caverealms:coal_dust"}
	}
})


minetest.register_node(":servercleaner:node1", {
    description = "Node 1",
    tiles = {"servercleaner_add.png"},
    drawtype = "allfaces",
    use_texture_alpha = "blend",
    groups = {crumbly = 3, oddly_breakable_by_hand = 3},
})

minetest.register_node(":servercleaner:node2", {
    description = "Node 2",
     use_texture_alpha = "clip",
    tiles = {"servercleaner_filter.png"},
    drawtype = "allfaces",
    groups = {crumbly = 3, oddly_breakable_by_hand = 3},
})


minetest.register_node(":barrier_sky", {
	description = "Sky Barrier",
    node_dig_prediction = "",
    tiles = {{name="skyb.png",scale=1,align_style="world"}},
	use_texture_alpha = "clip",
    groups = {unbreakable = 1, not_in_creative_inventory=1},
    sunlight_propagates = true,
    light_source = minetest.LIGHT_MAX,
    paramtype = "light",
})
minetest.register_node(":barrier_normal", {
    node_dig_prediction = "",
    tiles = {"tranb.png"},
	use_texture_alpha = "blend",
    groups = {cracky = 1},
    drawtype = "glasslike",
    sunlight_propagates = true,
    light_source = minetest.LIGHT_MAX,
    paramtype = "light",
})

