
-- Load support for intllib.
local path = minetest.get_modpath(minetest.get_current_modname()) .. "/"

-- Translation support
local S = minetest.get_translator("mobs_monster")

-- Check for custom mob spawn file
local input = io.open(path .. "spawn.lua", "r")

if input then
	mobs.custom_spawn_monster = true
	input:close()
	input = nil
end


-- helper function
local function ddoo(mob)

	if minetest.settings:get_bool("mobs_monster." .. mob) == false then
		print("[Mobs_Monster] " .. mob .. " disabled!")
		return
	end

	dofile(path .. mob .. ".lua")
end

-- Monsters
ddoo("dirt_monster") -- PilzAdam
ddoo("dungeon_master")
ddoo("sand_monster")
ddoo("stone_monster")
ddoo("spider") -- AspireMint


-- Load custom spawning
if mobs.custom_spawn_monster then
	dofile(path .. "spawn.lua")
end


-- Lucky Blocks
if minetest.get_modpath("lucky_block") then
	dofile(path .. "lucky_block.lua")
end

mobs:register_mob("mobs_monster:sam", {
   type = "monster",
   passive = false,
   attacks_monsters = true,
   attacks_npcs = true,
   damage = 1,
   reach = 1,
   attack_type = "dogfight",
   hp_min = 30,
   hp_max = 45,
   armor = 80,
   collisionbox = {-0.25, 0.35, -0.25, 0.25, 0.9, 0.25},
   physical = false,
   visual = "mesh",
   mesh = "character.b3d",
   textures = {
      {"deadsam.png"},
   },
   blood_amount = 1,
   blood_texture = "blank.png",
   visual_size = {x=1, y=1},
   makes_footstep_sound = false,
   walk_velocity = 0.01,
   run_velocity = 5,
   jump = false,
   water_damage = 2,
   lava_damage = 0,
   light_damage = 0,
   view_range = 20,
   animation = {
      speed_normal = 1,
      speed_run = 1,
      walk_start = 1,
      walk_end = 1,
      stand_start = 1,
      stand_end = 1,
      run_start = 1,
      run_end = 1,
      punch_start = 1,
      punch_end = 1,
   },
})



mobs:register_mob("mobs_monster:_", {
	type = "monster",
	hp_min = 9,
   show_on_minimap = true,
	hp_max = 20,
   damage = 11,
  jump_height = 20,
	visual = "upright_sprite",
   collisionbox = {-0.5, -1.5, -0.5, 0.5, 0.5, 0.5},
	textures = {"yikes.png", "yikes1.png" },
   visual_size = { x = 5, y = 5, z = 5 },
	walk_velocity = 5,
   jump_height = 15.55,
	run_velocity = 22,
	view_range = 240,
	pathfinding = 1222,
	sounds = {
		random = "spooky_noise",
	},
	drops = {
		{name = "air", chance = 11, min = 0, max = 1},
		{name = "default:portal2", chance = 100, min = 0, max = 1},
	},
	attack_type = "dogfight",
	reach = 5,
	damage = 11,
})

-- UNKOWN OBJCECT FINAL BOSS by nininik

mobs:register_mob("mobs_monster:UNKNOWN", {
	type = "monster",
	passive = false,
	damage = 15,
	attack_type = "shoot",
--	dogshoot_switch = 1,
--	dogshoot_count_max = 30, -- nah bro
--	dogshoot_count2_max = 1, -- bruh  
--	reach = 40,
	shoot_interval = 1,
	arrow = "mobs_monster:item",
	shoot_offset = 0,
	hp_min = 100,
	hp_max = 300,
	armor = 90,
	knock_back = true,
	collisionbox = {-4, -4, -4, 4, 4.6, 4},
	visual = "sprite",
	textures = {
		"unknown_object.png",
	},
	visual_size = {x=9, y=9},
	makes_footstep_sound = true,
	sounds = {
		random = "spooky_noise",
		shoot_attack = "mobs_fireball",
	},
	walk_velocity = 4,
	run_velocity = 9,
	jump = true,
	view_range = 50,
	drops = {
		{name = "", chance = 1, min = 1, max = 2},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 20
})


mobs:spawn({
	name = "mobs_flat:UNKNOWN",
	nodes = {"util_commands:unkown"},
	neighbors = {"default:mese", "default:stone_with_mese", "air", "default:mossycobble"},
	chance = 1,
	active_object_count = 1,
})




-- ITEM (weapon)
mobs:register_arrow("mobs_monster:item", {
	visual = "sprite",
	visual_size = {x = 2, y = 2},
	textures = {"unknown_item.png"},
	velocity = 6,
	tail = 1,
	tail_texture = "unknown_node.png",
	tail_size = 2,
	glow = 8,
	expire = 1,

	-- direct hit, no fire... just plenty of pain
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 100},
		}, nil)
	end,

	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 10},
		}, nil)
	end,

	-- node hit
	hit_node = function(self, pos, node)
		mobs:boom(self, pos, 10)
	end
})

-- support for MT game translation.
local S = minetest.get_translator("mobs_monster")

-- eye boss by nininik

mobs:register_mob("mobs_monster:eyeboss", {
	type = "monster",
	passive = false,
	damage = 4,
	attack_type = "shoot",
--	dogshoot_switch = 1,
--	dogshoot_count_max = 30, -- nah bro
--	dogshoot_count2_max = 1, -- bruh  
--	reach = 40,
	shoot_interval = 3,
	arrow = "mobs_monster:eyeball",
	shoot_offset = 0.1,
	hp_min = 50,
	hp_max = 70,
	armor = 60,
	knock_back = true,
	collisionbox = {-0.7, -1, -0.7, 0.7, 1.6, 0.7},
	visual = "upright_sprite",
	textures = {
		"mobs_flat_eyeboss.png",
	},
	visual_size = {x=2, y=2},
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_spider",
		shoot_attack = "tnt_ignite",
	},
	walk_velocity = 4,
	run_velocity = 9,
	jump = true,
	view_range = 50,
	drops = {
		{name = "c", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 8,
})


mobs:spawn({
	name = "mobs_monster:eyeboss",
	nodes = {"default:dirt_empty"},
	neighbors = {"default:mese", "default:stone_with_mese", "air", "default:mossycobble"},
	chance = 1,
	active_object_count = 1,
})


mobs:register_egg("mobs_monster:eyeboss", ("eye boss"), "mobs_flat_eyeboss.png", 1)


-- fireball (weapon)
mobs:register_arrow("mobs_monster:eyeball", {
	visual = "sprite",
	visual_size = {x = 1, y = 1},
	textures = {"eyeball.png"},
	velocity = 6,
	tail = 1,
	tail_texture = "horror_portal.png",
	tail_size = 10,
	glow = 8,
	expire = 0.5,

	-- direct hit, no fire... just plenty of pain
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 5},
		}, nil)
	end,

	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 10},
		}, nil)
	end,

	-- node hit
	hit_node = function(self, pos, node)
		mobs:boom(self, pos, 9)
	end
})

-- support for MT game translation.


-- starcursed_mass by nininik

mobs:register_mob("mobs_monster:starcursed_mass", {
	type = "monster",
	passive = false,
	damage = 3,
	attack_type = "shoot",
	shoot_interval = 8,
  use_texture_alpha = true,
	arrow = "mobs_monster:arrow",
	shoot_offset = 0.1,
	hp_min = 20,
	hp_max = 50,
	armor = 50,
	knock_back = true,
	collisionbox = {-0.7, -1, -0.7, 0.7, 1.6, 0.7},
	visual = "upright_sprite",
	textures = {
		"starcursed_mass.png",
	},
	visual_size = {x=2, y=2},
	makes_footstep_sound = true,
	sounds = {
		random = "spooky_noise",
		shoot_attack = "p",
	},
	walk_velocity = 5,
	run_velocity = 11,
	jump = true,
  jump_height = 16,
	view_range = 100,
	drops = {
		{name = "default:diamond", chance = 0.5, min = 0, max = 11},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 20,
})


mobs:spawn({
	name = "mobs_monster:starcursed_mass",
	nodes = {"default:stone_with_diamond", "default:stone_with_mese"},
	neighbors = {"default:mese", "default:stone_with_mese", "air", "default:mossycobble"},
	chance = 100,
	active_object_count = 10,
})


mobs:register_egg("mobs_monster:starcursed_mass", ("Starcursed Mass"), "starcursed_mass.png", 1)


-- fireball (weapon)
mobs:register_arrow("mobs_monster:arrow", {
	visual = "sprite",
	visual_size = {x = 1, y = 1},
	textures = {"starcursed_mass.png"},
	velocity = 11,
	tail = 1,
	tail_texture = "starcursed_mass.png",
	tail_size = 1,
	glow = 8,
	expire = 1,

	-- direct hit, no fire... just plenty of pain
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 11},
		}, nil)
	end,

	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 10},
		}, nil)
	end,

	-- node hit
	hit_node = function(self, pos, node)
		mobs:boom(self, pos, 1)
	end
})



mobs:spawn({
	name = "slimes:lavabig",
	nodes = {"default:lava_source"},
	chance = 30,
	active_object_count = 12,
	max_height = -10,
})

-- Mese Monster

mobs:spawn({
	name = "slimes:greenbig",
	nodes = {"default:jungletree"},
	min_light = 0,
	chance = 50,
	active_object_count = 2,
	max_height = 200,
})

-- slimy

mobs:spawn({
	name = "slimes:greenmedium",
	nodes = {"default:junglegrass"},
	min_light = 0,
	chance = 50,
	max_height = 100,
})

mobs:register_mob("mobs_monster:crane_monster", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 2,
	damage = 3,
	hp_min = 12,
	hp_max = 32,
	armor = 100,
  blood_amount = 100,
  blood_texture = "default_steel_ingot.png",
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=2, y=4.1},
	textures = {
		"crane_monster.png",
	},
	makes_footstep_sound = true,
	sounds = {
		random = "pipe",
	},
	walk_velocity = 0.5,
	run_velocity = 9,
	view_range = 100,
	jump = true,
	drops = {
		{name = "default:steelblock", chance = 0.5, min = 0, max = 5},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 9,
	replace_rate = 5,
	replace_what = {"default:torch"},
	replace_with = "air",
	replace_offset = -1,
	floats = 1,
})

mobs:spawn({
	name = "mobs_monster:crane_monster",
	nodes = {"default:stone_with_iron", "default:stone_with_diamond"},
	neighbors = {"air"},
	chance = 100,
	active_object_count = 1,
})

mobs:register_egg("mobs_monster:crane_monster", ("CRANE MONSTER"), "crane_monster.png", 1)


print ("[MOD] Mobs Monster loaded")
