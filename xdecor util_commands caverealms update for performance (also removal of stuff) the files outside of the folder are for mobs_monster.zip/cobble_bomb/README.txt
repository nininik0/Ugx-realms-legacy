Minetest 0.4 mod: cobble_bomb
=========================

This mod code is licensed under the GNU LGPLv2.1.
License for texture and sound is (CC BY-SA 3.0)

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

http://www.gnu.org/licenses/lgpl-2.1.html

Adds rolling and exploding bomb to the game.
Explosion damages players, mobs, and another bombs too.
Explosion destroys only stone and cobble.
Explosion do not respect old type area protectors and only partially respect new type area protection.
