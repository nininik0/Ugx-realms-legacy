local S

if minetest.get_translator ~= nil then
    S = minetest.get_translator(minetest.get_current_modname())
else
    S = function(str)
        return(str)
    end
end

--- Registering Armor

minetest.register_tool("xtrarmor:chestplate_ultra", {
	description = S("Ultra Chestplate"),
	inventory_image = "xtrarmor_chestplate_ultra_preview.png",
    groups = {armor_torso=44, armor_heal=18, armor_use=100, armor_fire=10},
    armor_groups = {fleshy =20},
    damage_groups = {cracky=2, snappy=1, level=3},
    wear = 0,
})

minetest.register_tool("xtrarmor:leggings_regnum", {
	description = S("Regnum Leggings"),
	inventory_image = "xtrarmor_leggings_regnum.png",
    groups = {armor_legs=33, armor_heal=38, armor_use=80, armor_fire=1},
    armor_groups = {fleshy =20},
    damage_groups = {cracky=2, snappy=1, level=3},
    wear = 0,
})

minetest.register_tool("xtrarmor:chestplate_void", {
	description = ("void chestplate"),
	inventory_image = "xtrarmor_chestplate_void.png",
    groups = {armor_torso=69, armor_heal=18, armor_use=20,
        physics_speed=1.5, physics_jump=1, armor_fire=1, armor_fire=1, armor_use=50},
    armor_groups = {fleshy =15},
    damage_groups = {cracky=2, snappy=1, level=3},
    wear = 0,
})

minetest.register_tool("xtrarmor:helmet_admin2", {
	description = S("Purple Admin Helmet"),
	inventory_image = "xtrarmor_helmet_admin2.png",
    groups = {armor_head=100, armor_heal=180, armor_use=0, armor_fire=1, not_in_creative_inventory=1},
    armor_groups = {fleshy = 100},
    damage_groups = {cracky=2, snappy=1, level=3},
    wear = 0,
})

minetest.register_tool("xtrarmor:shield", {
	description = S("Shield"),
	inventory_image = "shield.png",
    groups = {armor_shield=1, armor_heal=19, armor_use=200, armor_fire=1},
    armor_groups = {fleshy=20},
    wear = 0,
})

armor:register_armor("xtrarmor:helmet", {
	description = "Dangerous region protection Suit Helmet",
	inventory_image = "molten_sailor_inv_helmet.png",
	groups = {armor_head=9, armor_heal=9, armor_fire=8, armor_use=150, physics_speed=0.01, physics_jump=0.01},
	wear = 0,
})

armor:register_armor("xtrarmor:helmet_ultra", {
	description = "ultra helmet",
	inventory_image = "xtrarmor_helmet_ultra.png",
	groups = {armor_head=19, armor_heal=20, armor_fire=25, armor_use=100},
	wear = 0,
})

armor:register_armor("xtrarmor:helmet_regnum", {
	description = "Regnum Helmet",
	inventory_image = "xtrarmor_helmet_regnum.png",
	groups = {armor_head=9, armor_heal=9, armor_fire=8, armor_use=150},
	wear = 0,
})
minetest.register_tool("xtrarmor:chestplate", {
	description = "Dangerous region protection Suit Chestplate",
	inventory_image = "molten_sailor_inv_chestplate.png",
	groups = {armor_torso=8, armor_heal=19, armor_fire=15,armor_use=150},
	wear = 0,
})

minetest.register_tool("xtrarmor:pants", {
	description = "Dangerous region protection Suit Pants",
	inventory_image = "molten_sailor_inv_pants.png",
	groups = {armor_legs=7, armor_heal=10, armor_fire=11,armor_use=150},
	wear = 0,
})

minetest.register_tool("xtrarmor:boots", {
	description = "Dangerous region protection Suit Boots",
	inventory_image = "molten_sailor_inv_boots.png",
	groups = {armor_feet=6, armor_heal=10, armor_fire=10,  physics_speed= 2.2,armor_use=150},
	wear = 0,
})

armor:register_armor("xtrarmor:void_helmet", {
	description = "void Helmet",
	inventory_image = "xtrarmor_void_helmet.png",
	groups = {armor_head=11, armor_heal=10, armor_fire=9, armor_use=100},
	wear = 0,
})


minetest.register_tool("xtrarmor:chestplate_hev", {
	description = "Hev torso",
	inventory_image = "halftest_inv_chestplate_hev.png",
	groups = {armor_torso=37.4,physics_jump=0.2,physics_speed=0.4, armor_heal=9, armor_use=250, radiation=100},
	wear = 0,
})
minetest.register_tool("xtrarmor:leggings_hev", {
	description = "Hev Leggings",
	inventory_image = "halftest_inv_leggings_hev.png",
	groups = {armor_legs=27.3,physics_jump=0.5,physics_speed=0.4, armor_heal=9, armor_use=250, radiation=100},
	wear = 0,
})
minetest.register_tool("xtrarmor:boots_hev", {
	description = "Hev Boots",
	inventory_image = "halftest_inv_boots_hev.png",
	groups = {armor_feet=17.3,physics_jump=0.4,physics_speed=0.9, armor_heal=9, armor_use=250, radiation=100},
	wear = 0,
})




armor:register_armor("xtrarmor:boots_ruby", {
	description = S"Ruby Boots",
	inventory_image = "3d_armor_inv_boots_ruby.png",
	groups = {armor_feet = 5, armor_heal = 15,
		physics_speed = 0.1, physics_jump = 0.01}
})
armor:register_armor("xtrarmor:leggings_emerald", {
	description = S"Emerald Leggings",
	inventory_image = "3d_armor_inv_leggings_emerald.png",
	groups = {armor_legs = 25, armor_heal = 20, armor_use = 1000,
		physics_speed = 0.03, physics_jump = 0.03}
})

armor:register_armor("xtrarmor:leggings_ruby", {
	description = S"Ruby Leggings",
	inventory_image = "3d_armor_inv_leggings_ruby.png",
	groups = {armor_legs = 25, armor_heal = 15,
		physics_speed = 0.02, physics_jump = 0.02}
})
armor:register_armor("xtrarmor:chestplate_emerald", {
	description = S"Emerald Chestplate",
	inventory_image = "3d_armor_inv_chestplate_emerald.png",
	groups = {armor_torso = 30, armor_heal = 20, armor_use = 1000,
		physics_speed = 0.09, physics_jump = 0.03}
})

armor:register_armor("xtrarmor:chestplate_ruby", {
	description = S"Ruby Chestplate",
	inventory_image = "3d_armor_inv_chestplate_ruby.png",
	groups = {armor_torso = 30, armor_heal = 15,
		physics_speed = 0.02, physics_jump = 0.02}
})

armor:register_armor("xtrarmor:leggings_blue", {
	description = "Blue Leggings",
	inventory_image = "xtrarmor_leggings_blue.png",
	groups = {armor_legs = 100, armor_heal = 100,
		physics_speed = 0.02, physics_jump = 0.02,armor_use=150}
})
armor:register_armor("xtrarmor:chestplate_mese", {
	description = "Mese Chestplate",
	inventory_image = "xtrarmor_chestplate_mese.png",
	groups = {armor_torso = 25, armor_heal = 25,
		physics_speed = 0.1, physics_jump = 0.01, armor_use=150}
})

armor:register_armor("xtrarmor:helmet_blue", {
	description = S"Blue helmet",
	inventory_image = "xtrarmor_helmet_blue.png",
	groups = {armor_head = 5, armor_heal = 15,
		physics_speed = 0.1, physics_jump = 0.01}
})

armor:register_armor("xtrarmor:chestplate_space", {
	description = S"space Chestplate",
	inventory_image = "xtrarmor_chestplate_space.png",
	groups = {armor_torso = 30, armor_heal = 15,
		physics_speed = 0.02, physics_jump = 0.02}
})


armor:register_armor("xtrarmor:helmet_space", {
	description = S"Space Helmet",
	inventory_image = "xtrarmor_helmet_space.png",
	groups = {armor_head = 5, armor_heal = 15,
		physics_speed = 0.1, physics_jump = 0.01, armor_water=1, armor_use = 69}
})



armor:register_armor("xtrarmor:leggings_space", {
	description = S" Leggings",
	inventory_image = "xtrarmor_leggings_space.png",
	groups = {armor_legs = 25, armor_heal = 15,
		physics_speed = 0.02, physics_jump = 0.02, armor_use=69}
})


armor:register_armor("xtrarmor:boots_space", {
	description = S"Space Boots",
	inventory_image = "xtrarmor_boots_space.png",
	groups = {armor_feet = 5, armor_heal = 15,
		physics_speed = 0.1, physics_jump = 0.01, armor_use=69}
})



armor:register_armor("xtrarmor:leggings_mese", {
	description = S"Mese Leggings",
	inventory_image = "xtrarmor_leggings_mese.png",
	groups = {armor_legs = 15, armor_heal = 10,
		physics_speed = 0.02, physics_jump = 0.02, armor_use=150}
})





armor:register_armor("xtrarmor:helmet_mese", {
	description = S"Mese Helmet",
	inventory_image = "xtrarmor_helmet_mese.png",
	groups = {armor_head = 5, armor_heal = 10,
		physics_speed = 0.1, physics_jump = 0.01, armor_use=50}
})

armor:register_armor("xtrarmor:chestplate_1", {
	description = S"The Chestplate",
	inventory_image = "xtrarmor_chestplate_1.png",
	groups = {armor_torso = 30, armor_heal = 15,
		physics_speed = 0.5, physics_jump = 0.02, armor_use=100}
})



armor:register_armor("xtrarmor:leggings_tts", {
	description = S"Thunderstrike Leggings",
	inventory_image = "ttsleg.png",
	groups = {armor_legs = 35, armor_heal = 30,
		physics_speed = 0.5, physics_jump = 0.5}
})


armor:register_armor("xtrarmor:boots_tts", {
	description = S"Thunderstrike Boots",
	inventory_image = "xtrarmor_boots_tts.png",
	groups = {armor_feet = 15, armor_heal = 15,
		physics_speed = 0.1, physics_jump = 0.01}
})

armor:register_armor("xtrarmor:chestplate_tts", {
	description = S"Thunderstrike Chestplate",
	inventory_image = "ttschest.png",
	groups = {armor_torso = 50, armor_heal = 50,
		physics_speed = 0.5, physics_jump = 0.5}
})


armor:register_armor("xtrarmor:chestplate_tts2", {
	description = S"T.T.S. Chestplate",
	inventory_image = "ttschest2.png",
	groups = {armor_torso = 30, armor_heal = 15,
		physics_speed = 0.5, physics_jump = 0.5}
})

armor:register_armor("xtrarmor:leggings_blueadmin", {
	description = S"Blue Admin Leggings",
	inventory_image = "xtrarmor_leggings_blueadmin.png",
	groups = {armor_legs = 100, armor_heal = 105,
		physics_speed = 0.02, physics_jump = 0.02}
})


armor:register_armor("xtrarmor:helmet_blueadmin", {
	description = S"Blue admin helmet",
	inventory_image = "xtrarmor_helmet_blueadmin.png",
	groups = {armor_head = 100, armor_heal = 115,
		physics_speed = 0.1, physics_jump = 0.01}
})

armor:register_armor("xtrarmor:chestplate_blueadmin", {
	description = S"Blue Admin Chestplate",
	inventory_image = "xtrarmor_chestplate_blueadmin.png",
	groups = {armor_torso = 150, armor_heal = 150,
		physics_speed = 0.02, physics_jump = 0.02}
})


armor:register_armor("xtrarmor:leggings_orangeadmin", {
	description = S"Orange Admin Leggings",
	inventory_image = "xtrarmor_leggings_orangeadmin.png",
	groups = {armor_legs = 100, armor_heal = 105,
		physics_speed = 0.02, physics_jump = 0.02}
})


armor:register_armor("xtrarmor:helmet_orangeadmin", {
	description = S"Orange admin helmet",
	inventory_image = "xtrarmor_helmet_orangeadmin.png",
	groups = {armor_head = 100, armor_heal = 115,
		physics_speed = 0.1, physics_jump = 0.01}
})

armor:register_armor("xtrarmor:chestplate_orangeadmin", {
	description = S"Orange Admin Chestplate",
	inventory_image = "xtrarmor_chestplate_orangeadmin.png",
	groups = {armor_torso = 150, armor_heal = 150,
		physics_speed = 0.02, physics_jump = 0.02}
})



	-- Register helmets
	armor:register_armor("xtrarmor:helmet_reinforcedleather", {
		description = "Reinforced Leather Helmet",
		inventory_image = "3d_armor_inv_helmet_reinforcedleather.png",
		groups = {armor_head = 6, armor_heal = 0, armor_use = 40},
	})
	-- Register chestplates
	armor:register_armor("xtrarmor:chestplate_reinforcedleather", {
		description = "Reinforced Leather Chestplate",
		inventory_image = "3d_armor_inv_chestplate_reinforcedleather.png",
		groups = {armor_torso = 11, armor_heal = 0, armor_use = 40},
	})
	-- Register leggings
	armor:register_armor("xtrarmor:leggings_reinforcedleather", {
		description = "Reinforced Leather Leggings",
		inventory_image = "3d_armor_inv_leggings_reinforcedleather.png",
		groups = {armor_legs = 11, armor_heal = 0, armor_use = 40},
	})
	-- Register boots
		armor:register_armor("xtrarmor:boots_reinforcedleather", {
		description = "Reinforced Leather Boots",
		inventory_image = "3d_armor_inv_boots_reinforcedleather.png",
		groups = {armor_feet = 6, armor_heal = 0, armor_use = 40},
	})

minetest.register_tool("xtrarmor:shield_1", {
	description = S("The Shield"),
	inventory_image = "shield1.png",
    groups = {armor_shield=15, armor_heal=20, armor_use=200, armor_fire=1},
    armor_groups = {fleshy=20},
    wear = 0,
})



armor:register_armor("xtrarmor:helmet_leathercap", {
	description = S"Leather cap",
	inventory_image = "xtrarmor_helmet_leathercap.png",
	groups = {armor_head = 10, armor_heal = 15,
		physics_speed = 0.1, physics_jump = 0.1}
})

armor:register_armor("xtrarmor:chestplate_titanium", {
	description = S"Titanium Chestplate",
	inventory_image = "xtrarmor_chestplate_titanium.png",
	groups = {armor_torso = 30, armor_heal = 35,
		physics_speed = -0.02, physics_jump = -0.02}
})



armor:register_armor("xtrarmor:leggings_titanium", {
	description = S"Titanium Leggings",
	inventory_image = "xtrarmor_leggings_titanium.png",
	groups = {armor_legs = 30, armor_heal = 25,
		physics_speed = -0.02, physics_jump = -0.02}
})


armor:register_armor("xtrarmor:helmet_titanium", {
	description = S"Titanium Helmet",
	inventory_image = "xtrarmor_helmet_titanium.png",
	groups = {armor_head = 30, armor_heal = 15,
		physics_speed = -0.1, physics_jump = -0.01}
})

armor:register_armor("xtrarmor:helmet_shadow", {
	description = S"shadow helmet",
	inventory_image = "xtrarmor_helmet_shadow.png",
	groups = {armor_head = 10, armor_heal = 5,
		physics_speed = 0.02, physics_jump = 0.02}
})


armor:register_armor("xtrarmor:leggings_cold", {
	description = S"Cold Leggings",
	inventory_image = "xtrarmor_leggings_cold.png",
	groups = {armor_legs = 25, armor_heal = 15,
		physics_speed = 0.02, physics_jump = 0.02, armor_use=100}
})


armor:register_armor("xtrarmor:helmet_cold", {
	description = S"Cold Helmet",
	inventory_image = "xtrarmor_helmet_cold.png",
	groups = {armor_head = 5, armor_heal = 15,
		physics_speed = 0.1, physics_jump = 0.01, armor_use=100}
})

armor:register_armor("xtrarmor:chestplate_cold", {
	description = S"Cold Chestplate",
	inventory_image = "xtrarmor_chestplate_cold.png",
	groups = {armor_torso = 30, armor_heal = 15,
		physics_speed = 0.02, physics_jump = 0.02, armor_use=100}
})


minetest.register_tool("xtrarmor:shield_bright", {
	description = S("Bright Shield"),
	inventory_image = "shield2.png",
    groups = {armor_shield=33, armor_heal=19, armor_use=200, armor_fire=1},
    armor_groups = {fleshy=20},
    wear = 0,
})



minetest.register_node(":more_chests:wifi", {
	description = "Wifi Chest",
	tiles = {"wifi_top.png", "wifi_top.png", "wifi_side.png",
		"wifi_side.png", "wifi_side.png",
{name="wifi_front_animated.png", animation={type="vertical_frames", aspect_w=16, aspect_h=16, length=2.0}}
},
	paramtype2 = "facedir",
	groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2,},
	legacy_facedir_simple = true,
	sounds = default.node_sound_wood_defaults(),
	on_construct = function(pos)
		local meta = minetest.env:get_meta(pos)
		meta:set_string("formspec",
				"size[8,9]"..
				"list[current_player;more_chests:wifi;0,0;8,4;]"..
				"list[current_player;main;0,5;8,4;]")
		meta:set_string("infotext", "Wifi Chest")
	end,
	on_metadata_inventory_move = function(pos, from_list, from_index, to_list, to_index, count, player)
		minetest.log("action", player:get_player_name()..
				" moves stuff in wifi chest at "..minetest.pos_to_string(pos))
	end,
    on_metadata_inventory_put = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
				" moves stuff to wifi chest at "..minetest.pos_to_string(pos))
	end,
    on_metadata_inventory_take = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
				" takes stuff from wifi chest at "..minetest.pos_to_string(pos))
	end,
})

minetest.register_craft({
	output = 'more_chests:wifi',
	recipe = {
		{'default:wood','default:mese','default:wood'},
		{'default:wood','default:steel_ingot','default:wood'},
		{'default:wood','default:wood','default:wood'}
	}
})

minetest.register_on_joinplayer(function(player)
	local inv = player:get_inventory()
	inv:set_size("more_chests:wifi", 8*4)
end)
local function has_locked_chest_privilege(meta, player)
	if player:get_player_name() ~= meta:get_string("owner") then
		return false
	end
	return true
end





--The Pipe clipboard guy who check Foster didn't steal anything, who owns the WD40.

mobs:register_mob("mobs:veiko", {
	type = "npc",
	hp_min = 33,
	hp_max = 50,
	collisionbox = {-0.1, -1, -0.1, 0.1, 0.95, 0.1},
	visual = "upright_sprite",
	visual_size = {x=1,y=2},
	textures = {{"veiko_f.png","veiko_r.png"}},
	walk_velocity = 3,
	run_velocity = 7,
	follow = {"ugx:teleport_fruit"},
	jump = true,
	jump_height = 2,
	view_range = 90,
	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,
})

mobs:register_egg("mobs:veiko", "Veiko", "veiko_f.png")

--Robert's robot friend Joey, in its third and penultimate form, a domestic health-bot.

mobs:register_mob("mobs:jel", {
	type = "npc",
	hp_min = 33,
	hp_max = 50,
	collisionbox = {-0.1, -0.5, -0.1, 0.1, 0.45, 0.1},
	visual = "upright_sprite",
	visual_size = {x=1,y=1},
	textures = {{"jel_f.png","jel_r.png"}},
	walk_velocity = 3,
	run_velocity = 7,
	follow = {"default:steel_ingot"},
	jump = true,
	jump_height = 4,
	view_range = 69,
	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,
})

mobs:register_egg("mobs:jel", "Jel", "jel_f.png")


--Lamb the supervisor of the pipe factory from Beneath a Steel Sky

mobs:register_mob("mobs:inokuin", {
	type = "npc",
	hp_min = 33,
	hp_max = 50,
	collisionbox = {-0.1, -1, -0.1, 0.1, 0.95, 0.1},
	visual = "upright_sprite",
	visual_size = {x=1,y=2},
	textures = {{"inokuin_f_" ..math.random(1,2).. ".png","inokuin_r_" ..math.random(1,2).. ".png"}},
	walk_velocity = 4,
	run_velocity = 7,
	follow = {"default:apple"},
	jump = true,
	jump_height = 2,
	view_range = 60,
	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,
})

mobs:register_egg("mobs:inokuin", "Inokuin", "inokuin_f_0.png")


mobs:register_mob("mobs:etoll", {
	type = "npc",
	hp_min = 33,
	hp_max = 50,
	collisionbox = {-0.1, -1, -0.1, 0.1, 0.95, 0.1},
	visual = "upright_sprite",
	visual_size = {x=1,y=2},
	textures = {{"etoll_f.png","etoll_r.png"}},
	walk_velocity = 5,
	run_velocity = 5,
	follow = {"mobs:etoll"},
	jump = true,
	jump_height = 2,
	view_range = 55,
	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,
})

mobs:register_egg("mobs:etoll", "Etoll", "etoll_f.png")

minetest.register_craft({
	output = "darks:dark_chestplate",
	recipe = {
		{"darks:darksubstance", "", "darks:darksubstance"},
		{"darks:darksubstance", "darks:darksubstance", "darks:darksubstance"},
		{"darks:darksubstance", "darks:darksubstance", "darks:darksubstance"},
	},
})

minetest.register_craft({
	output = "darks:dark_leggings",
	recipe = {
		{"darks:darksubstance", "darks:darksubstance", "darks:darksubstance"},
		{"darks:darksubstance", "", "darks:darksubstance"},
		{"darks:darksubstance", "", "darks:darksubstance"},
	},
})

minetest.register_craft({
	output = "darks:dark_boots",
	recipe = {
		{"darks:darksubstance", "", "darks:darksubstance"},
		{"darks:darksubstance", "", "darks:darksubstance"},
	},
})

minetest.register_craft({
	output = "darks:dark_helmet",
	recipe = {
		{"darks:darksubstance", "darks:darksubstance", "darks:darksubstance"},
		{"darks:darksubstance", "", "darks:darksubstance"},
		{"", "", ""},
	},
})




-- 8 viscosity example liquids
for v=0,7 do
	minetest.register_node(":testnodes:liquid"..v, {
		description = string.format(S("flowing test liquid %i"), v),
		inventory_image = minetest.inventorycube("supplemental_testliquid"..v..".png"),
		drawtype = "flowingliquid",
		tiles = {"supplemental_testliquid"..v..".png"},
		special_tiles = {
			{
				name="supplemental_testliquid"..v..".png",
				backface_culling=false,
			},
			{
				name="supplemental_testliquid"..v..".png",
				backface_culling=true,
			},

		},
		use_texture_alpha = "blend",
		paramtype = "light",
		paramtype2 = "flowingliquid",
		walkable = false,
		pointable = false,
		diggable = false,
		buildable_to = true,
		drop = "",
		drowning = 1,
		liquidtype = "flowing",
		liquid_alternative_flowing = "testnodes:liquid"..v,
		liquid_alternative_source = "testnodes:liquidsource"..v,
		liquid_viscosity = v,
		groups = {not_in_creative_inventory = 1},
		sounds = default.node_sound_water_defaults(),
	})

	minetest.register_node(":testnodes:liquidsource"..v, {
		description = string.format(S("test liquid source %i"), v),
		inventory_image = minetest.inventorycube("supplemental_testliquid"..v..".png"),
		drawtype = "liquid",
		special_tiles = {
			{
				name="supplemental_testliquid"..v..".png",
				backface_culling=false,
			},
		},
		tiles = {"supplemental_testliquid"..v..".png",},
		use_texture_alpha = "blend",
		paramtype = "light",
		walkable = false,
		pointable = false,
		diggable = false,
		buildable_to = true,
		drop = "",
		drowning = 1,
		liquidtype = "source",
		liquid_alternative_flowing = "testnodes:liquid"..v,
		liquid_alternative_source = "testnodes:liquidsource"..v,
		liquid_viscosity = v,
		groups = {},
		sounds = default.node_sound_water_defaults(),
	})

	minetest.register_alias("supplemental:liquid"..v, ":testnodes:liquid"..v)
	minetest.register_alias("supplemental:liquidsource"..v, ":testnodes:liquidsource"..v)
end



minetest.register_node(":tutorial:shield_2",{
	description = S("mounted shield"),
	tiles = {"castle_shield_side_2.png", "castle_shield_side_2.png", "castle_shield_side_2.png", "castle_shield_side_2.png", "castle_shield_back.png", "castle_shield_front_2.png"},
	drawtype="nodebox",
	paramtype2 = "facedir",
	paramtype = "light",
	groups={creative_breakable=1},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.500000,-0.125000,0.375000,0.500000,0.500000,0.500000}, --NodeBox 1
			{-0.437500,-0.312500,0.375000,0.425000,0.500000,0.500000}, --NodeBox 2
			{-0.312500,-0.437500,0.375000,0.312500,0.500000,0.500000}, --NodeBox 3
			{-0.187500,-0.500000,0.375000,0.187500,0.500000,0.500000}, --NodeBox 4
		},
	},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.500000,-0.500000,0.375000,0.500000,0.500000,0.500000}, --NodeBox 1
		},
	},			
	walkable = false,
})


minetest.register_node(":tutorial:day", {
	description = S("day/night switch (day)"),
	tiles = { "tutorial_day.png" },
	groups = {creative_breakable=1},
	on_rightclick = function(pos, node, clicker, itemstack, pointed_thing)
		minetest.set_timeofday(0)
		minetest.set_node(pos, {name="tutorial:night"})
	end
})
minetest.register_node(":tutorial:night", {
	description = S("day/night switch (night)"),
	tiles = { "tutorial_night.png" },
	groups = {creative_breakable=1},
	on_rightclick = function(pos, node, clicker, itemstack, pointed_thing)
		minetest.set_timeofday(0.5)
		minetest.set_node(pos, {name="tutorial:day"})
	end
})


local mcl = minetest.get_modpath("mcl_core") ~= nil

-- Npc by TenPlus1



mobs:register_mob("mobs:npc", {
	type = "npc",
	passive = false,
	damage = 3,
	attack_type = "dogfight",
	attack_monsters = true,
	attack_npcs = false,
	owner_loyal = true,
	pathfinding = true,
	hp_min = 10,
	hp_max = 20,
	armor = 100,
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "character.b3d",
	drawtype = "front",
	textures = {
		{"character.png"},
		{"character_2.png"},
		{"character_3.png"},
		{"character_14.png"},
		{"character_40.png"},
		{"character_50.png"},
		{"character_54.png"},
		{"character_64.png"},
     {"character_78.png"},
     {"character_91.png"},
     {"character_113.png"},
     {"character_122.png"},
     {"character_126.png"}
	},
	child_texture = {
		{"baby.png"} -- derpy baby by AmirDerAssassine
	},
	makes_footstep_sound = true,
	sounds = {},
	walk_velocity = 2,
	run_velocity = 3,
	jump = true,
	drops = {
		{name = mcl and "mcl_core:wood" or "default:wood", chance = 1, min = 1, max = 3},
		{name = mcl and "mcl_core:apple" or "default:apple", chance = 2, min = 1, max = 2},
		{name = mcl and "mcl_tools:axe_stone" or "default:axe_stone", chance = 5, min = 1, max = 1}
	},
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	follow = {
		mcl and "mcl_farming:bread" or "farming:bread",
		mcl and "mcl_mobitems:cooked_beef"or "mobs:meat",
		mcl and "mcl_core:diamond" or "default:diamond"
	},
	view_range = 15,
	owner = "",
	order = "wander",
	fear_height = 3,
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 189, --200
		punch_end = 198 --219
        
},

        on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,

})


-- register spawn egg
mobs:register_egg("mobs:npc", S("Npc"),
		mcl and "default_stone_brick.png" or "default_brick.png", 1)



-- spawn NPC in world
if not mobs.custom_spawn_npc then

	mobs:spawn({
		name = "mobs_npc:npc",
		nodes = {mcl and "mcl_core:stonebrick" or "default:brick"},
		neighbors = {mcl and "mcl_flowers:tallgrass" or "default:grass_3"},
		min_light = 10,
		chance = 10000,
		active_object_count = 1,
		min_height = 0,
		day_toggle = true
	})
end

-- dev/init.lua

minetest.register_craft({
    output = "xtrarmor:chestplate_reinforcedleather",
    recipe = {
        {"mobs:leather", "default:steel_ingot", "mobs:leather"},
        {"mobs:leather", "default:steel_ingot", "mobs:leather"},
        {"mobs:leather", "default:steel_ingot", "mobs:leather"},
    },
})

-- dev/init.lua

minetest.register_craft({
    output = "xtrarmor:leggings_reinforcedleather",
    recipe = {
        {"default:steel_ingot", "mobs:leather", "default:steel_ingot"},
        {"mobs:leather", "", "mobs:leather"},
        {"mobs:leather", "", "mobs:leather"},
    },
})

-- dev/init.lua

minetest.register_craft({
    output = "xtrarmor:boots_reinforcedleather",
    recipe = {
        {"", "", ""},
        {"mobs:leather", "", "mobs:leather"},
        {"default:steel_ingot", "", "default:steel_ingot"},
    },
})

-- dev/init.lua

minetest.register_craft({
    output = "xtrarmor:helmet_reinforcedleather",
    recipe = {
        {"mobs:leather", "default:steel_ingot", "mobs:leather"},
        {"mobs:leather", "", "mobs:leather"},
        {"", "", ""},
    },
})

-- dev/init.lua

minetest.register_craft({
    output = "xtrarmor:boots",
    recipe = {
        {"default:tinblock", "", "default:tinblock"},
        {"default:steelblock", "", "default:steelblock"},
    },
})
-- dev/init.lua

minetest.register_craft({
    output = "xtrarmor:leggings",
    recipe = {
        {"default:steelblock", "default:tinblock", "default:steelblock"},
        {"default:steelblock", "", "default:steelblock"},
        {"default:steelblock", "", "default:tinblock"},
    },
})

-- dev/init.lua

minetest.register_craft({
    output = "xtrarmor:chestplate",
    recipe = {
        {"default:steelblock", "default:tinblock", "default:steelblock"},
        {"default:steelblock", "ugx:super_compressed_rainbow_block", "default:steelblock"},
        {"", "default:tinblock", ""},
    },
})


-- dev/init.lua

minetest.register_craft({
    output = "xtrarmor:helmet_reinforcedleather",
    recipe = {
        {"mobs:leather", "default:steel_ingot", "mobs:leather"},
        {"mobs:leather", "", "mobs:leather"},
        {"", "", ""},
    },
})


minetest.register_craft({
    output = "xtrarmor:chestplate",
    recipe = {
        {"default:steelblock", "default:tinblock", "default:steelblock"},
        {"default:steelblock", "ugx:super_condensed_rainbow_block", "default:steelblock"},
        {"", "default:tinblock", ""},
    },
})

minetest.register_craft({
    output = "xtrarmor:pants",
    recipe = {
        {"default:steelblock", "default:tinblock", "default:steelblock"},
        {"default:steelblock", "", "default:steelblock"},
        {"default:tinblock", "", "default:tinblock"},
    },
})

-- dev/init.lua

minetest.register_craft({
    output = "xtrarmor:helmet",
    recipe = {
        {"default:obsidian_glass", "default:tinblock", "default:obsidian_glass"},
        {"default:steelblock", "default:obsidian_glass", "default:steelblock"},
        {"", "", ""},
    },
})

minetest.register_craft({
    output = "xtrarmor:helmet_emerald",
    recipe = {
        {"oresplus:emerald", "oresplus:emerald", "oresplus:emerald"},
        {"oresplus:emerald", "", "oresplus:emerald"},
        {"", "", ""},
    },
})

minetest.register_craft({
    output = "xtrarmor:boots_emerald",
    recipe = {
        {"", "", ""},
        {"oresplus:emerald", "", "oresplus:emerald"},
        {"oresplus:emerald", "", "oresplus:emerald"},
    },
})

minetest.register_craft({
    output = "xtrarmor:leggings_emerald",
    recipe = {
        {"oresplus:emerald", "", "oresplus:emerald"},
        {"oresplus:emerald", "oresplus:emerald", "oresplus:emerald"},
        {"oresplus:emerald", "", "oresplus:emerald"},
    },
})

minetest.register_craft({
    output = "xtrarmor:chestplate_emerald",
    recipe = {
        {"oresplus:emerald", "oresplus:emerald", "oresplus:emerald"},
        {"oresplus:emerald", "", "oresplus:emerald"},
        {"oresplus:emerald", "oresplus:emerald", "oresplus:emerald"},
    },
})

minetest.register_craft({
    output = "xtrarmor:chestplate_mese",
    recipe = {
        {"default:mese_block", "default:mese_block", "default:mese_block"},
        {"default:mese_block", "", "default:mese_block"},
        {"default:mese_block", "default:mese_block", "default:mese_block"},
    },
})

minetest.register_craft({
    output = "xtrarmor:leggings_mese",
    recipe = {
        {"default:mese_block", "default:mese_block", "default:mese_block"},
        {"default:mese_block", "", "default:mese_block"},
        {"default:mese_block", "", "default:mese_block"},
    },
})

minetest.register_craft({
    output = "xtrarmor:boots_mese",
    recipe = {
        {"", "", ""},
        {"default:mese_block", "", "default:mese_block"},
        {"default:mese_block", "", "default:mese_block"},
    },
})

minetest.register_craft({
    output = "xtrarmor:helmet_mese",
    recipe = {
        {"default:mese_block", "default:mese_block", "default:mese_block"},
        {"default:mese_block", "", "default:mese_block"},
        {"", "", ""},
    },
})



minetest.register_craft({
    output = "xtrarmor:shield_bright",
    recipe = {
        {"default:meselamp", "default:meselamp", "default:meselamp"},
        {"default:meselamp", "default:diamondblock", "default:meselamp"},
        {"", "infinitytools:infinityblock", ""},
    },
})




-- dev/init.lua

minetest.register_tool(":hotsword", {
    inventory_image = "hotsword.png",
    tool_capabilities = {
        full_punch_interval = 0.5,
        max_drop_level = 1,
        groupcaps = {
            cracky = {times = {[1] = 1.5, [2] = 0.7, [3] = 0.2}, uses = 50, maxlevel = 3},
        },
        damage_groups = {fleshy = 25},
    },
    sound = {breaks = "default_tool_breaks"},
})