local panes_list = {
	{"white", "White", "ffffff", }, {"blue", "Blue", "0000FF", },
	{"cyan", "Cyan", "00FFFF", }, {"green", "Green", "00FF00", },
	{"magenta", "Magenta", "FF00FF", }, {"orange", "Orange", "FF6103", },
	{"violet", "Purple", "800080", }, {"red", "Red", "FF0000", },
	{"yellow", "Yellow", "FFFF00", },
}

for i in ipairs(panes_list) do
	local name = panes_list[i][1]
	local description = panes_list[i][2]
	local colour = panes_list[i][3]
	local tex = "abriglass_plainglass.png^[colorize:#"..colour..":122"

	abripanes.register_pane("abriglass_pane_"..name, {
		description = description.." Glass Pane",
		textures = {tex, tex, tex},
		groups = {cracky = 3},
		use_texture_alpha = "blend",
		wield_image = tex,
     backface_culling = true,
		inventory_image = tex,
		sounds = default.node_sound_glass_defaults(),
		recipe = {
			{"default:glass", "default:glass", "default:glass",},
			{"default:glass", "default:glass", "default:glass",},
			{"","dye:"..name,"",},
		}
	})
end








minetest.register_node(":frame", {
	light_source = 8,
   use_texture_alpha = "blend",
	drawtype = "allfaces",
	tiles = {"frame2.png"},
   groups = {unbreakable=1, not_in_creative_inventory=1},
})




minetest.register_node(":f", {
	drawtype = "allfaces",
	use_texture_alpha = "blend",
	tiles = {"eaves.png"},
   groups = {unbreakable=1, not_in_creative_inventory=1},
   walkable = false,
})




minetest.register_node(":poison", {
	drawtype = "signlike",
	paramtype = "light",
  use_texture_alpha = "clip",
	paramtype2 = "wallmounted",
	tiles = { "posen.png" },
   damage_per_second = 2,


	walkable = false,
	groups = { unbreakable = 1, not_in_creative_inventory = 1},
	sunlight_propagates = true,
})


minetest.register_node(":dark", {
	drawtype = "signlike",
   use_texture_alpha = "clip",
	paramtype = "light",
	paramtype2 = "wallmounted",
	tiles = { "blacc.png" },


	walkable = false,
	groups = { unbreakable = 1, not_in_creative_inventory = 1},
	sunlight_propagates = true,
})


minetest.register_node(":testnodes:flysign", {
	drawtype = "signlike",
  use_texture_alpha = "clip",
	paramtype = "light",
	paramtype2 = "wallmounted",
	tiles = { "flai.png" },


	walkable = false,
	groups = {choppy=1, cracky=1},
	sunlight_propagates = true,
})

minetest.register_node(":caverealms:shaft", {
	drawtype = "signlike",
  use_texture_alpha = "clip",
	paramtype = "light",
	paramtype2 = "wallmounted",
	tiles = { "shaft.png" },


	walkable = false,
	groups = { cracky = 3},
	sunlight_propagates = true,
})



minetest.register_node(":tst",{
drawtype = "mesh",
mesh = "testnodes_marble_metal.obj",
tiles = { "twist.png" },
paramtype = "light",
visual_scale = 291,
use_texture_alpha = "blend",
groups = {choppy=1, not_in_creative_inventory=1},
})



minetest.register_node(":ni",{
drawtype = "mesh",
mesh = "testnodes_marble_metal.obj",
description = "M",
use_texture_alpha = "clip",
tiles = { "eaves.png" },
paramtype = "light",
visual_scale = 291,
groups = {choppy=1, not_in_creative_inventory=1},
})


minetest.register_tool(":sword", {
	inventory_image = "sword.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=9,
		damage_groups = {fleshy=22, not_in_creative_inventory=1},
	}
})


minetest.register_node(":o:hno", {
	drawtype = "allfaces",
	use_texture_alpha = "blend",
	tiles = {"39r.png"},
   groups = {unbreakable=1, not_in_creative_inventory=1},
})


local register_node = minetest.register_node


register_node(':3stone', {
    tiles = { 'void_essential_stone.png' },
    groups = {choppy=1, not_in_creative_inventory=1},
    is_ground_content = true
})

register_node(':water_s0urce', {
    tiles = { 'void_essential_water_source.png' },
    groups = {choppy=1, not_in_creative_inventory=1},
    is_ground_content = true
})


minetest.register_node(":9292020202020200202020",{
drawtype = "mesh",
mesh = "testnodes_marble_metal.obj",
tiles = { "flai.png" },
use_texture_alpha = "clip",
light_source = 14,
paramtype = "light",
visual_scale = 222,
groups = {choppy=1, not_in_creative_inventory=1},
})


minetest.register_node(":363552524241413q424228282828282",{
drawtype = "mesh",
mesh = "testnodes_marble_metal.obj",
use_texture_alpha = "blend",
tiles = { "wellspring.png" },
paramtype = "light",
visual_scale = 200,
groups = {choppy=1, not_in_creative_inventory=1},
})






minetest.register_node(":1:378q28378q28829292", {
	wield_scale = {x = 9, y = 9, z = 9},
  visual_scale = 22,
	tiles = {{
		name = "0Y0.png",
		animation = {
			type = "vertical_frames",
			aspect_w = 16,
			aspect_h = 16,
			length = 0.3
		},
	}},
	drawtype = "allfaces",
	paramtype = "light",
  use_texture_alpha = "clip",
	sunlight_propagates = true,
	light_source = 14,
	walkable = false,
	groups = {vessel = 1, dig_immediate = 3, attached_node = 1},
})


minetest.register_node(":1:foo", {
	drawtype = "liquid",
	tiles = {
		"void_essential_water_source.png^[colorize:#0000FF:127^[opacity:190",
	},
	special_tiles = {
		{name = "void_essential_water_source.png^[colorize:#0000FF:17^[opacity:190",
			backface_culling = false},
		{name = "void_essential_water_source.png^[colorize:#0000FF:19^[opacity:120",
			backface_culling = true},
	},
	liquids_pointable = true,
	liquidtype = "source",
	liquid_alternative_flowing = "1:foo",
	liquid_alternative_source = "1:foo",
	liquid_renewable = false,
	liquid_range = 0,
	liquid_viscosity = 9,
	use_texture_alpha = "blend",
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	post_effect_color = {a = 64, r = 20, g = 69, b = 200},
	sounds = {
		footstep = { name = "soundstuff_sinus", gain = 1.0 },
	}
})



minetest.register_node(":1:fall", {
	tiles = {"command.png"},
	groups = {cracky=3},
   use_texture_alpha = "clip",
	sounds = {
		footstep = { name = "leave_noise", gain = 1.0 },
	}
})

