abripanes
===

Mod for Minetest by Shara RedCat which adds faintly glowing coloured glass panes.These can be used for stained glass windows or for gentle lighting. 

NOTE: This mod is only fully functional from version 0.4.15.


Crafting
---------

Coloured glass panes can be made from six glass nodes and the matching dye.


Licenses and Attribution 
-----------------------

Code for this mod is released under MIT (https://opensource.org/licenses/MIT).

Textures for this mod are released under CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/), attribution: Shara RedCat.
