function abripanes.register_pane(name, def)
	for i = 1, 15 do
		minetest.register_alias("xpanes:" .. name .. "_" .. i, "xpanes:" .. name .. "_flat")
	end

	local flatgroups = table.copy(def.groups)
	flatgroups.pane = 1
	minetest.register_node(":xpanes:" .. name .. "_flat", {
		description = def.description,
		drawtype = "nodebox",
		paramtype = "light",
		is_ground_content = false,
		sunlight_propagates = true,
     backface_culling = true,
		inventory_image = def.inventory_image,
		wield_image = def.wield_image,
		paramtype2 = "facedir",
		use_texture_alpha = "blend",
		light_source = 4,
		tiles = {def.textures[3], def.textures[3], def.textures[1]},
		groups = flatgroups,
		drop = "xpanes:" .. name .. "_flat",
		sounds = def.sounds,
		node_box = {
			type = "fixed",
			fixed = {{-1/2, -1/2, -1/32, 1/2, 1/2, 1/32}},
		},
		selection_box = {
			type = "fixed",
			fixed = {{-1/2, -1/2, -1/32, 1/2, 1/2, 1/32}},
		},
		connect_sides = { "left", "right" },
	})

	local groups = table.copy(def.groups)
	groups.pane = 1
	groups.not_in_creative_inventory = 1
	minetest.register_node(":xpanes:" .. name, {
		drawtype = "nodebox",
		paramtype = "light",
		is_ground_content = false,
		sunlight_propagates = true,
		use_texture_alpha = "blend",
		light_source = 4,
     backface_culling = true,
		description = def.description,
		tiles = {def.textures[3], def.textures[3], def.textures[1]},
		groups = groups,
		drop = "xpanes:" .. name .. "_flat",
		sounds = def.sounds,
		node_box = {
			type = "connected",
			fixed = {{-1/32, -1/2, -1/32, 1/32, 1/2, 1/32}},
			connect_front = {{-1/32, -1/2, -1/2, 1/32, 1/2, -1/32}},
			connect_left = {{-1/2, -1/2, -1/32, -1/32, 1/2, 1/32}},
			connect_back = {{-1/32, -1/2, 1/32, 1/32, 1/2, 1/2}},
			connect_right = {{1/32, -1/2, -1/32, 1/2, 1/2, 1/32}},
		},
		connects_to = {"group:pane", "group:stone", "group:glass", "group:wood", "group:tree"},
	})

	minetest.register_craft({
		output = "xpanes:" .. name .. "_flat 16",
		recipe = def.recipe
	})
end

minetest.register_tool(":modname:healing_staff", {
    description = "Healing Staff",
    inventory_image = "modname_healing_staff.png",
    wield_image = "modname_healing_staff.png",
    on_use = function(itemstack, user, pointed_thing)
        local pos = user:get_pos()
        local wielded_item = user:get_wielded_item()
        local meta = wielded_item:get_meta()
        
        if pointed_thing.type == "object" then
            local object = pointed_thing.ref
            if object:is_player() then
                local player_name = object:get_player_name()
                local hp = object:get_hp()
                if hp < 20 then
                    object:set_hp(hp + 5)
                    minetest.sound_play("healing_sound", {pos = pos, max_hear_distance = 10})
                end
            end
        elseif pointed_thing.type == "node" then
            local objects = minetest.get_objects_inside_radius(pointed_thing.above, 4)
            for _, object in ipairs(objects) do
                if object:is_player() then
                    local player_name = object:get_player_name()
                    local hp = object:get_hp()
                    if hp < 20 then
                        object:set_hp(hp + 5)
                        minetest.sound_play("healing_sound", {pos = pos, max_hear_distance = 10})
                        minetest.add_particlespawner({
                            amount = 20,
                            time = 0.1,
                            minpos = {x = pointed_thing.above.x - 0.5, y = pointed_thing.above.y, z = pointed_thing.above.z - 0.5},
                            maxpos = {x = pointed_thing.above.x + 0.5, y = pointed_thing.above.y + 1, z = pointed_thing.above.z + 0.5},
                            minvel = {x = -0.5, y = 2, z = -0.5},
                            maxvel = {x = 0.5, y = 3, z = 0.5},
                            minacc = {x = 0, y = -1, z = 0},
                            maxacc = {x = 0, y = -1, z = 0},
                            minexptime = 1,
                            maxexptime = 2,
                            minsize = 2,
                            maxsize = 4,
                            collisiondetection = true,
                            collision_removal = true,
                            vertical = true,
                            texture = "bloodstone_bloodstone_heal_particle.png",
                        })
                    end
                end
            end
        end
        return itemstack
    end,
})