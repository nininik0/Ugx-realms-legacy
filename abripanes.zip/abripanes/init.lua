local modpath = minetest.get_modpath("abripanes").. DIR_DELIM

abripanes = {}

dofile(modpath.."api.lua")
dofile(modpath.."nodes.lua")

abripanes.init = true


minetest.register_node("abripanes:fullglassblock", {
   use_texture_alpha = "blend",
  drawtype = "glasslike",
   sunlight_propagates = true,
  paramtype = "light",
	tiles = {"abriglass_plainglass.png"},
   light_source = 1,
	groups = {cracky=1},
})


-- Define the liquid node
minetest.register_node("abripanes:liquid", {
    description = "Liquid",
    drawtype = "liquid",
    tiles = {
        {
            name = "663.png",
            animation = {
                type = "vertical_frames",
                aspect_w = 16,
                aspect_h = 16,
                length = 2
            }
        }
    },
    special_tiles = {
        -- Additional liquid tiles for variation
        {
            name = "663.png",
            animation = {
                type = "vertical_frames",
                aspect_w = 16,
                aspect_h = 16,
                length = 2
            },
            backface_culling = false
        }
    },
    alpha = 160,
    damage_per_second = 1,
    paramtype = "light",
    paramtype2 = "flowingliquid",
    pointable = false,
    liquids_pointable = true,
    groups = {liquid = 3, not_in_creative_inventory = 1},
    liquidtype = "source",
    liquid_alternative_flowing = "abripanes:liquid_flowing",
    liquid_alternative_source = "abripanes:liquid",
    liquid_viscosity = 5,
    liquid_range = 5,
    post_effect_color = {a = 103, r = 255, g = 255, b = 255},
    drop = "",
    walkable = false,
    drowning = 91,
    liquid_renewable = false,
    light_source = 6,
    on_construct = function(pos)
        minetest.get_node_timer(pos):start(math.random(10, 20))
    end,
    on_timer = function(pos, elapsed)
        -- Emit smoke periodically
        minetest.add_particlespawner({
            amount = 1,
            time = 0.1,
            minpos = {x = pos.x - 0.2, y = pos.y + 0.2, z = pos.z - 0.2},
            maxpos = {x = pos.x + 0.2, y = pos.y + 0.2, z = pos.z + 0.2},
            minvel = {x = 0, y = 0.5, z = 0},
            maxvel = {x = 0, y = 1, z = 0},
            minacc = {x = 0, y = 0, z = 0},
            maxacc = {x = 0, y = 0, z = 0},
            minexptime = 15,
            maxexptime = 35,
            minsize = 4,
            maxsize = 14,
            collisiondetection = true,
            vertical = true,
            texture = "smoke_puff.png",
            animation = {
                type = "vertical_frames",
                aspect_w = 16,
                aspect_h = 16,
                length = 3
            }
        })
        minetest.get_node_timer(pos):start(math.random(10, 20))
    end
})

-- Define the flowing version of the liquid
minetest.register_node("abripanes:liquid_flowing", {
    description = "Flowing Liquid",
    drawtype = "flowingliquid",
    tiles = {"663.png"},
    special_tiles = {
        {
            name = "663.png",
            backface_culling = false,
            animation = {
                type = "vertical_frames",
                aspect_w = 16,
                aspect_h = 16,
                length = 2
            }
        }
    },
    alpha = 160,
    paramtype = "light",
    paramtype2 = "flowingliquid",
    groups = {liquid = 3, not_in_creative_inventory = 1, liquid = 4},
    liquidtype = "flowing",
    liquid_alternative_flowing = "abripanes:liquid_flowing",
    liquid_alternative_source = "abripanes:liquid",
    liquid_viscosity = 5,
    pointable = false,
    liquids_pointable = true,
    liquid_range = 5,
    post_effect_color = {a = 103, r = 255, g = 255, b = 255},
    drop = "",
    walkable = false,
    drowning = 91,
    damage_per_second = 1,
    liquid_renewable = false,
    light_source = 6,
    on_construct = function(pos)
        minetest.get_node_timer(pos):start(math.random(10, 20))
    end,
    on_timer = function(pos, elapsed)
        -- Emit smoke periodically
        minetest.add_particlespawner({
            amount = 5,
            time = 0.1,
            minpos = {x = pos.x - 0.2, y = pos.y + 0.2, z = pos.z - 0.2},
            maxpos = {x = pos.x + 0.2, y = pos.y + 0.2, z = pos.z + 0.2},
            minvel = {x = 0, y = 0.5, z = 0},
            maxvel = {x = 0, y = 1, z = 0},
            minacc = {x = 0, y = 0, z = 0},
            maxacc = {x = 0, y = 0, z = 0},
            minexptime = 15,
            maxexptime = 35,
            minsize = 4,
            maxsize = 14,
            collisiondetection = true,
            vertical = true,
            texture = "smoke_puff.png",
            animation = {
                type = "vertical_frames",
                aspect_w = 16,
                aspect_h = 16,
                length = 3
            }
        })
        minetest.get_node_timer(pos):start(math.random(10, 20))
    end
})



minetest.register_node(":default:no", {
	description = "PORTAL DO NOT PLACE",
	drawtype = "signlike",
	visual_scale = 3.0,
	tiles = {"0n0.png"},
   drop = "ignore",
	inventory_image = "0n0.png",
	use_texture_alpha = true,
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	light_source = 10,
	walkable = false,
	is_ground_content = true,
	selection_box = {
		type = "wallmounted",
		fixed = {-0.5, -0.5, -0.5, 0.5, -0.4, 0.5}
	},
	on_rightclick = function(pos, node, _)
	if minetest.get_modpath("mobs") then
		minetest.after(0.5, function()
		minetest.set_node(pos, {name="default:portal2", param2=node.param2})
		minetest.add_particlespawner(
			25, --amount
			2, --time
			{x=pos.x-1, y=pos.y, z=pos.z-1}, --minpos
			{x=pos.x+1, y=pos.y, z=pos.z+1}, --maxpos
			{x=-0, y=-0, z=-0}, --minvel
			{x=0, y=0, z=0}, --maxvel
			{x=-0.5,y=1,z=-0.5}, --minacc
			{x=0.5,y=1,z=0.5}, --maxacc
			1, --minexptime
			1.5, --maxexptime
			5, --minsize
			6, --maxsize
			false, --collisiondetection
			"fire_basic_flame.png" --texture
		)
		end)
		end
	end,
	groups = {cracky=3,dig_immediate=3, not_in_creative_inventory=1},
})

minetest.register_node(":default:portal2", {
	description = "portal",
	drawtype = "signlike",
	visual_scale = 3.0,
	tiles = {"horror_portal.png"},
	inventory_image = "horror_portal.png",
	use_texture_alpha = true,
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	light_source = 14,
	walkable = false,
  drop = "default:placeholder",
	is_ground_content = true,
	selection_box = {
		type = "wallmounted",
		fixed = {-0.5, -0.5, -0.5, 0.5, -0.4, 0.5}
	},
	on_construct = function(pos)
		minetest.after(2, function()
     minetest.env:add_entity(pos, "mobs_monster:eyeboss")
     minetest.env:add_entity(pos, "mobs_monster:eyeboss")
		minetest.remove_node(pos)
		end)
	end,
	groups = {cracky=3,dig_immediate=3, not_in_creative_inventory=1},
})

minetest.register_node("abripanes:ultraspamblock", {
    description = "Spam Block",
    tiles = {"default_cloud.png^spam.png"},
    light_source = 6,
    groups = {snappy = 3},
    sounds = default.node_sound_stone_defaults(),
    on_rightclick = function(pos, node, clicker)
        if clicker and clicker:is_player() then
            local player_name = clicker:get_player_name()
            minetest.chat_send_player(player_name, "hi how are you SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM :D ")
        end
    end,
})

minetest.register_craft({
    output = "lenny_block:block",
    recipe = {
        {"default:stone", "default:stone", "default:stone"},
        {"default:stone", "dye:whieyy3y3ywuw7wushsh7w8w827ehehdte", "default:stone"},
        {"default:stone", "default:stone", "default:stone"},
    },
})

minetest.register_abm({
    nodenames = {"abripanes:ultraspamblock"},
    interval = 2,
    chance = 1,
    action = function(pos, node, active_object_count, active_object_count_wider)
        local minp = vector.subtract(pos, 0.5)
        local maxp = vector.add(pos, 0.5)
        minetest.add_particlespawner({
            amount = 50,
            time = 2,
            minpos = minp,
            maxpos = maxp,
            minvel = {x = -1, y = -1, z = -1},
            maxvel = {x = 1, y = 1, z = 1},
            minacc = {x = -1, y = -1, z = -1},
            maxacc = {x = 1, y = 1, z = 1},
            minexptime = 1,
            maxexptime = 2,
            minsize = 0.5,
            maxsize = 5.5,
            collisiondetection = true,
            vertical = false,
            texture = "spam.png",
            glow = 14,
        })
    end,
})

minetest.register_craft({
    output = "xdecor:crafting_guide",
    recipe = {
        {"default:book", "ugx:chisel"},
    },
})

