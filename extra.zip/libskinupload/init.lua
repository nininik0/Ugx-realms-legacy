libskinupload = {
    notifications = {},
    reviewers = {}
}

local mcl = not not minetest.get_modpath("mcl_skins")
local it = not not minetest.get_modpath("itbase")

if mcl then
    --Override mcl_skins to degrade gracefully instead of giving an unknown item
    local _get_node_id_by_player = mcl_skins.get_node_id_by_player
    function mcl_skins.get_node_id_by_player(p)
        local out = _get_node_id_by_player(p)
        if not minetest.registered_items["mcl_meshhand:"..out] then
            return "mcl_skins_character_1_female_surv"
        else
            return out
        end
    end
end

-- Shim for 3d_armor
if minetest.get_modpath("3d_armor") then
    local _get_player_skin = armor.get_player_skin
    function armor.get_player_skin(self, name)
        local id = libskinupload.get_skin_id(name)
        if id == "" then
            return _get_player_skin(self, name)
        end
        return "libskinupload_uploaded_skin_"..id..".png"
    end
end

-- Shim for u_skins
if minetest.get_modpath("u_skins") then
    local gt = u_skins.get_type
    u_skins.get_type = function(tx)
        local out = gt(tx)
        if out then return out else return u_skins.type.MODEL end
    end
end

minetest.register_chatcommand("whatis", {
    func = function(name)
        local p = minetest.get_player_by_name(name)
        minetest.chat_send_player(name, minetest.serialize(p:get_properties().textures))
    end
})

local function player_model(p, tx, model)
    if mcl then
        return (model and "mcl_armor_character_female.b3d" or "mcl_armor_character.b3d")..";"..tx..",blank.png"
    elseif it then
        return "player.b3d;"..tx
    end
    return "character.b3d;"..tx
end

local db = minetest.get_mod_storage()
local storage_dir = minetest.get_worldpath().."/libskinupload_skins/"
local storage_dir_meta = minetest.get_worldpath().."/libskinupload_meta/"
minetest.mkdir(storage_dir)
minetest.mkdir(storage_dir_meta)


    for _, x in pairs(minetest.get_dir_list(storage_dir, false)) do
        minetest.after(0, function()
            minetest.dynamic_add_media({
                filepath = storage_dir..x,
                filename = x
            }, function() end)
        end)
        if mcl then
            local f = io.open(storage_dir_meta..string.gsub(x, ".png", ".json"))
            local meta
            if f then
                meta = minetest.parse_json(f:read("a"))
                f:close()
            end
            mcl_skins.register_simple_skin{texture = x, slim_arms = meta.msa or false}
        end
    end

minetest.register_privilege("skin_review", {
    on_grant = function(name)
        libskinupload.reviewers[name] = true
        db:set_string("reviewers", minetest.serialize(libskinupload.reviewers))
    end,
    on_revoke = function(name)
        libskinupload.reviewers[name] = nil
        db:set_string("reviewers", minetest.serialize(libskinupload.reviewers))
    end,
    give_to_singleplayer = false,
    give_to_admin = false
})
minetest.register_privilege("no_skin_upload", {
    give_to_singleplayer = false,
    give_to_admin = false
})

libskinupload.notifications = minetest.deserialize(db:get_string("notifications")) or {}
libskinupload.reviewers = minetest.deserialize(db:get_string("reviewers")) or {}

local function markdown(str)
    local out = str
        :gsub("__(.+)__", "<i>%1</i>")
        :gsub("**(.+)**", "<b>%1</b>")
        :gsub("^^(.+)^^", "<u>%1</u>")
        :gsub("``(.+)``", "<mono>%1</mono>")
    return out
end

function libskinupload.notify(name, msg)
    if name == ":reviewers" then
        for n, _ in pairs(libskinupload.reviewers) do
            if minetest.get_player_by_name(n) then
                minetest.chat_send_player(n, msg)
            end
        end
    else
        if minetest.get_player_by_name(name) then
            minetest.chat_send_player(name, msg)
        else
            libskinupload.notifications[name] = msg
            db:set_string("notifications", minetest.serialize(libskinupload.notifications))
        end
    end
end

minetest.register_on_joinplayer(function(p)
    if db:contains("skin:"..p:get_player_name()) then
        libskinupload.set_skin(p, db:get_string("skin:"..p:get_player_name()))
    end
    local msg = libskinupload.notifications[p:get_player_name()]
    if msg then
        minetest.chat_send_player(p:get_player_name(), msg)
        libskinupload.notifications[p:get_player_name()] = nil
        db:set_string("notifications", minetest.serialize(libskinupload.notifications))
    end
    if minetest.check_player_privs(p, {skin_review = true}) then
        local newskins = db:get_int("newrequests")
        if newskins > 0 then minetest.chat_send_player(p:get_player_name(), minetest.colorize("#579a1e", "[libskinupload] "..newskins.." new skin request"..(newskins == 1 and " has" or "s have").." been submitted. Run /skinreview to see "..(newskins == 1 and "it" or "them")..".")) end
    end
end)

function libskinupload.queue(p, req)
    local data = req.skin
    if minetest.check_player_privs(p, {no_skin_upload = true}) then
        minetest.chat_send_player(p:get_player_name(), "Insufficient permissions.")
        return "No permission."
    end
    if not minetest.decode_base64(data) then
        return "Invalid base64 data."
    end
    local def = {name = req.skinname or "", desc = req.desc or "", data = data}
    if mcl then
        def.mcl_slim_arms = req.mcl_slim_arms == "true" or false
    end
    def.private = req.private == "true" or false
    db:set_string("skinreq:"..p:get_player_name(), minetest.serialize(def))
    if not db:contains("skinreq:"..p:get_player_name()) then
        db:set_int("newrequests", db:get_int("newrequests") + 1)
    end
    libskinupload.notify(":reviewers", minetest.colorize("#579a1e", "[libskinupload] A new skin request has been submitted. Run /skinreview to see it."))
    return false
end

function libskinupload.deny(by, name)
    if not minetest.check_player_privs(by, {skin_review = true}) then
        minetest.chat_send_player(by:get_player_name(), "Insufficient permissions.")
        return true
    end
    minetest.log("action", by:get_player_name().." denied a skin upload request from "..name..". Reason: ")
    db:set_string("skinreq:"..name, "")
    db:set_int("newrequests", db:get_int("newrequests") - 1)
    libskinupload.notify(name, minetest.colorize("#dc4207", "[libskinupload] Your skin request was denied."))
end

local function get_next_id()
    if not db:contains("_nextid") then db:set_int("_nextid", -1) end
    db:set_int("_nextid", db:get_int("_nextid") + 1)
    return db:get_int("_nextid")
end
function libskinupload.accept(by, name)
    if not minetest.check_player_privs(by, {skin_review = true}) then
        minetest.chat_send_player(by:get_player_name(), "Insufficient permissions.")
        return true
    end
    minetest.log("action", by:get_player_name().." accepted a skin upload request from "..name..".")
    local req = minetest.deserialize(db:get_string("skinreq:"..name))
    local id = get_next_id()
    local fp = storage_dir.."/libskinupload_uploaded_skin_"..id..".png"
    local f = io.open(fp, "w+")
    if not f:write(minetest.decode_base64(req.data)) then minetest.log("error", "Failed to write skin file.") end
    f:flush()
    f:close()
    local fpm = storage_dir_meta.."/libskinupload_uploaded_skin_"..id..".json"
    local fm = io.open(fpm, "w+")
    if not fm:write(minetest.write_json{n = req.name, d = req.desc, c = name, p = req.private or false, msa = req.mcl_slim_arms or false}) then minetest.log("error", "Failed to write skin meta.") end
    fm:flush()
    fm:close()
    minetest.dynamic_add_media({
        filepath = fp
    }, function() end)
    if mcl then 
        mcl_skins.register_simple_skin{texture = "libskinupload_uploaded_skin_"..id..".png", slim_arms = req.mcl_slim_arms or false}
    end
    db:set_string("skinreq:"..name, "")
    db:set_int("newrequests", db:get_int("newrequests") - 1)
    libskinupload.notify(name, minetest.colorize("#579a1e", "[libskinupload] Your skin request was accepted."))
end

local upload_state = {}
function libskinupload.show_upload_dialog(name, args)
    if not args then args = {err = ""} end
    local p = minetest.get_player_by_name(name)
    if not upload_state[name] then upload_state[name] = {} end
    minetest.show_formspec(name, "libskinupload:upload", [==[formspec_version[7]
        size[12,10]
        textarea[0.5,0.5;11,8;;;]==]..minetest.formspec_escape("To upload a skin, paste the base64-encoded image into the Data field below. This can be obtained from a terminal by running `base64 -i <filepath>` (e.g. `base64 -i ~/Desktop/skins/my_skin.png`) and copying the output. Alternatively, you can use a web tool (search 'base64-encode an image' or similar). Once a request is sbmitted, it will need to be reviewed. You will be notified when your request is accepted or denied.")..[==[]
        ]==]..((args.err and args.err ~= "") and "label[0.5,2.5;"..minetest.colorize("#b31706", "Error: "..args.err).."]" or "")..[=[
        container[0,3]
        field[0.5,0;11,0.5;skin;Data;]=]..minetest.formspec_escape(args.data or "")..[=[]
        field[0.5,1;11,0.5;skinname;Name;]=]..minetest.formspec_escape(args.name or "")..[=[]
        textarea[0.5,2;11,2;skindesc;Description;]=]..minetest.formspec_escape(args.desc or "")..[=[]
        container_end[]
        checkbox[0.5,7.5;private;Personal Skin;]=]..(not not args.private and "true" or "false")..[=[]
        ]=]..
        (mcl and "checkbox[0.5,8;mcl_slim_arms;Slim Arms;"..(not not args.mcl_slim_arms and "true" or "false").."]" or "")
        ..[=[
        button[0.5,8.5;11,1;confirm;Upload Skin]
        ]=])
end
minetest.register_chatcommand("skinupload", {
    func = libskinupload.show_upload_dialog,
    privs = {no_skin_upload = false}
})

local review_state = {}
function libskinupload.show_review_dialog(name, args)
    local p = minetest.get_player_by_name(name)
    local fs = [=[formspec_version[7]
        size[12,10]]=]
    if args == "" then
        fs = fs..[=[scrollbaroptions[min=0;max=100;thumbsize=10]
        scrollbar[10.8,0.5;0.2,9;vertical;na;0]
        scroll_container[0.5,0.5;11,9;na;vertical;]]=]
    
        local i = 0
        for k, v in pairs(db:to_table().fields) do
            if string.find(k, "skinreq:", 1, true) then
                local req = minetest.deserialize(v)
                local pn = string.gsub(k, "skinreq:", "")
                fs = fs.."style[view"..pn..";bgcolor=#0000;border=false]\
                style[view"..pn..":hovered;bgcolor=#0001;border=false]\
                style[view"..pn..":focused;bgcolor=#0001;border=false]\
                style[view"..pn..":pressed;bgcolor=#0001;border=false]\
                model["..((i %4) *2)..","..4 *math.floor(i / 4)..";2,4;pre;"..player_model(p, "\\[png:"..minetest.formspec_escape(req.data), req.mcl_slim_arms or false)..";0,210;;false;0,0;]\
                button["..((i %4) *2)..","..4 *math.floor(i / 4)..";2,4;view"..pn..";]"
                i = i + 1
            end
        end
        fs = fs..[=[
        scroll_container_end[]
        ]=]
    else
        local req = minetest.deserialize(db:get_string("skinreq:"..args))
        fs = fs.."model[0.5,0.5;8,9;pre;"..player_model(p, "\\[png:"..minetest.formspec_escape(req.data), req.mcl_slim_arms or false)..";0,210;;true;0,0;]\
        button[8,1;3,1;accept;Accept]\
        button[8,2;3,1;deny;Deny]\
        label[8,3.5;Creator: "..(args or "N/A").."]\
        label[8,4;Name: "..minetest.formspec_escape(req.name or "N/A").."]\
        textarea[8,4;6,2;;;"..minetest.formspec_escape(req.desc or "N/A").."]\
        button[8,6;3,1;back;Back]"
    end
    minetest.show_formspec(name, "libskinupload:review", fs)
end
minetest.register_chatcommand("skinreview", {
    func = function(name, args)
        review_state[name] = {}
        libskinupload.show_review_dialog(name, args)
    end,
    privs = {skin_review = true}
})

local choose_state = {}
function libskinupload.show_choose_dialog(name, args)
    local p = minetest.get_player_by_name(name)
    local fs = [=[formspec_version[7]
        size[12,10]]=]
    if args == "" then
        fs = fs..[=[scrollbaroptions[min=0;max=100;thumbsize=10]
        scrollbar[10.8,0.5;0.2,9;vertical;na;0]
        scroll_container[0.5,0.5;11,9;na;vertical;]]=]
    
        local i = 0
        for _, pn in pairs(minetest.get_dir_list(storage_dir, false)) do
            local meta = libskinupload.get_skin_meta(pn)
            if meta.p and meta.c ~= name then
                goto continue
            end
            fs = fs.."style[view"..pn..";bgcolor=#0000;border=false]\
            style[view"..pn..":hovered;bgcolor=#0001;border=false]\
            style[view"..pn..":focused;bgcolor=#0001;border=false]\
            style[view"..pn..":pressed;bgcolor=#0001;border=false]\
            model["..((i %4) *2)..","..4 *math.floor(i / 4)..";2,4;pre;"..player_model(p, pn, true)..";0,210;;false;0,0;]\
            button["..((i %4) *2)..","..4 *math.floor(i / 4)..";2,4;view"..pn..";]"
            ::continue::
            i = i + 1
        end
        fs = fs..[=[
        scroll_container_end[]
        ]=]
    else
        local meta = libskinupload.get_skin_meta(args)
        if meta.p and meta.c ~= name then
            fs = fs.."label[0.5,0.5;Insufficient privileges.]"
            return
        end
        fs = fs.."model[0.5,0.5;8,9;pre;"..player_model(p, args, not not meta.msa)..";0,210;;true;0,0;]\
        button[8,2;3,1;confirm;Set Skin]\
        label[8,3.5;"..minetest.formspec_escape(meta.n or "N/A").."]\
        textarea[8,4;6,2;;;"..minetest.formspec_escape(meta.d or "N/A").."]\
        button[8,8;3,1;back;Back]"
    end
    minetest.show_formspec(name, "libskinupload:choose", fs)
end
minetest.register_chatcommand("skinchoose", {
    func = function(name, args)
        choose_state[name] = {}
        libskinupload.show_choose_dialog(name, args)
    end
})

minetest.register_chatcommand("skinchange", {
    func = function(name, args)
        local f = io.open(storage_dir.."libskinupload_uploaded_skin_"..args..".png")
        if not f then
            minetest.chat_send_player(name, "Invalid uploaded skin ID.")
            return
        else
            f:close()
        end
        local meta = libskinupload.get_skin_meta("libskinupload_uploaded_skin_"..args..".png")
        if meta.p then
            minetest.chat_send_player(name, "Insufficient privileges.")
            return
        end
        libskinupload.set_skin(minetest.get_player_by_name(name), args)
    end
})

minetest.register_chatcommand("skindelete", {
    func = function(name, id)
        local f = io.open(storage_dir_meta.."libskinupload_uploaded_skin_"..id..".json")
        local meta = minetest.deserialize(f:read("a")) or {}
        f:close()
        os.remove(storage_dir.."libskinupload_uploaded_skin_"..id..".png")
        os.remove(storage_dir_meta.."libskinupload_uploaded_skin_"..id..".json")
        minetest.chat_send_player(name, "Successfully deleted skin '"..(meta.n or "#"..id).."' from "..(meta.c or "[unknown]")..".")
    end,
    privs = {skin_review = true}
})

minetest.register_chatcommand("skinforget", {
    func = function(name, args)
        libskinupload.forget_skin(name)
    end
})

function libskinupload.set_skin(p, id)
    local fname = "libskinupload_uploaded_skin_"..id..".png"
    local meta = libskinupload.get_skin_meta(fname)
    if meta.p and meta.c ~= p:get_player_name() then
        --minetest.chat_send_player(p:get_player_name(), "Insufficient permissions.")
        return
    end
        p:set_properties({
            textures = {fname},
        })
    if minetest.get_modpath("u_skins") then
        u_skins.u_skins[p:get_player_name()] = "libskinupload_uploaded_skin_"..id
        u_skins.save()
    elseif mcl then
        mcl_player.player_set_skin(p, "libskinupload_uploaded_skin_"..id..".png")
        mcl_skins.save(p)
    end
    if minetest.get_modpath("3d_armor") then
        armor.textures[p:get_player_name()].skin = "libskinupload_uploaded_skin_"..id..".png"
    end
    db:set_string("skin:"..p:get_player_name(), id)
end

function libskinupload.forget_skin(p)
    db:set_string("skin:"..(type(p) == "string" and p or p:get_player_name()), "")
end

function libskinupload.get_skin_id(name)
    return db:get_string("skin:"..name)
end

function libskinupload.get_skin_meta(skin)
    local f = io.open(storage_dir_meta..string.gsub(skin, ".png", ".json"))
    local meta
    if f then
        meta = minetest.parse_json(f:read("a"))
        f:close()
        return meta
    else
        return false
    end
end


minetest.register_on_player_receive_fields(function(p, name, data)
    if name == "libskinupload:upload" then
        if minetest.check_player_privs(p, {no_skin_upload = true}) then
            minetest.chat_send_player(p:get_player_name(), "Insufficient permissions.")
            minetest.close_formspec(p:get_player_name(), name)
            return true
        end
        local m = upload_state[p:get_player_name()]
        if data.key_enter_field or data.confirm then
            if mcl then
                data.mcl_slim_arms = m.mcl_slim_arms or false
            end
            data.private = m.private or false
            local x = libskinupload.queue(p, data)
            if x then
                libskinupload.show_upload_dialog(p:get_player_name(), {data = data.skin, name = data.skinname, desc = data.skindesc, private = m.private, mcl_slim_arms = m.mcl_slim_arms == "true" or false, err = x})
                return true
            end
            upload_state[p:get_player_name()] = nil
            minetest.close_formspec(p:get_player_name(), name)
            return true
        end
        if data.quit then
            upload_state[p:get_player_name()] = nil
            return true
        end
        if data.private then
            m.private = data.private
        end
        if data.mcl_slim_arms then
            m.mcl_slim_arms = data.mcl_slim_arms
        end
        libskinupload.show_upload_dialog(p:get_player_name(), {data = data.skin, name = data.skinname, desc = data.skindesc, private = m.private, mcl_slim_arms = m.mcl_slim_arms == "true" or false})
        return true
    elseif name == "libskinupload:review" then
        if not minetest.check_player_privs(p, {skin_review = true}) then
            minetest.chat_send_player(p:get_player_name(), "Insufficient permissions.")
            return true
        end
        if data.quit then
            review_state[p:get_player_name()] = nil
            return true
        end
        if data.back then
            libskinupload.show_review_dialog(p:get_player_name(), "")
            return true
        elseif data.deny then
            libskinupload.deny(p, review_state[p:get_player_name()].current)
            libskinupload.show_review_dialog(p:get_player_name(), "")
            return true
        elseif data.accept then
            libskinupload.accept(p, review_state[p:get_player_name()].current)
            libskinupload.show_review_dialog(p:get_player_name(), "")
            return true
        end
        for k, v in pairs(data) do
            if string.find(k, "view", 1, true) then
                review_state[p:get_player_name()].current = string.gsub(k, "^view", "")
                libskinupload.show_review_dialog(p:get_player_name(), review_state[p:get_player_name()].current)
                return true
            end
        end
        return true
    elseif name == "libskinupload:choose" then
        if data.quit then
            choose_state[p:get_player_name()] = nil
            return true
        end
        if data.back then
            libskinupload.show_choose_dialog(p:get_player_name(), "")
            return true
        elseif data.confirm then
            libskinupload.set_skin(p, string.gsub(string.sub(choose_state[p:get_player_name()].current, string.len("libskinupload_uploaded_skin_."), -1), ".png", ""))
            minetest.close_formspec(p:get_player_name(), name)
            return true
        end
        for k, v in pairs(data) do
            if string.find(k, "view", 1, true) then
                choose_state[p:get_player_name()].current = string.gsub(k, "^view", "")
                libskinupload.show_choose_dialog(p:get_player_name(), choose_state[p:get_player_name()].current)
                return true
            end
        end
        return true
    elseif data.libskinupload_chooser then
        unified_inventory.set_inventory_formspec(p,"libskinupload_chooser")
    end
    for k, _ in pairs(data) do
        if k == "libskinupload_upload_trigger" then
            libskinupload.show_upload_dialog(p:get_player_name())
        elseif string.sub(k, 1, string.len("libskinupload_set_skin_")) == "libskinupload_set_skin_" then
            local id = string.sub(k, string.len("libskinupload_set_skin_") + 1, -1)
            libskinupload.set_skin(p, id)
            unified_inventory.set_inventory_formspec(p,"libskinupload")
        end
    end
end)

--[[
for i = 1, 15 do
    db:set_string("skinreq:a"..i, minetest.serialize{name = "",desc = "", data = "iVBORw0KGgoAAAANSUhEUgAAAEAAAAAgCAYAAACinX6EAAAGIklEQVRogdWYXWwcVxXHf3fmzox37CWxg6II/BTxJbWxylcTJFphkbqooTYFHirRqragtJECVFGQSqO2akWBB1RRsFQ/kbZ8hErQikURgog6SislKX3BRYgSKZGQ/ZIoa5Y43tmZO/fyMJ7Jfnl3Fq8d5S9Zvufcjzn/e88599wVdMFvfzxhAMJQNehdVwKwshp2nD/91CnR7Rs3EjLvQGUah7p9N+XGIPcGSKGaNX025cYgNwttLDQWUii0sVr6p8YfwrZtAOI45vfzL/fPyk1EK5N1kJIHsITeNIO2Gj35cX0eaM4BsTaItY2JtdmwYVuFvuWAcHWV2PNAWGh983iI9cRrt+zOM7A+7ptzwPhtU2A0uhagowATVRn/+L39tXSTIEo/mdhUfzWmsQwQovFzk4/9OVedcOKndxuAS8tJ3THz9Hyueafm582esTEAduzYIQCuXLliAN5dWEAGneuYPuA6Yc8RGCOoRb3t+bFnxg2A6/nsHE42IdV124g9Y2O8u7DA8MhIpltcXGS5XGbP2BhSqebY7i/SfOi5NqFKBCGgFsa55qdELy2HjO7yGzYhL4ZHRlgulxtOPt2QPlQznRNeNYgpDDjUwhjPTeqEvOTrMbpre9buZRPq3b5dO9cGPPLDv3L16lX0318DwLr1yxSLRX723U/iym6lREw1iLJNSFENojyfBmDnsEtYW2VgcDuf//qrmcuneSEPFhcX27atARc6/R2Z/SdLS0v4D58HFYKw8B8+z9LSEk/M/avj3IG6YqGecC/kITlp1/MbyAMc+Pafcj+0lsvltu2uSXD28McoFov4wzZR9DaWifCHP0Cx6PODRz9Ct/mDBYdr1YRwM/HBgpPL+NFd27nrkdc39Kr83Pi4aNfOFQLLJ1/g4t0CdU2Csbh44Jf851T35BmqJD84jk0UNca949hZfyfMPD0v0kS4GRB3vv7RgdP3vRekCtu2Gz525y07GibML1zqeBLdjP3Gs6c7GhTHccf1/31i1jiuDUYThTXCIMS2BQiJikM+/JXv9eQpMrzvvZvqXeu4No4tQNsYx0XH4JoQ7TgI0XuU3FTkM6xFjtAGhEZL//9eSp6FlT6Z1YL7J6bBaH5z8pW+rRlFUfbqjGoKFQUYJzn5WPV2uwCI5pjvFRePPwmAEUmR88Y/3sj67r39AAB/ePtEptv/iS+C0YACY/GXv/0RSG4EFSVXykpV4zjJevtv/yqWldQaRsdgSQQGVIhWITpWWEohTEy89u6Q29+fvUpHv3CoY1xsOAQe/M6PGuRDh+9gZTW5IWThfQ19Q77kgW8ebdDNHNzXsmZKHuBrM0c2amJH9CUHDHuJwcu15Kob8iUrq4rzT/4iGbBfMuTLdcevh7ROaB7fq9wJ8r+nf44FCFsQawGxSlzOaLTSaLWKwCAQaCmxvSJC1cACrTT33P+tlkU9RzA7d4ZTn7oLgCNzJ3n86HhbA469eJaZg/u4Vo0YLLioKMSThpoSzD7/ZlcCG4XluQU818GVLp5fwHUknj+IJx08fxDHc/BsgetIHMdJ+h0bzy3geu0dyJF2W/1KtX3xdOzFswBZxZiiXXj0G5alFQz44EkspbBtm6mnXmbquVcRqoYtbGzHw3ZtbGEQqsbUc79j6tnj2LLQdtGVqmo48cePjq9LHq4TzVsa9xNy6vvHKa89DkbW3sjlcplSqcSXpqczubkfYOqZX7UsOPv8mxw6fEeDLiXfzqXryae3QE0liTv1jM2ELNe9jNJ2qVRicnKyZXD92FRuFwTpLVCfY6/r8mEryANYQZA9AwiCgCAImJycpFQqZXJzf728HuoJdyLfjuhWkQewKpVKRqxSqVCpVCiVSkxMTGRyc3+93IzpRz+T/H9n6LrunSFemjuT9a0H6bjUlNiS5Jd98/Lly5mQtvfu3cu5c+fYvbvxF/P6san8wTZl+EtzZ7j1Q5/ObUR6FQ4WnOz3g5mD+zJPaL7Pe5U7QWzbtq2lFL5w4UIL+fVwm19r0b11qX1N/tmdnbN8/cmn5H/9ygtYjsSENXQYImwBIqlT4uAaGI0QAgtNrG2wLSzLQrgFjI4ZveexjqXw/wBU+sGWvrP/SgAAAABJRU5ErkJggg=="})
end
--]]
