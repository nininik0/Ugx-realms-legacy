<!--
SPDX-FileCopyrightText: 2024 DS

SPDX-License-Identifier: CC0-1.0
-->

I already said this repo uses REUSE. This file is just to satisfy contentdb.
