-- SPDX-FileCopyrightText: 2024 DS
--
-- SPDX-License-Identifier: Apache-2.0

local path = core.get_modpath(core.get_current_modname())

dofile(path.."/api.lua")
dofile(path.."/game_support.lua")
