-- Ensure `default.player_attached` exists
if not default.player_attached then
    default.player_attached = {}
end

minetest.register_globalstep(function(dtime)
    local players = minetest.get_connected_players()
    for i = 1, #players do
        local name = players[i]:get_player_name()
        if default.player_attached[name] and not players[i]:get_attach() and
                (players[i]:get_player_control().up or
                players[i]:get_player_control().down or
                players[i]:get_player_control().left or
                players[i]:get_player_control().right or
                players[i]:get_player_control().jump) then
            players[i]:set_eye_offset({x=0, y=0, z=0}, {x=0, y=0, z=0})
            players[i]:set_physics_override({speed = 1, jump = 1, gravity = 1})
            default.player_attached[name] = false
            default.player_set_animation(players[i], "stand", 30)
        end
    end
end)

minetest.register_chatcommand("sit", {
    description = "Sit down",
    func = function(name)
        local player = minetest.get_player_by_name(name)
        if default.player_attached[name] then
            player:set_eye_offset({x=0, y=0, z=0}, {x=0, y=0, z=0})
            player:set_physics_override({speed = 1, jump = 1, gravity = 1})
            default.player_attached[name] = false
            default.player_set_animation(player, "stand", 30)
        else
            player:set_eye_offset({x=0, y=-7, z=2}, {x=0, y=0, z=0})
            player:set_physics_override({speed = 0, jump = 0, gravity = 0})
            default.player_attached[name] = true
            default.player_set_animation(player, "sit", 30)
        end
    end
})

minetest.register_chatcommand("lay", {
    description = "Lay down",
    func = function(name)
        local player = minetest.get_player_by_name(name)
        if default.player_attached[name] then
            player:set_eye_offset({x=0, y=0, z=0}, {x=0, y=0, z=0})
            player:set_physics_override({speed = 1, jump = 1, gravity = 1})
            default.player_attached[name] = false
            default.player_set_animation(player, "stand", 30)
        else
            player:set_eye_offset({x=0, y=-13, z=0}, {x=0, y=0, z=0})
            player:set_physics_override({speed = 0, jump = 0, gravity = 0})
            default.player_attached[name] = true
            default.player_set_animation(player, "lay", 0)
        end
    end
})

minetest.register_chatcommand("afk", {
    description = "Set your character to become Away From Keys",
    func = function(name)
        local player = minetest.get_player_by_name(name)
        if default.player_attached[name] then
            player:set_eye_offset({x=0, y=0, z=0}, {x=0, y=0, z=0})
            player:set_physics_override({speed = 1, jump = 1, gravity = 1})
            default.player_attached[name] = false
            default.player_set_animation(player, "stand", 30)
        else
            player:set_eye_offset({x=9, y=-13, z=56}, {x=21, y=-9, z=9})
            player:set_physics_override({speed = 0, jump = 1, gravity = 0})
            default.player_attached[name] = true
            default.player_set_animation(player, "sit", 0)
        end
    end
})

minetest.override_item("default:obsidian", {on_blast = function() end})