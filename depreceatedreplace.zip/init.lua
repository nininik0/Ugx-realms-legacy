minetest.register_node(":deadadvisor", {
	drawtype = "mesh",
  use_texture_alpha = "clip",
	mesh = "mobs_dungeon_master.b3d",
	tiles = {"123gy.png^mobs_blood.png^blacc.png"},
	paramtype = "light",
	paramtype2 = "wallmounted",
	collision_box = tall_pyr_cbox,

	groups = {dig_immediate=3},
})


minetest.register_node(":deadadvisor2", {
	drawtype = "mesh",
  use_texture_alpha = "clip",
	mesh = "mobs_dungeon_master.b3d",
	tiles = {"456gy.png^mobs_blood.png^blacc.png"},
	paramtype = "light",
	paramtype2 = "wallmounted",
	collision_box = tall_pyr_cbox,

	groups = {dig_immediate=3},
})

minetest.register_node(":deadvoidworker", {
	drawtype = "mesh",
  use_texture_alpha = true,
	mesh = "character.b3d",
	tiles = {"dedcharacter2.png"},
	paramtype = "light",
	paramtype2 = "wallmounted",
	collision_box = tall_pyr_cbox,

	groups = {dig_immediate=3},
})

--The Pipe clipboard guy who check Foster didn't steal anything, who owns the WD40.

mobs:register_mob("mobs:veiko", {
	type = "npc",
	hp_min = 33,
	hp_max = 50,
	collisionbox = {-0.1, -1, -0.1, 0.1, 0.95, 0.1},
	visual = "upright_sprite",
	visual_size = {x=1,y=2},
	textures = {{"veiko_f.png","veiko_r.png"}},
	walk_velocity = 3,
	run_velocity = 7,
	follow = {"ugx:teleport_fruit"},
	jump = true,
	jump_height = 2,
	view_range = 90,
	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,
})


mobs:register_egg("mobs:veiko", "Veiko", "veiko_f.png")

--Robert's robot friend Joey, in its third and penultimate form, a domestic health-bot.

mobs:register_mob("mobs:jel", {
	type = "npc",
	hp_min = 33,
	hp_max = 50,
	collisionbox = {-0.1, -0.5, -0.1, 0.1, 0.45, 0.1},
	visual = "upright_sprite",
	visual_size = {x=1,y=1},
	textures = {{"jel_f.png","jel_r.png"}},
	walk_velocity = 3,
	run_velocity = 7,
	follow = {"default:steel_ingot"},
	jump = true,
	jump_height = 4,
	view_range = 69,
	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,
})

mobs:register_egg("mobs:jel", "Jel", "jel_f.png")


--Lamb the supervisor of the pipe factory from Beneath a Steel Sky

mobs:register_mob("mobs:inokuin", {
	type = "npc",
	hp_min = 33,
	hp_max = 50,
	collisionbox = {-0.1, -1, -0.1, 0.1, 0.95, 0.1},
	visual = "upright_sprite",
	visual_size = {x=1,y=2},
	textures = {{"inokuin_f_" ..math.random(1,2).. ".png","inokuin_r_" ..math.random(1,2).. ".png"}},
	walk_velocity = 4,
	run_velocity = 7,
	follow = {"default:apple"},
	jump = true,
	jump_height = 2,
	view_range = 60,
	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,
})

mobs:register_egg("mobs:inokuin", "Inokuin", "inokuin_f_0.png")


mobs:register_mob("mobs:etoll", {
	type = "npc",
	hp_min = 33,
	hp_max = 50,
	collisionbox = {-0.1, -1, -0.1, 0.1, 0.95, 0.1},
	visual = "upright_sprite",
	visual_size = {x=1,y=2},
	textures = {{"etoll_f.png","etoll_r.png"}},
	walk_velocity = 5,
	run_velocity = 5,
	follow = {"mobs:etoll"},
	jump = true,
	jump_height = 2,
	view_range = 55,
	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,
})

mobs:register_egg("mobs:etoll", "Etoll", "etoll_f.png")

mobs:register_mob("mobs:feylo", {
	type = "npc",
	hp_min = 33,
	hp_max = 50,
	collisionbox = {-0.1, -1, -0.1, 0.1, 0.95, 0.1},
	visual = "upright_sprite",
	visual_size = {x=1,y=2},
	textures = {{"feylo_f.png","feylo_r.png"}},
	walk_velocity = 2,
	run_velocity = 5,
	follow = {"binoculars:binoculars"},
	jump = true,
	jump_height = 5,
	view_range = 66,
	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,
})

mobs:register_egg("mobs:feylo", "Feylo", "feylo_f.png")

--The main guy of lure of the temptress, who burns the straw in his cell after being captured, frees the Jester, and has to figure out a way to give the guy in chains water, and find the key out of the torture room etc...

mobs:register_mob("mobs:graz", {
	type = "npc",
	hp_min = 33,
	hp_max = 50,
	collisionbox = {-0.1, -1, -0.1, 0.1, 0.95, 0.1},
	visual = "upright_sprite",
	visual_size = {x=1,y=2},
	textures = {{"graz_f.png","graz_r.png"}},
	walk_velocity = 3,
	run_velocity = 7,
	follow = {"bucket:bucket_empty"},
	jump = true,
	jump_height = 4,
	view_range = 20,
	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,
})

mobs:register_egg("mobs:graz", "Graz", "graz_f.png")

--uhhhh 

mobs:register_mob("mobs:purpleinoukin", {
	type = "npc",
	hp_min = 33,
	hp_max = 50,
	collisionbox = {-0.1, -1, -0.1, 0.1, 0.95, 0.1},
	visual = "upright_sprite",
	visual_size = {x=1,y=2},
	textures = {{"ino1.png","ino2.png"}},
	walk_velocity = 2,
	run_velocity = 5,
	follow = {"ignore"},
	jump = true,
	jump_height = 3,
	view_range = 20,
	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,
})

mobs:register_egg("mobs:purpleinoukin", "Rich inoukin", "ino1.png")



--The main guy of Flight of the amazon queen, who lets say exlored a wierd jungle.

mobs:register_mob("mobs:oreon", {
	type = "npc",
	hp_min = 33,
	hp_max = 50,
	collisionbox = {-0.1, -1, -0.1, 0.1, 0.95, 0.1},
	visual = "upright_sprite",
	visual_size = {x=1,y=2},
	textures = {{"oreon_f.png","oreon_r.png"}},
	walk_velocity = 2.9,
	run_velocity = 5,
	follow = {"default:dirt_with_grass_footsteps"},
	jump = true,
	jump_height = 2,
	view_range = 20,
	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,
})

mobs:register_egg("mobs:oreon", "Oreon", "oreon_f.png")

--The mechanic of the room with the lathe machine in Beneath a Steel Sky, the guy in green overalls who goes to court to argue about a guard laughing at him because some water splashed on him.

mobs:register_mob("mobs:penta", {
	type = "npc",
	hp_min = 33,
	hp_max = 50,
	collisionbox = {-0.1, -1, -0.1, 0.1, 0.95, 0.1},
	visual = "upright_sprite",
	visual_size = {x=1,y=2},
	textures = {{"penta_f.png","penta_r.png"}},
	walk_velocity = 2.5,
	run_velocity = 5,
	follow = {"mobs:leather"},
	jump = true,
	jump_height = 5,
	view_range = 20,
	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,
})

mobs:register_egg("mobs:penta", "Penta", "penta_f.png")

mobs:register_mob("mobs:beka", {
	type = "npc",
	hp_min = 33,
	hp_max = 50,
	collisionbox = {-0.1, -1, -0.1, 0.1, 0.95, 0.1},
	visual = "upright_sprite",
	visual_size = {x=1,y=2},
	textures = {"beka.png","beka_r.png"},
	walk_velocity = 3,
	run_velocity = 6,
	follow = {"ugx:blue_ice"},
	jump = true,
	jump_height = 2,
	view_range = 69,
	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,
})

mobs:register_egg("mobs:beka", "Beka", "beka.png")



mobs:register_mob("mobs:sleeper", {
	type = "npc",
	hp_min = 33333,
	hp_max = 65535,
	collisionbox = {-0.1, -1, -0.1, 0.1, 0.95, 0.1},
	visual = "upright_sprite",
	visual_size = {x=1,y=1},
	textures = {"sleeper.png"},
	walk_velocity = 3,
	run_velocity = 5,
	follow = {"default:dirt_with_grass"},
	jump = true,
	jump_height = 9,
	view_range = 20,
})

mobs:register_egg("mobs:sleeper", "sleeper", "sleeper.png")

--The Main guy, Robert Foster, from Beneath A Steel Sky

mobs:register_mob("mobs:demopay", {
	type = "npc",
	hp_min = 33,
	hp_max = 50,
	collisionbox = {-0.1, -1, -0.1, 0.1, 0.95, 0.1},
	visual = "upright_sprite",
	visual_size = {x=1,y=2},
	textures = {{"demopay_f.png","demopay_r.png"}},
	walk_velocity = 5,
	run_velocity = 15,
	follow = {"default:steelblock"},
	jump = true,
	jump_height = 5,
	view_range = 20,
	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,
})

mobs:register_egg("mobs:demopay", "Demopay", "demopay_f.png")



--Guy from Vampire story who's girlfriend gets stolen by the vampire in the hotel.

mobs:register_mob("mobs:swinepine", {
	type = "npc",
	hp_min = 33,
	hp_max = 50,
	collisionbox = {-0.1, -1, -0.1, 0.1, 0.95, 0.1},
	visual = "upright_sprite",
	visual_size = {x=1,y=2},
	textures = {{"swinepine_f.png","swinepine_r.png"}},
	walk_velocity = 3,
	run_velocity = 6,
	follow = {"farming:bread"},
	jump = true,
	jump_height = 3,
	view_range = 200,
	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end
})

mobs:register_egg("mobs:swinepine", "Swinepine", "swinepine_f.png")



minetest.register_alias("farming:oat", "default:grass_1")




mobs:register_mob("mobs_monster:delusоnеr", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
   nametag = "abandoned delusioner",
	reach = 4,
	damage = 5,
	hp_min = 20,
	hp_max = 100,
	armor = 100,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	textures = {
		{"default_obsidian.png^mobs_meat_raw.png^mobs_blood.png^blacc.png"},
		{"dedcharacter2.png^mobs_blood.png^blacc.png"}
	},
	makes_footstep_sound = true,
	sounds = {
		random = "distortedtrumpets",
     attack = "spooky_noise.10",
	},
	walk_velocity = 2,
	run_velocity = 9,
	jump_height = 8,
	stepheight = 9,
	floats = 0,
	view_range = 666,
	drops = {
     {name = "deadvoidworker", chance = 1, min = 1, max = 1},
     {name = "ignore", chance = 1, min = 1, max = 22},
     {name = "dead_portal_peice", chance = 1, min=1, max=1}, 
     {name = "specialblocks:blood_block", chance = 1, min = 1, max = 21},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 40,
		run_end = 63,
		punch_start = 40,
		punch_end = 63,
	}
})


mobs:register_mob("specialblocks:sp", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
   nametag = "Captor",
  visual_size = {x=3, y=3},
	reach = 4,
	damage = 3,
	hp_min = 20,
	hp_max = 111,
	armor = 100,
	collisionbox = {-0.7, -1.7, -0.7, 0.7, 1.7, 1.4},
	visual = "mesh",
	mesh = "character.b3d",
	textures = {
		{"ignore.png^mobs_meat_raw.png^mobs_blood.png^sunrisebg.png"},
		{"starcursed_mass.png^mobs_blood.png^default_snow_side.png"}
	},
	makes_footstep_sound = true,
	sounds = {
		random = "imagetoaudio",
     attack = "spooky_noise",
	},
	walk_velocity = 2,
	run_velocity = 9,
	jump_height = 8,
	stepheight = 9,
	floats = 0,
	view_range = 666,
	drops = {
		{name = "mobs:inokuin", chance = 1, min = 1, max = 1},
		{name =  "specialblocks:blood_block", chance = 1, min = 1, max = 5},
		{name = "mobs:veiko", chance = 1, min = 1, max = 1},
		{name = "mobs:demopay", chance = 1, min = 1, max = 1},
  		{name = "mobs:graz", chance = 1, min = 1, max = 1},
		{name = "mobs:swinepine", chance = 1, min = 1, max = 1},
		{name = "mobs:beka", chance = 1, min = 1, max = 1},
     {name = "mobs:purpleinoukin", chance = 1, min = 1, max = 1},
     {name = "mobs:sleeper", chance = 1, min = 1, max = 1},
     {name = "mobs:penta", chance = 1, min = 1, max = 1},
    {name = "mobs:jel", chance = 1, min = 1, max = 1},
     {name = "deadbat", chance = 1, min = 1, max = 1},
     {name = "mobs:etoll", chance = 1, min = 1, max = 1},
     {name = "deadadvisor", chance = 1, min = 1, max = 1},
    {name = "deadadvisor2", chance = 1, min = 1, max = 1},
     {name = "mobs:oreon", chance = 1, min = 1, max = 1}
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 40,
		run_end = 63,
		punch_start = 40,
		punch_end = 63,
	}
})







-- Register the blood item
minetest.register_craftitem(":blood", {
    description = "Blood",
    inventory_image = "mobs_blood.png",
})

minetest.register_node(":specialblocks:blood_block", {
    description = "Blood Block",
    tiles = {"mobs_meat_raw_top.png^mobs_blood.png"},
    groups = {crumbly = 3, oddly_breakable_by_hand = 3},
    on_use = minetest.item_eat(2), -- The block is edible and restores 4 HP
})





mobs:register_mob("mobs_monster:voidFiend", {
   type = "npc",
   passive = false,
   attack_monsters = true,
   attack_npcs = false,
   damage = 8,
   reach = 3,
   attack_type = "shoot",
   shoot_interval = 2.5,
   arrow = "mobs_monster:arrow",
   shoot_offset = 1,
   hp_min = 30,
   hp_max = 45,
   armor = 80,
   collisionbox = {-0.9, -0.2, -0.9, 0.9, 1.5, 0.9},
   visual = "mesh",
   mesh = "cacodemon.b3d",
   textures = {
      {"h0i.png"},
      {"hoi.png"}
   },
   blood_amount = 80,
   blood_texture = "sun.png",
   backface_culling = false,
   use_texture_alpha = true,
   visual_size = {x=2, y=2},
   makes_footstep_sound = true,
   walk_velocity = 3,
   run_velocity = 5,
   jump = true,
   fly = true,
   fall_speed = 0,
   stepheight = 10,
   water_damage = 2,
   lava_damage = 0,
   light_damage = 0,
   view_range = 20,
   animation = {
      speed_normal = 10,
      speed_run = 20,
      walk_start = 1,
      walk_end = 20,
      stand_start = 1,
      stand_end = 20,
      run_start = 1,
      run_end = 20,
      shoot_start = 20,
      shoot_end = 40,
   },
follow = {
		"farming:wheat", "default:grass_1", "farming:barley",
		"farming:oat", "farming:rye"
	},
	view_range = 8,
	replace_rate = 10,
	replace_what = {
		{"group:grass", "air", 0},
		{"default:dirt_with_grass", "default:dirt_with_grass_footsteps", -1}
	},
--	stay_near = {{"farming:straw", "group:grass"}, 10},

on_rightclick = function(self, clicker)

		-- feed or tame
		if mobs:feed_tame(self, clicker, 8, true, true) then

			-- if fed 7x wheat or grass then cow can be milked again
			if self.food and self.food > 6 then
				self.gotten = false
			end

			return
		end

		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 60, false, nil) then return end

		local tool = clicker:get_wielded_item()
		local name = clicker:get_player_name()
		local item = tool:get_name()

		-- milk cow with empty bucket
		if item == "bucket:bucket_empty"
		or item == "wooden_bucket:bucket_wood_empty"
		or item == "bucket_wooden:bucket_empty" then

			--if self.gotten == true
			if self.child == true then
				return
			end

			if self.gotten == true then

				minetest.chat_send_player(name, ("void fiend already liquided!"))

				return
			end

			local inv = clicker:get_inventory()

			tool:take_item()
			clicker:set_wielded_item(tool)

			-- which bucket are we using
			local ret_item = "city_block:bucket_pitch"

			if item == "wooden_bucket:bucket_wood_empty"
			or item == "bucket_wooden:bucket_empty" then
				ret_item = "city_block:bucket_pitch"
			end

			if inv:room_for_item("main", {name = ret_item}) then
				clicker:get_inventory():add_item("main", ret_item)
			else
				local pos = self.object:get_pos()

				pos.y = pos.y + 0.5

				minetest.add_item(pos, {name = ret_item})
			end

			self.gotten = true -- milked

			return
		end
	end,

	on_replace = function(self, pos, oldnode, newnode)

		self.food = (self.food or 0) + 1

		-- if cow replaces 8x grass then it can be milked again
		if self.food >= 8 then
			self.food = 0
			self.gotten = false
		end
	end
})




	mobs:spawn({
		name = "mobs_monster:voidFiend",
		nodes = {"default:dirt_with_grass", "ethereal:green_dirt"},
		neighbors = {"group:grass"},
		min_light = 14,
		interval = 60,
		chance = 9000,
		min_height = 5,
		max_height = 200,
		day_toggle = true
	})



mobs:register_egg("mobs_monster:voidFiend", ("void fiend"), "h0i.png")


minetest.register_tool(":shovel", {
	description = ("Shovel"),
	inventory_image = "shovel.png",
	wield_image = "shovel.png",
	tool_capabilities = {
		full_punch_interval = 1.1,
		max_drop_level=1,
		groupcaps={
			crumbly = {times={[1]=1.65, [2]=1.05, [3]=0.45}, uses=10, maxlevel=4},
		},
		damage_groups = {fleshy=20},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {shovel = 1}
})

minetest.register_node(":texture_box", {
	tiles = {"texture_box.png"},
  use_texture_alpha = "clip",
	groups = {oddly_breakable_by_hand = 2},
})


minetest.register_node(":ugx:altdiamond", {
	tiles = {"demondblock.png"},
  use_texture_alpha = "clip",
	groups = {oddly_breakable_by_hand = 2},
})

minetest.register_node(":base", {
	tiles = {"mastered-base.png"},
  use_texture_alpha = "clip",
	groups = {oddly_breakable_by_hand = 2},
})

minetest.register_node(":error", {
	drawtype = "mesh",
	mesh = "error.obj",
	tiles = {"unknown_node.png^[colorize:#ff0000:255"},
	pointable = true,
	walkable = false,
})


mobs:register_mob("mobs_monster:executioner", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
	damage = 8,
	hp_min = 9,
	hp_max = 32,
	armor = 100,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	textures = {"executioner.png"},
	spritediv = {x = 1, y = 1},
	visual_size = {x=2, y=2},
	makes_footstep_sound = false,
	sounds = {
		random = "15",
	},
	walk_velocity = 5,
	run_velocity = 10,
	view_range = 50,
	jump = true,
	drops = {
		{name = "default:steel_ingot", chance = 0.5, min = 1, max = 9},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 10,
	floats = 100,
})




minetest.register_tool(":voidsword", {
    inventory_image = "demon_blade.png",
    tool_capabilities = {
        full_punch_interval = 3,
        max_drop_level = 5,
        groupcaps = {
            snappy = {
                times = {[2] = 0.1, [3] = 0.1},
                uses = 2000,
                maxlevel = 3,
            },
        },
        damage_groups = {fleshy = 666},
    },
    wield_scale = {x = 2, y = 2, z = 1},  -- Adjust the wield scale as needed
})

minetest.register_tool(":bladehand", {
    inventory_image = "blade_hand.png",
    tool_capabilities = {
        full_punch_interval = 0.5,
        max_drop_level = 5,
        groupcaps = {
            choppy = {
                times = {[2] = 0.1, [3] = 0.1},
                uses = 2222,
                maxlevel = 3,
            },
        },
        damage_groups = {fleshy = 69},
    },
    wield_scale = {x = 1.5, y = 1.5, z = 0.9},  -- Adjust the wield scale as needed
})


minetest.register_tool(":basetools:tinysword", {
    inventory_image = "tinysword.png",
    tool_capabilities = {
        full_punch_interval = 0.1,
        max_drop_level = 3,
        groupcaps = {
            snappy = {
                times = {[2] = 0.1, [3] = 0.1},
                uses = 2222,
                maxlevel = 3,
            },
        },
        damage_groups = {fleshy = 3},
    },
    wield_scale = {x = 0.5, y = 0.5, z = 0.09},  -- Adjust the wield scale as needed
})

-- ugx/init.lua

minetest.register_node(":ugx:icebrick", {
    description = "Ice Brick",
    tiles = {"icebrick.png"},
    is_ground_content = false,
    groups = {cracky=3, oddly_breakable_by_hand=2},
})

minetest.register_craft({
    output = "ugx:icebrick 4",
    recipe = {
        {"default:snow", "default:snow"},
        {"default:ice", "default:ice"},
    }
})


minetest.register_node(":bloodpuddle", {
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	tiles = { "bloodp.png" },


	walkable = false,
	groups = { dig_immediate = 3 },
	sunlight_propagates = true,
})

minetest.register_node(":ugx:shop", {
    description = "shop",
    drawtype = "allfaces",
    visual_scale = 6.5,
    tiles = {"sh0p.png"},
    paramtype = "light",
    sunlight_propagates = true,
    is_ground_content = false,
    groups = {cracky = 3, oddly_breakable_by_hand = 3},
    sounds = default.node_sound_glass_defaults(),
})

minetest.register_node(":void", {
    drawtype = "plantlike",
    tiles = {"altard.png"},
    inventory_image = "altard.png",
    wield_image = "altard.png",
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {unbreakable=1, flora=1, attached_node=1, not_in_creative_inventory=1},
})

minetest.register_node(":v0id", {
    drawtype = "plantlike",
    tiles = {"altard2.png"},
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {unbreakable=1, flora=1, attached_node=1, not_in_creative_inventory=1},
})


minetest.register_node(":banner", {
    drawtype = "plantlike",
    tiles = {"banner.png"},
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})


minetest.register_node(":banner2", {
    drawtype = "torchlike",
    tiles = {"banner.png"},
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})

minetest.register_node(":banner1", {
    drawtype = "signlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"banner.png"},
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})

minetest.register_node(":banner1_big", {
    drawtype = "signlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"banner.png"},
    visual_scale = 6.5,
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})

minetest.register_node(":banner1_medium", {
    drawtype = "signlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"banner.png"},
    visual_scale = 3.5,
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})

minetest.register_node(":banner1_massive", {
    drawtype = "signlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"banner.png"},
    visual_scale = 10,
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})

minetest.register_node(":deadbat", {
    drawtype = "signlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"dedbat.png"},
    visual_scale = 3,
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})


minetest.register_node(":vo1d", {
    drawtype = "signlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"altard3.png"},
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})

minetest.register_node(":harvesterCorpse", {
    drawtype = "signlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    visual_scale = 9,
    tiles = {"starcursed_mass.png^yikes.png^0n0.png^deleyed.png^ohmy.png"},
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {oddly_breakable_by_hand=1},
})


minetest.register_node(":VOIDADMIN", {
    drawtype = "signlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    visual_scale = 11,
    tiles = {"chaos.png"},
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {oddly_breakable_by_hand=1},
})




local mcl = minetest.get_modpath("mcl_core") ~= nil

-- Npc by TenPlus1



mobs:register_mob("mobs:npc", {
	type = "npc",
	passive = false,
	damage = 3,
	attack_type = "dogfight",
	attack_monsters = true,
	attack_npcs = false,
	owner_loyal = true,
	pathfinding = true,
	hp_min = 10,
	hp_max = 20,
	armor = 100,
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "character.b3d",
	drawtype = "front",
	textures = {
		{"character.png"},
		{"character_2.png"},
		{"character_3.png"},
		{"character_14.png"},
		{"character_40.png"},
		{"character_50.png"},
		{"character_54.png"},
		{"character_64.png"},
     {"character_78.png"},
     {"character_91.png"},
     {"character_113.png"},
     {"character_122.png"},
     {"character_126.png"}
	},
	child_texture = {
		{"baby.png"} -- derpy baby by AmirDerAssassine
	},
	makes_footstep_sound = true,
	sounds = {},
	walk_velocity = 2,
	run_velocity = 3,
	jump = true,
	drops = {
		{name = mcl and "mcl_core:wood" or "default:wood", chance = 1, min = 1, max = 3},
		{name = mcl and "mcl_core:apple" or "default:apple", chance = 2, min = 1, max = 2},
		{name = mcl and "mcl_tools:axe_stone" or "default:axe_stone", chance = 5, min = 1, max = 1}
	},
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	follow = {
		mcl and "mcl_farming:bread" or "farming:bread",
		mcl and "mcl_mobitems:cooked_beef"or "mobs:meat",
		mcl and "mcl_core:diamond" or "default:diamond"
	},
	view_range = 15,
	owner = "",
	order = "wander",
	fear_height = 3,
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 189, --200
		punch_end = 198 --219
        
},

        on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,

})


-- register spawn egg
mobs:register_egg("mobs:npc", ("Npc"),
		mcl and "default_stone_brick.png" or "default_brick.png", 1)



-- spawn NPC in world
if not mobs.custom_spawn_npc then

	mobs:spawn({
		name = "mobs_npc:npc",
		nodes = {mcl and "mcl_core:stonebrick" or "default:brick"},
		neighbors = {mcl and "mcl_flowers:tallgrass" or "default:grass_3"},
		min_light = 10,
		chance = 10000,
		active_object_count = 1,
		min_height = 0,
		day_toggle = true
	})
end


minetest.register_node(":crackstone", {
    drawtype = "plantlike",
    tiles = {"crackstone.png"},
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})



minetest.register_node(":crackstone_big", {
    drawtype = "plantlike",
    tiles = {"crackstone.png"},
    paramtype = "light",
    visual_scale = 6.5,
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})


minetest.register_node(":crackstone_huge", {
    drawtype = "plantlike",
    tiles = {"crackstone.png"},
    paramtype = "light",
    visual_scale = 11,
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})


minetest.register_abm({
	label = "Rat Spawning",
	nodenames = {"default:tree", "default:jungletree"},
	interval = 10,
	chance = 200,
	catch_up = false,
	action = function(pos, node, active_object_count, active_object_count_wider)
		if active_object_count_wider > 0 then
			return
		end
		pos.x = pos.x + math.random(-2, 2)
		pos.z = pos.z + math.random(-2, 2)
		node = minetest.get_node(pos)
		local below = minetest.get_node(vector.offset(pos, 0, -1, 0))
		if below.name == "default:dirt_with_grass" and node.name == "air" then
			minetest.add_entity(pos, "dev:rat")
		end
	end,
})


minetest.register_node(":crackstone2", {
    drawtype = "torchlike",
    tiles = {"crackstone.png"},
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})

minetest.register_node(":crackstone1", {
    drawtype = "signlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"crackstone.png"},
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})

minetest.register_node(":crackstone1_big", {
    drawtype = "signlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"crackstone.png"},
    visual_scale = 6.5,
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})


minetest.register_node(":dead_portal_peice", {
    drawtype = "signlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"killedportal.png"},
    paramtype = "light",
    visual_scale = 2.9,
    sunlight_propagates = true,
    walkable = false,
    groups = {oddly_breakable_by_hand = 1},
})

minetest.override_item("default:obsidian_block", {on_blast = function() end})
minetest.override_item("default:obsidianbrick", {on_blast = function() end})