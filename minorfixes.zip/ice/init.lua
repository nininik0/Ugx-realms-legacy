mobs:register_mob("mobs:роs_", {
	type = "monster",
	hp_min = 3,	hp_max = 20,
	collisionbox = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
	visual = "sprite",
	visual_size = {x = 1, y = 1},
	textures = {"shadow_fiend.png"},
	blood_texture = "black.png",
	makes_footstep_sound = false,
	damage = 3,
	attack_type = "dogfight",
	reach = 2,
	passive = false,
	walk_velocity = 7,
	run_velocity = 8,
drops = {
		{name = "VOIDADMIN", chance = 0.1, min = 0, max = 1},
	},
	jump_chance = 3,
	jump_height = 10,
   fly = true,
	fly_in={"air", "default:water_source", "default:river_water_source", "default:river_water_flowing", "maptools:buildable_to_light", "maptools:darkair", "maptools:lightbulb"},
	floats = true,
	fall_speed = 0,
	regen= 1,
	armor = 99,
	view_range = 50,
	on_die = function(self, pos)
		local num = math.random(1, 2)
		for i=1,num do
			minetest.add_entity({x=pos.x + math.random(-2, 2), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "mobs_monster:item")
		end
	end,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
  footstep = "mobs_fireball",
})

mobs:register_mob("mobs:bird", {
	type = "npc",
    passive = true,
	hp_min = 3,	hp_max = 9,
	collisionbox = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
	visual = "sprite",
	visual_size = {x = 1, y = 1},
	textures = {"flight.png"},
	walk_velocity = 3,
	run_velocity = 5,
drops = {
		{name = "mobs:leather", chance = 0.5, min = 0, max = 1},
	},
	jump_chance = 3,
	jump_height = 10,
   fly = true,
	fly_in={"air", "default:water_source", "default:river_water_source", "default:river_water_flowing", "maptools:buildable_to_light", "maptools:darkair", "maptools:lightbulb"},
	floats = true,
	fall_speed = 0,
	armor = 100,
    follow = {"farming:barley"},
	view_range = 50,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 1,
	light_damage = 0,
    on_rightclick = function(self, clicker)

		if mobs:feed_tame(self, clicker, 20, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end
})


mobs:register_egg("mobs:bird", ("Bird"), "flight.png", 1)






mobs:register_mob("specialblocks:sp", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 2,
  blood_texture = "zombie_orb.png",
	damage = 5,
	hp_min = 20,
	hp_max = 40,
	armor = 100,
	collisionbox = {-1.1, -1.1, -1.4, 1.4, 1.5, 1.4},
	visual = "upright_sprite",
	textures = {"zombie_orb.png"},
	spritediv = {x = 1, y = 1},
	visual_size = {x=3.3, y=3.3},
	makes_footstep_sound = false,
	sounds = {
		random = "spooky_noise.10",
	},
	walk_velocity = 2,
	run_velocity = 4,
	view_range = 22,
    jump = true,
	drops = {
		{name = "simulcara", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 10,
	floats = 100,
})

mobs:register_mob("mobs:color", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
  blood_texture = "blood2.png",
	damage = 5,
	hp_min = 40,
	hp_max = 50,
	armor = 99,
	collisionbox = {-1.1, -1.1, -1.4, 1.4, 1.5, 1.4},
	visual = "upright_sprite",
	textures = {"colorhorror.png"},
	spritediv = {x = 1, y = 1},
	visual_size = {x=3, y=3},
	makes_footstep_sound = true,
	sounds = {
		random = "default_cool_lava",
	},
	walk_velocity = 2,
	run_velocity = 4,
	view_range = 22,
	jump = true,
	drops = {
		{name = "ugx:spectre", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 5,
	floats = 10,
})


mobs:register_mob("mobs_animal:gigabat", {
	type = "npc",
    attack_npcs = false,
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
    follow = {
		"default:dirt", "ugx:teleport_fruit", "ugx:blue_packed_ice",
		"default:stone", "farming:wheat"
	},
	damage = 40,
	hp_min = 155,
	hp_max = 172,
	armor = 99,
	collisionbox = {-1.1, -1.1, -1.4, 1.4, 1.5, 1.4},
	visual = "upright_sprite",
	textures = {"gigabat.png"},
	spritediv = {x = 1, y = 1},
	visual_size = {x=3.4, y=3.4},
	makes_footstep_sound = false,
	sounds = {
		random = "mobs_fireball",
	},
	walk_velocity = 3,
	run_velocity = 7,
	view_range = 100,
	jump = true,
	drops = {
		{name = "default:dirt_with_snow", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 10,
	floats = 100,
    on_rightclick = function(self, clicker)

		if mobs:feed_tame(self, clicker, 20, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end
})


mobs:register_egg("mobs_animal:gigabat", ("Giga Bat"), "gigabat.png", 1)





mobs:register_mob("mobs_monster:iceservant", {
	type = "npc",
    attack_npcs = false,
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 2,
	damage = 9,
	hp_min = 80,
	hp_max = 100,
	armor = 100,
  follow = {
		"default:ice", "ugx:blue_ice", "ugx:blue_packed_ice",
		"farming:barley", "farming:corn"
	},
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=2, y=2},
	textures = {
		"f.png",
		"r.png",
	},
	makes_footstep_sound = true,
	sounds = {
		random = "wind",
	},
	walk_velocity = 3,
	run_velocity = 6,
	view_range = 50,
	jump = true,
	drops = {
		{name = "specialblocks:teamthunderstrike", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 4,
	replace_rate = 5,
	replace_what = {"default:dirt_with_grass"},
	replace_with = "default:dirt_with_grass_footsteps",
	replace_offset = -1,
	floats = 1,
    on_rightclick = function(self, clicker)

		if mobs:feed_tame(self, clicker, 20, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end
})


mobs:register_egg("mobs_monster:iceservant", ("Ice Servant"), "f.png", 1)

mobs:register_mob("mobs_monster:zyme", {
	type = "npc",
    attack_npcs = false,
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 2,
	damage = 9,
	hp_min = 40,
	hp_max = 40,
	armor = 100,
  follow = {
		"default:dirt_with_grass", "bones:bones", "ugx:skull_lantern",
		"farming:barley", "default:dirt"
	},
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=2, y=2},
	textures = {
      {"z1.png"},
      {"z2.png"}
   },
	makes_footstep_sound = true,
	sounds = {
		random = "erth",
	},
	walk_velocity = 3,
	run_velocity = 6,
	view_range = 50,
	jump = true,
	drops = {
		{name = "specialblocks:plant", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 4,
	replace_rate = 5,
	replace_what = {"default:dirt_with_grass"},
	replace_with = "default:dirt_with_grass_footsteps",
	replace_offset = -1,
	floats = 1,
    on_rightclick = function(self, clicker)

		if mobs:feed_tame(self, clicker, 20, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end
})


mobs:register_egg("mobs_monster:zyme", ("Zyme"), "z1.png", 1)




-- Utility function to register colorized bricks
local function register_brick(name, base_texture, color)
	minetest.register_node("ice:" .. name .. "_bricks", {
		description = name:gsub("^%l", string.upper) .. " Bricks",
		tiles = {base_texture .. "^[colorize:" .. color},
		is_ground_content = false,
		groups = {cracky = 3, not_cuttable=1},
		sounds = default.node_sound_ice_defaults(),
	})
end

-- Utility function to register colorized ice and packed ice
local function register_ice(name, color, packed_color)
	minetest.register_node("ice:" .. name .. "_ice", {
		description = name:gsub("^%l", string.upper) .. " Ice",
		tiles = {"default_ice.png^[colorize:" .. color},
		paramtype = "light",
		use_texture_alpha = "blend",
		is_ground_content = false,
		groups = {cracky = 3, cools_lava = 1, not_cuttable=1},
		sounds = default.node_sound_ice_defaults(),
	})

	minetest.register_node("ice:packed_" .. name .. "_ice", {
		description = "Packed " .. name:gsub("^%l", string.upper) .. " Ice",
		tiles = {"xdecor_packed_ice.png^[colorize:" .. packed_color},
		paramtype = "light",
		use_texture_alpha = "blend",
		is_ground_content = false,
		groups = {cracky = 3, not_cuttable=1},
		sounds = default.node_sound_ice_defaults(),
	})
end

-- Registering all the colorized bricks
register_brick("snow", "default_stone_brick.png", "white:90")
register_brick("ice", "default_stone_brick.png", "cyan:90")
register_brick("packed_ice", "default_stone_brick.png", "lightblue:90")
register_brick("blue_ice", "default_stone_brick.png", "blue:90")
register_brick("packed_blue_ice", "default_stone_brick.png", "deepskyblue:90")

-- Registering the thin ice pane
minetest.register_node("ice:thin_ice_pane", {
	description = "Thin Ice Pane",
	drawtype = "glasslike_framed",
	tiles = {"caverealms_thin_ice.png^[colorize:cyan:50"},
	paramtype = "light",
	use_texture_alpha = "blend",
	is_ground_content = false,
	groups = {cracky = 3, cools_lava = 1, not_cuttable=1},
	sounds = default.node_sound_glass_defaults(),
})

-- Registering the custom ice blocks
register_ice("green", "green:80", "darkgreen:80")
register_ice("purple", "purple:80", "darkviolet:80")

-- Registering packed snow
minetest.register_node("ice:packed_snow", {
	description = "Packed Snow",
	tiles = {"default_snow.png^[colorize:white:66^default_obsidian_glass.png^[colorize:white:88"},
	is_ground_content = false,
	groups = {cracky = 3, not_cuttable=1},
	sounds = default.node_sound_snow_defaults(),
})

-- Registering the Sapphire Block (retextured diamond block with dark purple-blue color)
minetest.register_node("ice:sapphire_block", {
	description = "Sapphire Block",
	tiles = {"default_diamond_block.png^[colorize:darkviolet:100"},
	is_ground_content = false,
	groups = {cracky = 3, not_cuttable=1},
	sounds = default.node_sound_stone_defaults(),
})

-- Register aliases
minetest.register_alias("crackeddarkice", "default:water_source")
minetest.register_alias("crackedlightsnow", "default:dirt_with_grass")

-- Spectre of Torment item
minetest.register_tool(":spectre_of_torment", {
    inventory_image = "torment.png",
    max_uses = 333,
    on_use = function(itemstack, user, pointed_thing)
        local pos

        if pointed_thing.type == "node" then
            pos = pointed_thing.under
        elseif pointed_thing.type == "object" then
            pos = pointed_thing.ref:get_pos()
            pointed_thing.ref:punch(user, nil, {damage_groups = {fleshy = 66}}, nil)
        elseif user then
            pos = user:get_pos()
        end

        if pos then
            pos.y = pos.y + 1  -- Slightly above the entity or player

            if minetest.get_node(pos).name == "air" then
                minetest.set_node(pos, {name = "specialblocks:liquid_pain_flowing"})
            end
        end

        -- Reduce the uses by applying wear to the item
        itemstack:add_wear(65535 / 333)  -- Divide by the number of uses (333)
        
        return itemstack
    end,
})

-- Register a craft for the Spectre of Torment (optional)
minetest.register_craft({
    output = "ugx:skull_lantern",
    recipe = {
        {"", "", ""},
        {"", "bones:bones", ""},
        {"", "xdecor:lantern", ""},
    }
})

minetest.register_tool(":xdecor:small_knife", {
  inventory_image = "xdecor_small_knife.png",
  description = "Small Knife",
  tool_capabilities = {
  full_punch_interval = 0.3,
  damage_groups = {fleshy=2,icy=3},
  }
})

minetest.register_craft({
    output = "xdecor:small_knife",
    recipe = {
        {"", "", ""},
        {"", "default:stick", ""},
        {"", "default:iron_lump", ""},
    }
})

-- Register dark ice
minetest.register_node(":darkice", {
    tiles = {"darkice.png"},
    is_ground_content = false,
    groups = {cracky = 3, ice = 1},
    sounds = default.node_sound_glass_defaults(),
})

-- Register light snow
minetest.register_node(":lightsnow", {
    tiles = {"lightsnow.png"},
    is_ground_content = false,
    groups = {crumbly = 3, snowy = 1},
    sounds = default.node_sound_snow_defaults(),
})

minetest.register_node(":specialblocks:bluelight", {
    tiles = {"tutorial_pad.png"},
    is_ground_content = false,
    groups = {cracky = 3, choppy = 1},
    light_source = 8,
    sounds = default.node_sound_glass_defaults(),
})



-- Register Ice Spear
minetest.register_tool("ice:ice_spear", {
    description = "Ice Spear",
    inventory_image = "ice_spear.png",
    wield_scale = {x = 2, y = 2, z = 2},
    tool_capabilities = {
        full_punch_interval = 0.01,
        max_drop_level = 1,
        groupcaps = {
            cracky = {
                times = { [1] = 0.01, [2] = 0.1, [3] = 0.01 },
                uses = 2220,
                maxlevel = 3,
            },
        },
        damage_groups = { fleshy = 27 },
    },
})

-- Register Ice Sword
minetest.register_tool(":delusonersword", {
    inventory_image = "default_obsidian.png^mobs_meat_raw.png^mobs_blood.png^blacc.png",
    wield_scale = {x=1.2, y=1.2, z=1.2},
    tool_capabilities = {
        full_punch_interval = 0.7,
        max_drop_level = 1,
        groupcaps = {
            snappy = {
                times = {[1]=1.90, [2]=0.70, [3]=0.20},
                uses = 100,
                maxlevel = 3,
            },
        },
        damage_groups = {fleshy=50},
       },
    sound = {
        punch_use = "spooky_noise.10",
    },
})

-- Walker by KaadmY

mobs:register_mob(
   "mobs:trileg",
   {
      type = "npc",
      passive = false,
      attack_type = "dogfight",
      damage = 3,
      attack_npcs = false,
      hp_min = 8,
      hp_max = 16,
      armor = 200,
      collisionbox = {-0.3, 0, -0.3, 0.3, 1.5, 0.3},
      visual = "mesh",
      mesh = "walk.b3d",
      textures = {
	 {"walk.png"},
      },
      makes_footstep_sound = true,
      sounds = {
	 attack = "mobs_swing",
	 distance = 16,
      },
      walk_velocity = 1,
      run_velocity = 3,
      jump = true,
      follow = "xdecor:cobweb",
      view_range = 14,
      drops = {
	 {
	    name = "ugx:teleport_fruit",
	    chance = 1, min = 1, max = 2
	 },
	 {
	    name = "default:stick",
	    chance = 3, min = 2, max = 4
	 },
	 {
	    name = "default:tinblock",
	    chance = 15, min = 2, max = 3
	 },
      },
      water_damage = 2,
      lava_damage = 30,
      animation = {
	 speed_normal = 20,
	 speed_run = 20,
	 stand_start = 0,
	 stand_end = 24,
	 punch_start = 25,
	 punch_end = 34,
	 walk_start = 35,
	 walk_end = 50,
	 run_start = 35,
	 run_end = 50,
      },
    on_rightclick = function(self, clicker)

		if mobs:feed_tame(self, clicker, 20, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end
})

mobs:register_egg("mobs:trileg", ("TriLeg"), "unded.png", 1)


mobs:register_spawn(
   "mobs:trileg",
   {
      "default:dry_dirt",
      "default:dirt_with_dry_grass"
   },
   20,
   14,
   12000,
   1,
   31000
)

-- Register Plant-like Block
minetest.register_node(":simulcara", {
    drawtype = "plantlike",
    tiles = {"spwn.png"},
    inventory_image = "spwn.png",
    light_source = 3,
    groups = {unbreakable=1, not_in_creative_inventory=1},
    walkable = false,
    selection_box = {
        type = "fixed",
        fixed = {-0.3, 0, -0.3, 0.3, 1, 0.3},
    },
})



-- Register Fan Tool
minetest.register_tool(":ugx:fan", {
    description = "Hand Fan",
    inventory_image = "fan.png", -- Use your fan texture here
    sound = {name = "wind"}, -- Replace with your fan sound effect
    groups = {tool = 1},

    -- Custom functionality when using the tool
    on_use = function(itemstack, user, pointed_thing)
        -- Check if the pointed_thing is a player
        if pointed_thing.type == "node" and user then
            local player_pos = user:get_pos()
            local pos = pointed_thing.under

            -- Play sound effect for players within 5 blocks
            for _, player in ipairs(minetest.get_connected_players()) do
                local p_pos = player:get_pos()
                if vector.distance(player_pos, p_pos) <= 5 then
                    minetest.sound_play("wind", {pos = p_pos, gain = 1.0})
                end
            end

            -- Add tiny wind/dust particles
            for i = 1, 10 do
                local particle_pos = vector.add(player_pos, vector.new(math.random(-1, 1), math.random(0, 1), math.random(-1, 1)))
                minetest.add_particle({
                    pos = particle_pos,
                    velocity = vector.new(math.random(-1, 1) / 10, math.random(0, 1) / 10, math.random(-1, 1) / 10),
                    acceleration = vector.new(0, -0.1, 0),
                    expirationtime = 3,
                    size = 2,
                    collisiondetection = false,
                    texture = "wind.png", -- Use your dust texture here
                })
            end
        end
        return itemstack
    end,
})




--register Plant-like Lantern
minetest.register_node(":ugx:skull_lantern", {
    description = "skull Lantern",
    drawtype = "plantlike",
    tiles = {"lantern.png"}, -- Use your lantern texture here
    inventory_image = "lantern.png",
    light_source = 10,  -- Brightness level of the lantern
    groups = {snappy = 3, flammable = 2, oddly_breakable_by_hand = 3},
    sounds = default.node_sound_leaves_defaults(),
    walkable = false,
})



minetest.register_node(":9yt67rd6r54yest3wa4ser", {
    tiles = {"1853.png"},
    is_ground_content = false,
    groups = {unbreakable=1, not_in_creative_inventory=1},
})


-- ABM to spawn entities





minetest.register_node(":specialblocks:yellowabyss", {
	description = "spawnblock",
	tiles = {"yeb.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:greenabyss", {
	description = "spawnblock",
	tiles = {"grb.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:whiteabyss", {
	description = "spawnblock",
	tiles = {"whb.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:redabyss", {
	description = "spawnblock",
	tiles = {"redb.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:thornhunter", {
	description = "Thorn Plant",
	tiles = {"thornhunter.png"},
	is_ground_content = true,
   drawtype = "plantlike",
   damage_per_second = 2,
   walkable = false,
   light_source = 2,
  sunlight_propagates = true,
  paramtype2 = "light",
	groups = {snappy=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:briar", {
	description = "Thorn Plant Briar",
	tiles = {"briar_patch.png"},
	is_ground_content = true,
   drawtype = "plantlike",
   damage_per_second = 2,
   walkable = false,
   light_source = 1,
  sunlight_propagates = true,
  paramtype2 = "light",
	groups = {snappy=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:plant", {
	description = "Plant",
  drawtype = "plantlike",
	tiles = {"plant.png"},
  walkable = false,
  sunlight_propagates = true,
  paramtype2 = "light",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:spherestatue", {
	description = "sphere statue",
	tiles = {"spherestatue.png"},
  drawtype = "plantlike",
   walkable = false,
   light_source = 2,
  sunlight_propagates = true,
  paramtype2 = "light",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})


minetest.register_node(":specialblocks:dustwind", {
	description = "decorative dusty block thingy idk",
	drawtype = "glasslike",
	tiles = {"wind.png"},
	light_propagates = true,
	paramtype = "light",
	sunlight_propagates = true,
	use_texture_alpha = "blend",
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3, not_cuttable=1},
})

mobs:register_mob("specialblocks:shadowlord", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
  blood_texture = "shadow_fiend.png",
	damage = 5,
    on_die = function(self, pos)
		local num = math.random(1, 4)
		for i=1,num do
            minetest.add_entity({x=pos.x + math.random(-2, 2), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "mobs:роs_")
            minetest.add_entity({x=pos.x + math.random(-3, 3), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "mobs:роs_")
		end
	end,
	hp_min = 50,
	hp_max = 100,
	armor = 100,
	collisionbox = {-1.1, -1.1, -1.4, 1.4, 1.5, 1.4},
	visual = "upright_sprite",
	textures = {"lordshadow.png"},
	spritediv = {x = 1, y = 1},
	visual_size = {x=2.8, y=2.8},
	makes_footstep_sound = true,
	sounds = {
		attack = "sp",
	},
	walk_velocity = 2,
	run_velocity = 4,
	view_range = 22,
	jump = true,
	drops = {
		{name = "fakeportal", chance = 0.5, min = 0, max = 1},
        
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 10,
	floats = 1,
})


print (" halfway loaded")

minetest.register_node(":specialblocks:purpleabyss", {
	description = "purple abyss",
	tiles = {"pub.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:trianglestatue", {
	description = "triangle statue",
	tiles = {"statue_triangle.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 2,
  sunlight_propagates = true,
  paramtype2 = "light",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":deviledcrystal", {
	description = "DEVILLED CRYSTAL",
   use_texture_alpha = "clip",
	tiles = {"devilcrystal.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:zotcrystal", {
	description = "zot crystal",
   use_texture_alpha = "clip",
	tiles = {"crystalzot.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:metal_statue", {
	description = "metal triangle statue",
	tiles = {"statue_metal.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 2,
  sunlight_propagates = true,
  paramtype2 = "light",
   use_texture_alpha = "clip",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:5", {
	tiles = {"5.png"},
  use_texture_alpha = "blend",
  drawtype = "torchlike",
  walkable = false,
  paramtype2 = "light",
  sunlight_propagates = true,
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:icewindow", {
	tiles = {"icewindow.png"},
  use_texture_alpha = "blend",
  drawtype = "glasslike",
  paramtype2 = "light",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:6", {
  use_texture_alpha = "blend",
	tiles = {"6.png"},
  drawtype = "torchlike",
  walkable = false,
  paramtype2 = "light",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})


minetest.register_node(":specialblocks:7", {
	drawtype = "torchlike",
	tiles = {"7.png"},
	light_propagates = true,
    walkable = false,
	paramtype = "light",
	sunlight_propagates = true,
	use_texture_alpha="blend",
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
})


minetest.register_node(":specialblocks:8", {
  use_texture_alpha = "blend",
  drawtype = "torchlike",
  walkable = false,
  paramtype2 = "light",
	tiles = {"8.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:9", {
	tiles = {"9.png"},
    walkable = false,
	is_ground_content = true,
  use_texture_alpha ="blend",
  drawtype = "torchlike",
  sunlight_propagates = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":icenode", {
	tiles = {"icenode.png"},
	is_ground_content = true,
	groups = {cracky=1, not_in_creative_inventory=1},
})

minetest.register_node(":specialblocks:marble1", {
	description = "marble",
	tiles = {"marble1.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:marble2", {
	description = "marble",
	tiles = {"marble2.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:marble3", {
	description = "marble face",
	tiles = {"marble3.png"},
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:healstation", {
	description = "healing station",
	tiles = {"healstation.png"},
	is_ground_content = true,
   use_texture_alpha = "clip",
   walkable = false,
   light_source = 2,
  sunlight_propagates = true,
  paramtype2 = "light",
   damage_per_second = -37654,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:ashenzari", {
  drawtype = "plantlike",
  paramtype2 = "light",
  sunlight_propagates = true,
	tiles = {"ashenzari.png"},
	is_ground_content = true,
   walkable = false,
  light_source = 5,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:shiningone", {
  drawtype = "plantlike",
  paramtype2 = "light",
  sunlight_propagates = true,
	tiles = {"Old_-_Shining_one_altar_v1.png"},
	is_ground_content = true,
   walkable = false,
  light_source = 5,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:elyvilon", {
  drawtype = "plantlike",
  paramtype2 = "light",
  sunlight_propagates = true,
	tiles = {"Elyvilon_altar.png"},
	is_ground_content = true,
   walkable = false,
  light_source = 2,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:Quazlal", {
  drawtype = "plantlike",
  paramtype2 = "light",
  sunlight_propagates = true,
  use_texture_alpha = true,
	tiles = {"Qazlal_altar.png"},
	is_ground_content = true,
   walkable = false,
  light_source = 5,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:Lugonu", {
  drawtype = "plantlike",
  paramtype2 = "light",
  sunlight_propagates = true,
  use_texture_alpha = true,
	tiles = {"Lugonu_altar.png"},
	is_ground_content = true,
   walkable = false,
  light_source = 5,
	groups = {cracky=1, not_cuttable=1},
})


mobs:register_mob("mobs:dangercloud", {
	-- animal, monster, npc, barbarian
	type = "monster",
	-- agressive, does 21 damage to player when explode
	passive = false,
	attack_type = "explode",
	pathfinding = true,
	damage = 33,
	-- health & armor
	hp_min = 30, hp_max = 40, armor = 100,
	-- textures and model
	collisionbox = {-0.4, -0.4, -0.4, 0.4, 0.4, 0.4},
	visual = "sprite",
	drawtype = "front",
	textures = {
		{"poisoncloud.png"},
	},
	blood_texture = "poisoncloud.png",
	-- sounds
	makes_footstep_sound = true,
	sounds = {
		random = "xairtanks_hiss",
		explode= "tnt_explode",
	},
	-- speed and jump
	walk_velocity = 1.2,
	run_velocity = 2.5,
	jump = true,
    fear_height = 0,
     fly = true,
	fly_in={"air", "default:water_source", "default:river_water_source", "default:river_water_flowing", "maptools:buildable_to_light", "maptools:darkair", "maptools:lightbulb"},
	floats = true,
    floats = 1,
	fall_speed = 0.1,
	view_range = 16,
	-- drops mese or diamond when dead
	drops = {
		{name = "air",
		chance = 10, min = 3, max = 5,},
		{name = "deadtree",
		chance = 5, min = 1, max = 2,},
		{name = "bones:bones",
		chance = 3, min = 1, max = 3,},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,	
})

minetest.register_node(":specialblocks:Jiyva", {
  drawtype = "plantlike",
  paramtype2 = "light",
  sunlight_propagates = true,
  use_texture_alpha = true,
	tiles = {"Jiyva_altar.png"},
	is_ground_content = true,
   walkable = false,
  light_source = 1,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:Faded_altar", {
  drawtype = "plantlike",
  paramtype2 = "light",
  sunlight_propagates = true,
	tiles = {"Faded_altar.png"},
	is_ground_content = true,
   walkable = false,
  light_source = 0,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:gozag", {
  drawtype = "plantlike",
  paramtype2 = "light",
  sunlight_propagates = true,
  use_texture_alpha = true,
	tiles = {"Gozag_altar.png"},
	is_ground_content = true,
   walkable = false,
  light_source = 5,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:sifmuna", {
  drawtype = "plantlike",
  paramtype2 = "light",
  sunlight_propagates = true,
	tiles = {"Old_-_Sif_muna_altar_v1.png"},
	is_ground_content = true,
   walkable = false,
  light_source = 2,
	groups = {cracky=1, not_cuttable=1},
})



minetest.register_node(":specialblocks:cyanabyss", {
   tiles = {"cyanab.png"},
   groups = {cracky=3},
})

minetest.register_node(":specialblocks:invertedabyss", {
   tiles = {"invertab.png"},
   groups = {cracky=3, not_cuttable=1},
})


minetest.register_node(":specialblocks:orangeabyss", {
   tiles = {"orangeab.png"},
   groups = {cracky=3, not_cuttable=1},
})


minetest.register_node(":z_antiflesh", {
   tiles = {"mus.png"},
   groups = {cracky=3, not_in_creative_inventory=1},
})

minetest.register_node(":z_antieye", {
   tiles = {"museye.png"},
   groups = {cracky=3, not_cuttable=1, not_in_creative_inventory=1},
})


minetest.register_node(":z_antimouth", {
   tiles = {"musmo.png"},
   groups = {cracky=3, not_cuttable=1, not_in_creative_inventory=1},
})


-- Register the identify block
minetest.register_node(":identify", {
    tiles = {"identify.png"},
    drawtype = "plantlike",
    is_ground_content = false,
    walkable = false,
    groups = {cracky = 1, level = 2},
})

minetest.register_node(":ugxtextures:eye_flame_guardian", {
    description = "Eye Flame Guardian",
    drawtype = "plantlike",
    use_texture_alpha = "blend",
    visual_scale = 11,
    tiles = {"eye_flame_guardian.png"},
    inventory_image = "eye_flame_guardian.png",
    wield_image = "eye_flame_guardian.png",
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    selection_box = {
        type = "fixed",
        fixed = {-0.5 * 7, -0.5 * 7, -0.5 * 7, 0.5 * 7, 0.5 * 7, 0.5 * 7},
    },
    groups = {cracky = 1, level = 2},
    on_blast = function() end --Make it blast proof
})

minetest.register_abm({
    label = "Eye Flame Guardian attack",
    nodenames = {"ugxtextures:eye_flame_guardian"},
    interval = 2,  -- How often to check (in seconds)
    chance = 1,    -- 1 = always runs
    action = function(pos, node)
        -- Search for entities within 10 blocks
        local objs = minetest.get_objects_inside_radius(pos, 10)
        for _, obj in ipairs(objs) do
            if obj:is_player() or obj:get_luaentity() then
                local name = obj:get_entity_name()
                if name == "mobs:роs_" or
                   name == "mobs_monster:starcursed_mass" or
                   name == "mobs_monster:worker" or
                   name == "mobs_monster:stone_monster" or
                   name == "specialblocks:sp" or
                   name == "mobs_monster:dirt_monster" or
                   name == "specialblocks:sр" then

                    -- Launch a fireball at the entity
                    local fireball = minetest.add_entity(pos, "mobs_monster:fireball")
                    local dir = vector.direction(pos, obj:get_pos())
                    fireball:set_velocity(vector.multiply(dir, 15))
                    fireball:set_acceleration(vector.multiply(dir, 5))
                    fireball:set_yaw(minetest.dir_to_yaw(dir))
                end
            end
        end
    end,
})



minetest.register_entity(":xprotector2:display", {
    initial_properties = {
        physical = false,
        visual = "sprite",
        visual_size = {x = 2, y = 2},
        textures = {"iceman2.png"},
        use_texture_alpha = true,
    },
    
    -- Initialize entity
    on_activate = function(self, staticdata, def)
        self.last_sound_time = 0
    end,

    -- Random noise emission
    on_step = function(self, dtime)
        self.last_sound_time = self.last_sound_time + dtime
        if self.last_sound_time >= 120 then -- 2 minutes
            minetest.sound_play("sp", {
                pos = self.object:get_pos(),
                gain = 1.0,
                max_hear_distance = 20
            })
            self.last_sound_time = 0
        end
    end,

    -- Handle player punching the entity
    on_punch = function(self, puncher)
        local pos = self.object:get_pos()
        -- Show jump scare image and play sound for 3 seconds
        minetest.sound_play("scary", {
            pos = puncher:get_pos(),
            gain = 1.0,
            max_hear_distance = 20
        })
        minetest.chat_send_player(puncher:get_player_name(), "death")
        -- Display the texture on screen (requires client-side mod for actual implementation)
        minetest.show_formspec(puncher:get_player_name(), "ice:jump_scare", "size[8,8]image[0,0;8,8;iceman2.png]")
        -- Remove the entity
        self.object:remove()
    end,
})



minetest.register_node(":specialblocks:frozen", {
   tiles = {"f2.png"},
   groups = {cracky=3, not_cuttable=1},
})



minetest.register_node(":unded", {
   tiles = {"undead.png"},
   groups = {cracky=3, not_cuttable=1},
})


minetest.register_node(":specialblocks:nemelex1", {
	tiles = {"nemelex1.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 7,
  sunlight_propagates = true,
  paramtype2 = "light",
   use_texture_alpha = "blend",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":specialblocks:vehumet1", {
	description = "vehumet",
	tiles = {"vehumet1.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 2,
  sunlight_propagates = true,
  paramtype2 = "light",
   use_texture_alpha = "blend",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1},
})

minetest.register_node(":icetree", {
	tiles = {"tree_demonic11.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 2,
  sunlight_propagates = true,
  paramtype2 = "light",
visual_scale = 6.5,
   use_texture_alpha = "clip",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1, not_in_creative_inventory=1},
})

minetest.register_node(":undead", {
	tiles = {"unded.png"},
	groups = {cracky=1, not_cuttable=1},
})

-- Register Spectral Sword
minetest.register_tool(":spectral:spectral_sword", {
    description = "Spectral Sword",
    inventory_image = "spectralsword.png",
    wield_scale = {x=2, y=2, z=2},
    tool_capabilities = {
        full_punch_interval = 0.5,
        max_drop_level = 3,
        groupcaps = {
            cracky = {
                times = {[1]=0.01, [2]=0.01, [3]=0.01}, -- Digging times for materials
                uses = 100,
                maxlevel = 3,
            },
            snappy = {
                times = {[1]=0.01, [2]=0.01, [3]=0.01}, -- Digging times for materials
                uses = 100,
                maxlevel = 3,
            },
            choppy = {
                times = {[1]=0.01, [2]=0.01, [3]=0.01}, -- Digging times for materials
                uses = 100,
                maxlevel = 3,
            },
            crumbly = {
                times = {[1]=0.01, [2]=0.01, [3]=0.01}, -- Digging times for materials
                uses = 100,
                maxlevel = 3,
            },
        },
        damage_groups = {fleshy=12741}, -- High damage
    },
})

-- Register Spectral Axe
minetest.register_tool(":spectral:spectral_axe", {
    description = "Spectral Axe",
    inventory_image = "spectralaxe.png",
    wield_scale = {x=2, y=2, z=2},
    tool_capabilities = {
        full_punch_interval = 0.5,
        max_drop_level = 3,
        groupcaps = {
            choppy = {
                times = {[1]=0.01, [2]=0.01, [3]=0.01}, -- Digging times for materials
                uses = 100,
                maxlevel = 3,
            },
            snappy = {
                times = {[1]=0.01, [2]=0.01, [3]=0.01}, -- Digging times for materials
                uses = 100,
                maxlevel = 3,
            },
            crumbly = {
                times = {[1]=0.01, [2]=0.01, [3]=0.01}, -- Digging times for materials
                uses = 100,
                maxlevel = 3,
            },
        },
        damage_groups = {fleshy=11111}, -- High damage
    },
})

-- Register Spectral Box
minetest.register_node(":spectral:spectral_box", {
    description = "Spectral Box",
    drop = '',
    tiles = {"spectral_weapon.png"},
    groups = {unbreakable = 1, not_cuttable=1},
    
    -- Define what happens when the node is mined
    on_dig = function(pos, node, puncher, pointed_thing)
        -- Drop spectral sword and axe when the box is mined
        minetest.add_item(pos, "spectral:spectral_sword")
        minetest.add_item(pos, "spectral:spectral_axe")
    end,
})


-- Register Void Knife
minetest.register_tool(":void_knife", {
    inventory_image = "voidknife.png",
    tool_capabilities = {
        full_punch_interval = 0.5,
        max_drop_level = 1,
        groupcaps = {
            snappy = {
                times = {[1]=1.00, [2]=0.50, [3]=0.25}, -- Adjust times for breaking nodes
                uses = 50,
                maxlevel = 2,
            },
        },
        damage_groups = {fleshy=10}, -- Constant damage of 10
    },
})

minetest.register_node(":glitchtree", {
	tiles = {"tree_demonic8.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 0,
  sunlight_propagates = true,
  paramtype2 = "light",
visual_scale = 6.5,
   use_texture_alpha = "clip",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1, not_in_creative_inventory=1},
})

minetest.register_node(":slimetree", {
	tiles = {"tree_demonic12.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 2,
  sunlight_propagates = true,
  paramtype2 = "light",
visual_scale = 6.5,
   use_texture_alpha = "clip",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1, not_in_creative_inventory=1},
})

minetest.register_node(":deadtree", {
	tiles = {"tree_demonic2.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 0,
  sunlight_propagates = true,
  paramtype2 = "light",
visual_scale = 6.5,
   use_texture_alpha = "clip",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1, not_in_creative_inventory=1},
})

minetest.register_node(":rusttree", {
	tiles = {"tree_demonic4.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 0,
  sunlight_propagates = true,
  paramtype2 = "light",
visual_scale = 6.5,
   use_texture_alpha = "clip",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1, not_in_creative_inventory=1},
})

minetest.register_node(":normaltree", {
	tiles = {"tree7.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 0,
  sunlight_propagates = true,
  paramtype2 = "light",
visual_scale = 6.5,
   use_texture_alpha = "clip",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1, not_in_creative_inventory=1},
})

minetest.register_node(":pinetree", {
	tiles = {"tree6.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 0,
  sunlight_propagates = true,
  paramtype2 = "light",
visual_scale = 6.5,
   use_texture_alpha = "clip",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1, not_in_creative_inventory=1},
})

minetest.register_node(":n0rmaltree", {
	tiles = {"tree5.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 0,
  sunlight_propagates = true,
  paramtype2 = "light",
visual_scale = 6.5,
   use_texture_alpha = "clip",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1, not_in_creative_inventory=1},
})

minetest.register_node(":birchtree", {
	tiles = {"tree8.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 0,
  sunlight_propagates = true,
  paramtype2 = "light",
visual_scale = 6.5,
   use_texture_alpha = "clip",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1, not_in_creative_inventory=1},
})

minetest.register_node(":bignormaltree", {
	tiles = {"tree9.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 0,
  sunlight_propagates = true,
  paramtype2 = "light",
visual_scale = 7.2,
   use_texture_alpha = "clip",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1, not_in_creative_inventory=1},
})

minetest.register_node(":roottree", {
	tiles = {"tree_demonic15.png"},
  drawtype = "plantlike",
  walkable = false,
   light_source = 0,
  sunlight_propagates = true,
  paramtype2 = "light",
visual_scale = 6.5,
   use_texture_alpha = "clip",
	is_ground_content = true,
	groups = {cracky=1, not_cuttable=1, not_in_creative_inventory=1},
})

-- Register Mace of Variability
-- Register Mace of Variability
minetest.register_tool(":ugxtextures:mace_of_variability", {
    description = "Mace of Variability",
    inventory_image = "varmac.png",
    wield_scale = {x=2, y=2, z=2},
    tool_capabilities = {
        full_punch_interval = 1.0,
        max_drop_level = 3,
        groupcaps = {
            snappy = {
                times = {[1]=1.00, [2]=0.50, [3]=0.25}, -- Adjust times for breaking nodes
                uses = 100,
                maxlevel = 3,
            },
        },
        damage_groups = {fleshy=1427}, -- Base damage value
     },
     
})



minetest.register_tool(":basetools:freeman_crowbar", {
    description = "Freeman's Crowbar",
    range = 25,
    inventory_image = "freeman_crowbar.png",
    wield_scale = {x = 1.5, y = 1.5, z = 1.5},
    tool_capabilities = {
        full_punch_interval = 0.0,
        max_drop_level = 3,
        groupcaps = {
            unbreakable = {times={[1]=0.0}, uses=0, maxlevel=3},
            cracky = {times={[1]=0.0, [2]=0.0, [3]=0.0}, uses=0, maxlevel=3},
            crumbly = {times={[1]=0.0, [2]=0.0, [3]=0.0}, uses=0, maxlevel=3},
            snappy = {times={[1]=0.0, [2]=0.0, [3]=0.0}, uses=0, maxlevel=3},
            choppy = {times={[1]=0.0, [2]=0.0, [3]=0.0}, uses=0, maxlevel=3},
            plastic = {times={[1]=0.0}, uses=0, maxlevel=3},
        },
        damage_groups = {fleshy = 32767}, -- Max possible damage
    },
})


mobs:register_mob("mobs:еntitу", {
	type = "monster",
	passive = false,
	damage = 37520,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 10, -- shoot for 10 seconds
	dogshoot_count2_max = 5, -- dogfight for 2 seconds
	reach = 2,
	shoot_interval = 1.1,
	arrow = "mobs_monster:item",
	friendly_fire = false,
	shoot_offset = 0,
	hp_min = 65420,
	hp_max = 65535,
	armor = 80,
    on_die = function(self, pos)
		local num = math.random(1, 2)
		for i=1,num do
			minetest.add_entity({x=pos.x + math.random(-2, 2), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "specialblocks:sр")
            minetest.add_entity({x=pos.x + math.random(-2, 2), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "mobs_monster:worker")
            minetest.add_entity({x=pos.x + math.random(-2, 2), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "specialblocks:sp")
            minetest.add_entity({x=pos.x + math.random(-2, 2), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "mobs:роs_")
            minetest.add_entity({x=pos.x + math.random(-3, 3), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "mobs:color")
            minetest.add_entity({x=pos.x + math.random(-2, 2), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "specialblocks:shadowlord")	
		end
	end,
    nametag = "VØID BRАIN",
    visual_size = {x=10, y=10},
	collisionbox = {-3.4, -3, -3.2, 3.72, 3.2, 3.2},
	visual = "sprite",
	textures = {
		{"brain.png"}
	},
	makes_footstep_sound = true,
	sounds = {
		random = "fog",
		shoot_attack = "default_hard_footstep"
	},
	walk_velocity = 15,
	run_velocity = 22,
	jump = true,
	view_range = 1500,
	drops = {
		{name = "mobs:inokuin", chance = 1, min = 1, max = 1},
		{name =  "specialblocks:blood_block", chance = 1, min = 1, max = 5},
		{name = "mobs:veiko", chance = 1, min = 1, max = 1},
		{name = "mobs:demopay", chance = 1, min = 1, max = 1},
  		{name = "mobs:graz", chance = 1, min = 1, max = 1},
		{name = "mobs:swinepine", chance = 1, min = 1, max = 1},
		{name = "mobs:beka", chance = 1, min = 1, max = 1},
     {name = "mobs:purpleinoukin", chance = 1, min = 1, max = 1},
     {name = "mobs:sleeper", chance = 1, min = 1, max = 1},
     {name = "mobs:penta", chance = 1, min = 1, max = 1},
    {name = "mobs:jel", chance = 1, min = 1, max = 1},
     {name = "deadbat", chance = 1, min = 1, max = 1},
     {name = "mobs:stoneman", chance = 1, min = 1, max = 1},
		{name =  "dead_delusoner", chance = 1, min = 1, max = 5},
		{name = "dead_delus0ner", chance = 1, min = 1, max = 1},
		{name = "mobs:stonegrunt", chance = 1, min = 1, max = 1},
  		{name = "mobs:trileg", chance = 1, min = 1, max = 1},
		{name = "mobs_monster:zyme", chance = 1, min = 1, max = 1},
		{name = "deadcaptor", chance = 1, min = 1, max = 1},
     {name = "mobs:etoll", chance = 1, min = 1, max = 1},
     {name = "deadadvisor", chance = 1, min = 1, max = 1},
    {name = "deadadvisor2", chance = 1, min = 1, max = 1},
     {name = "mobs:oreon", chance = 1, min = 1, max = 1},
     {name = "spectre_of_torment", chance = 10, min = 0, max = 1}
     },
   water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 2
})


mobs:register_mob("mobs_monster:worker", {
	type = "monster",
	passive = false,
	damage = 30,
	attack_type = "dogfight",
	pathfinding = true,
    visual_size = {x=2, y=2},
	reach = 4,
	attacks_monsters = false,
	hp_min = 50,
	hp_max = 69,
	armor = 107,
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "upright_sprite",
	textures = {
		{"spectral_warrior.png"}, -- dungeon crawl stone soup thing ඞSUSSYඞSUSSYඞSUSSY
	},
	makes_footstep_sound = true,
	sounds = {
    random = "shut",
    },
	walk_velocity = 5,
	run_velocity = 12,
	stepheight = 1.1,
	fear_height = 2,
	jump = true,
	drops = {
		{name = "mobs:mese_block", chance = 1, min = 2, max = 2},
		{name = "default:diamond", chance = 1, min = 8, max = 18},
		{name = "default:diamond_block", chance = 2, min = 1, max = 4},
	},
	water_damage = 1,
	lava_damage = 3,
	light_damage = 0,
	view_range = 50,
	-- model animation
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	}
})




   mobs:register_mob("specialblocks:sр", {
	type = "monster",
	passive = false,
	damage = 30,
	attack_type = "dogfight",
	pathfinding = true,
    visual_size = {x=2, y=2},
	reach = 2,
	attacks_monsters = false,
	hp_min = 1000,
	hp_max = 2000,
	armor = 300,
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "upright_sprite",
	textures = {
		{"voidelite.png"}, -- dungeon crawl stone soup thing ඞSUSSYඞSUSSYඞSUSSY
	},
	makes_footstep_sound = true,
	sounds = {
    random = "default_steel_footstep",
    },
	walk_velocity = 5,
	run_velocity = 12,
	stepheight = 1.1,
	fear_height = 2,
	jump = true,
	drops = {
		{name = "default:steelblock", chance = 1, min = 2, max = 12},
		{name = "default:diamond", chance = 1, min = 8, max = 18},
		{name = "ignore", chance = 2, min = 1, max = 4},
	},
	water_damage = 1,
	lava_damage = 3,
	light_damage = 0,
	view_range = 50,
	-- model animation
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	}
})

-- Registering the new Ice Sword
minetest.register_tool(":icesword", {
    inventory_image = "icesword.png",
    wield_scale = {x=2, y=2, z=2},  -- Double the size for wielding (doubled view range)
    tool_capabilities = {
        full_punch_interval = 1.0,
        max_drop_level=1,
        groupcaps={
            snappy={times={[1]=1.0, [2]=0.7, [3]=0.3}, uses=300, maxlevel=3},
        },
        damage_groups = {fleshy=300}, -- 300 damage
    },
    sound = {breaks = "default_tool_breaks"},
})

-- Aliases for iceheart, icerune, and specialblocks:frozen2 to point to icesword
minetest.register_alias("iceheart", "icesword")
minetest.register_alias("icerune", "icesword")
minetest.register_alias("specialblocks:frozen", "icesword")

-- Large scale torchlike block (scale 5)
minetest.register_node(":crasheddropper", {
    drawtype = "torchlike",
    tiles = {"crashedsp.png"},
    paramtype = "light",
    light_source = 1,  -- Max light output
    walkable = false,
    sunlight_propagates = true,
    visual_scale = 5,  -- Large scale factor
    groups = {choppy = 2, dig_immediate = 3, flammable = 1},
    sounds = default.node_sound_wood_defaults(),
})

-- Wall-mounted block (scale 1.5) signlike
minetest.register_node(":simulacra_remains", {
    drawtype = "signlike",
    tiles = {"simded.png"},
    paramtype = "light",
    paramtype2 = "wallmounted",
    sunlight_propagates = true,
    walkable = false,
    selection_box = {
        type = "wallmounted",
    },
    visual_scale = 1.5, -- 1.5x scale for the wallmounted block
    groups = {choppy = 2, dig_immediate = 3},
    sounds = default.node_sound_wood_defaults(),
})


minetest.register_node(":void_remains", {
    drawtype = "signlike",
    tiles = {"voiddust.png"},
    paramtype = "light",
    paramtype2 = "wallmounted",
    sunlight_propagates = true,
    walkable = false,
    selection_box = {
        type = "wallmounted",
    },
    visual_scale = 1.6, -- 1.5x scale for the wallmounted block
    groups = {choppy = 2, dig_immediate = 3},
    sounds = default.node_sound_wood_defaults(),
})

-- Craft recipes (example 😋 👌 🙌 😍 😌 🤗 😋 👌 🙌 😍 😌 🤗 😋 👌 🙌 .)


mobs:register_mob("mobs:stoneman", {
	type = "npc",
	hp_min = 33,
	hp_max = 50,
	collisionbox = {-0.1, -1, -0.1, 0.1, 0.95, 0.1},
	visual = "upright_sprite",
	visual_size = {x=2,y=2},
	textures = {"stoneskin_old.png"},
	walk_velocity = 3,
	run_velocity = 6,
	follow = {"default:stone"},
	jump = true,
	jump_height = 2,
	view_range = 69,
})

mobs:register_egg("mobs:stoneman", (" "), "stoneskin_old.png", 1)


mobs:register_mob("mobs:stonegrunt", {
	type = "npc",
	hp_min = 50,
	hp_max = 100,
	collisionbox = {-0.1, -1, -0.1, 0.1, 0.95, 0.1},
	visual = "upright_sprite",
	visual_size = {x=2,y=2},
	textures = {"statue_form_old.png"},
	walk_velocity = 3,
	run_velocity = 6,
	follow = {"default:stonebrick"},
	jump = true,
	jump_height = 4,
	view_range = 69,
})

mobs:register_egg("mobs:stonegrunt", (" "), "statue_form_old.png", 1)


minetest.register_node(":depletedmonstergenerator", {
	tiles = {"deplete.png"},
	on_rightclick = function(pos, node, _)

	if minetest.get_modpath("mobs") then
		minetest.after(0.5, function()
        minetest.env:add_entity(pos, "specialblocks:sp")
     minetest.env:add_entity(pos, "cobble_bomb:cobblebomb")
   minetest.env:add_entity(pos, "mobs_monster:zyme")
   minetest.set_node(pos, {name = "fire:basic_flame"})
   minetest.sound_play("xairtanks_compressor_fail", {pos=pos, gain= 65535, max_hear_distance=50}, true)
		minetest.add_particlespawner(
			1, --amount
			1, --time
			{x=pos.x-1, y=pos.y, z=pos.z-1}, --minpos
			{x=pos.x+1, y=pos.y, z=pos.z+1}, --maxpos
			{x=-0, y=-0, z=-0}, --minvel
			{x=0, y=0, z=0}, --maxvel
			{x=-0.5,y=1,z=-0.5}, --minacc
			{x=0.5,y=1,z=0.5}, --maxacc
			50, --minexptime
			75, --maxexptime
			20, --minsize
           25, --maxsize
			true, --collisiondetection
			"default_item_smoke.png" --texture
		)
		end)
		end
	end,

on_construct = function(pos)
        local meta = minetest.get_meta(pos)
        meta:set_string("infotext", "Creation Reactor (depleted) activate self destruct")
    end,
	groups = {plastic=3, not_in_creative_inventory=1},
})

minetest.register_node(":cursedvoidremnants", {
    drawtype = "plantlike",
    tiles = {"gh.png^mobs_blood.png^sun.png^moon.png^bloodp.png^curse_skull.png^gh0.png"},
    paramtype = "light",
    use_texture_alpha = "blend",
    light_source = 3,
    	on_rightclick = function(pos, node, _)
	if minetest.get_modpath("mobs") then
		minetest.after(0.5, function()
        minetest.env:add_entity(pos, "specialblocks:shadowlord")
     minetest.env:add_entity(pos, "mobs:cursed")
		minetest.remove_node(pos)
		minetest.add_particlespawner(
			30, --amount
			15, --time
			{x=pos.x-1, y=pos.y, z=pos.z-1}, --minpos
			{x=pos.x+1, y=pos.y, z=pos.z+1}, --maxpos
			{x=-0, y=-0, z=-0}, --minvel
			{x=0, y=0, z=0}, --maxvel
			{x=-0.5,y=1,z=-0.5}, --minacc
			{x=0.5,y=1,z=0.5}, --maxacc
			1, --minexptime
			5, --maxexptime
			5, --minsize
			9, --maxsize
			false, --collisiondetection
			"curse_skull.png" --texture
		)
		end)
		end
	end,
	groups = {oddly_breakable_by_hand=3, not_in_creative_inventory=1},
})

mobs:register_mob("mobs:cursed", {
	type = "monster",
	passive = false,
	damage = 666,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 10, -- shoot for 10 seconds
	dogshoot_count2_max = 1, -- dogfight for 2 seconds
	reach = 2,
	shoot_interval = 1,
	arrow = "mobs_monster:item",
	friendly_fire = false,
	shoot_offset = 0,
	hp_min = 666,
	hp_max = 666,
	armor = 100,
    on_die = function(self, pos)
		local num = math.random(1, 2)
		for i=1,num do
			minetest.add_entity({x=pos.x + math.random(-2, 2), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "specialblocks:sр")
            minetest.add_entity({x=pos.x + math.random(-2, 2), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "mobs_monster:worker")
            minetest.add_entity({x=pos.x + math.random(-2, 2), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "specialblocks:sp")
            minetest.add_entity({x=pos.x + math.random(-2, 2), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "mobs:роs_")
            minetest.add_entity({x=pos.x + math.random(-3, 3), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "mobs:color")
            minetest.add_entity({x=pos.x + math.random(-2, 2), y=pos.y + 1, z=pos.z + (math.random(-2, 2))}, "specialblocks:shadowlord")	
		end
	end,
    nametag = "VØID SĶULL",
    visual_size = {x=10, y=10},
	collisionbox = {-2.4, -2, -2.2, 2.72, 2.2, 2.2},
	visual = "sprite",
	textures = {
		{"curse_skull.png"}
	},
	makes_footstep_sound = true,
	sounds = {
		random = "scary",
		shoot_attack = "fog"
	},
	walk_velocity = 15,
	run_velocity = 22,
	jump = true,
	view_range = 666,
	drops = {
		{name = "mobs:stoneman", chance = 1, min = 1, max = 1},
        {name = "delusonersword", chance = 0.5, min = 0, max = 1},
		{name =  "dead_delusoner", chance = 1, min = 1, max = 1},
		{name = "dead_delus0ner", chance = 1, min = 1, max = 1},
		{name = "mobs:stonegrunt", chance = 1, min = 1, max = 1},
  		{name = "mobs:trileg", chance = 1, min = 1, max = 1},
		{name = "mobs_monster:zyme", chance = 1, min = 1, max = 1},
		{name = "deadcaptor", chance = 1, min = 1, max = 1}
     },
   water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 2
})


minetest.register_node(":specialblocks:iceconduit_huge", {
    drawtype = "plantlike",
    tiles = {"icefact.png"},
    paramtype = "light",
    visual_scale = 11,
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})


minetest.register_abm({
	label = "uhhh idk",
	nodenames = {"default:jungletree", "default:aspentree"},
	interval = 900,
	chance = 200,
	catch_up = false,
	action = function(pos, node, active_object_count, active_object_count_wider)
		if active_object_count_wider > 0 then
			return
		end
		pos.x = pos.x + math.random(-2, 2)
		pos.z = pos.z + math.random(-2, 2)
		node = minetest.get_node(pos)
		local below = minetest.get_node(vector.offset(pos, 0, -1, 0))
		if below.name == "default:dirt_with_grass" and node.name == "air" then
			minetest.add_entity(pos, "mobs:stoneman")
            minetest.add_entity(pos, "mobs:stonegrunt")
		end
	end,
})


minetest.register_node(":specialblocks:iceconduit2", {
    drawtype = "torchlike",
    tiles = {"icefact.png"},
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})

minetest.register_node(":specialblocks:iceconduit", {
    drawtype = "plantlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"icefact.png"},
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})

minetest.register_node(":specialblocks:iceconduit_big", {
    drawtype = "plantlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"icefact.png"},
    visual_scale = 6.5,
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})


minetest.register_node(":specialblocks:blackbrick", {
   tiles = {"blackbrick.png"},
   groups = {cracky=2},
})



minetest.register_node(":andperhapsIshallmeetthem", {
   tiles = {"caverealms_thin_ice.png^bubble.png^sun.png^wind.png"},
   groups = {cracky=2},
   use_texture_alpha = true,
   drawtype = "allfaces_optional",
   on_construct = function(pos)
   minetest.sound_play("spooky_noise.10", {pos=pos, gain=1.0, max_hear_distance=20}, true)
        local meta = minetest.get_meta(pos)
        meta:set_string("infotext", "To all those who fell during the void war, either them or ugx")
    end,
    sounds = {
		footstep = { name = "spooky_noise.10", gain = 1.0 },
	}
})

minetest.register_node(":blooddrawing", {
	drawtype = "signlike",
	paramtype = "light",
    walkable = false,
    use_texture_alpha = "blend",
	paramtype2 = "wallmounted",
	tiles = { "blood2.png" },
    groups = {dig_immediate=3},
})


minetest.register_node(":bloodsplat", {
	drawtype = "signlike",
    walkable = false,
	paramtype = "light",
    use_texture_alpha = "blend",
	paramtype2 = "wallmounted",
	tiles = { "blood3.png" },
    groups = {dig_immediate=3},
})


minetest.register_node(":fakeportal2", {
    drawtype = "plantlike",
    tiles = {"fakeportal.png"},
    paramtype = "light",
    use_texture_alpha = "blend",
    visual_scale = 3.0,
    sunlight_propagates = true,
    light_source = 3,
    walkable = false,
    groups = {dig_immediate=3},
})

minetest.register_node(":fakeportal", {
    drawtype = "plantlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"fakeportal.png"},
    paramtype = "light",
    sunlight_propagates = true,
    walkable = false,
    light_source = 3,
    use_texture_alpha = "blend",
    groups = {dig_immediate=3},
})

minetest.register_node(":fakeportal3", {
    drawtype = "plantlike",
    paramtype2 = "wallmounted",
    legacy_wallmounted = true,
    tiles = {"fakeportal.png"},
    visual_scale = 6.5,
    paramtype = "light",
    use_texture_alpha = "blend",
    light_source = 3,
    sunlight_propagates = true,
    walkable = false,
    groups = {dig_immediate=3},
})

mobs:register_mob("mobs_monster:stonegolem", {
	type = "npc",
    attack_npcs = false,
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 2,
	damage = 10,
	hp_min = 80,
	hp_max = 100,
	armor = 99,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=2.2, y=2.2},
	textures = {
		"awards_hardened_miner.png",
	},
	makes_footstep_sound = true,
	sounds = {
		random = "default_hard_footstep",
	},
	walk_velocity = 3,
	run_velocity = 6,
	view_range = 50,
	jump = true,
	drops = {
		{name = "default:stone", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 4,
	floats = 1,
})


mobs:register_mob("mobs_monster:stonegolem", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 2,
	damage = 10,
	hp_min = 80,
	hp_max = 100,
	armor = 99,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=2.2, y=2.2},
	textures = {
		"awards_hardened_miner.png",
	},
	makes_footstep_sound = true,
	sounds = {
		random = "default_hard_footstep",
	},
	walk_velocity = 3,
	run_velocity = 6,
	view_range = 50,
	jump = true,
	drops = {
		{name = "default:stone", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 4,
	floats = 1,
})

mobs:register_mob("mobs_monster:deathcap", {
	type = "monster",
	attack_type = "dogfight",
	pathfinding = true,
	reach = 2,
	damage = 2,
	hp_min = 8,
	hp_max = 20,
	armor = 100,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=2, y=2},
	textures = {
		"deathcap.png",
	},
	makes_footstep_sound = true,
	sounds = {
		random = "spooky_noise.10",
	},
	walk_velocity = 3,
	run_velocity = 6,
	view_range = 50,
	jump = true,
	drops = {
		{name = "default:stone", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 4,
	floats = 1,
})

mobs:register_mob("mobs_monster:fleshgolem", {
	type = "npc",
    attack_npcs = false,
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 2,
	damage = 20,
	hp_min = 100,
	hp_max = 150,
	armor = 55,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=2.2, y=2.2},
	textures = {
		"flesh_golem.png",
	},
	makes_footstep_sound = true,
	sounds = {
		random = "slimes_jump",
	},
	walk_velocity = 3,
	run_velocity = 6,
	view_range = 50,
	jump = true,
	drops = {
		{name = "default:stone", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 4,
	floats = 1,
      follow = {"default:water_source"},
    	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 20, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,
})

mobs:register_egg("mobs_monster:fleshgolem", "flesh golem", "flesh_golem.png")

minetest.register_craft({
	output = 'default:clay_lump 8',
	type = 'shapeless',
	recipe = {"group:bones", "bucket:bucket_water"},
	replacements = {{"bucket:bucket_water", "bucket:bucket_empty"}},
})

minetest.register_craft({
	output = 'default:gravel',
	recipe = {
		{"group:bones", "group:bones", "group:bones"},
	},
})
minetest.register_craft({
	output = 'default:sand',
	recipe = {
		{"group:bones", "", "group:bones"},
		{"", "default:cobble", ""},
		{"group:bones", "", "group:bones"},
	},
})
minetest.register_craft({
	output = 'default:coal_lump',
	recipe = {
		{"", "group:bones", ""},
		{"group:bones", "default:clay_lump", "group:bones"},
		{"", "group:bones", ""},
	},
})
minetest.register_craft({
	output = 'default:dirt',
	recipe = {
		{"group:bones", "default:grass_1", "group:bones"},
		{"group:bones", "group:bones", "group:bones"},
		{"group:bones", "group:bones", "group:bones"},
	},
})

mobs:register_mob("mobs_monster:steelgolem", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 2,
	damage = 7,
	hp_min = 80,
	hp_max = 81,
	armor = 99,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=2.2, y=2.2},
	textures = {
		"ironman.png",
	},
	makes_footstep_sound = true,
	sounds = {
		random = "default_steel_footstep",
	},
	walk_velocity = 3,
	run_velocity = 6,
	view_range = 50,
	jump = true,
	drops = {
		{name = "default:stone", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 4,
	floats = 1,
})

mobs:register_mob("mobs_monster:naturalgolem", {
	type = "npc",
    attack_npcs = false,
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 2,
	damage = 11,
	hp_min = 80,
	hp_max = 111,
	armor = 98,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=2.2, y=2.2},
	textures = {
		"Vine-covered_golem.png",
	},
	makes_footstep_sound = true,
	sounds = {
		random = "default_dirt_footstep",
	},
	walk_velocity = 3,
	run_velocity = 6,
	view_range = 50,
	jump = true,
	drops = {
		{name = "default:dirt", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 4,
	floats = 1,
    follow = {"default:dirt"},
    	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 20, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end,
})

mobs:register_egg("mobs_monster:naturalgolem", "natural golem", "Vine-covered_golem.png")


mobs:register_mob("mobs_monster:fireattacker", {
	type = "monster",
    attack_npcs = false,
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 2,
	damage = 100,
	hp_min = 80,
	hp_max = 100,
	armor = 80,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=2.2, y=2.2},
	textures = {
		"awards_pyromaniac.png",
	},
	makes_footstep_sound = true,
	sounds = {
		random = "fire_large",
	},
	walk_velocity = 3,
	run_velocity = 10,
	view_range = 150,
	jump = true,
    jump_chance = 3,
	jump_height = 10,
   fly = true,
	fly_in={"air", "default:water_source", "default:river_water_source", "default:river_water_flowing", "maptools:buildable_to_light", "maptools:darkair", "maptools:lightbulb"},
	floats = true,
	fall_speed = 0,
	drops = {
		{name = "fire:basic_flame", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 0,
	floats = 1,
})

minetest.register_node(":testnodes:Signal", {
	description = ("Signal"),
	drawtype = "mesh",
	mesh = "character.b3d",
	tiles = {"signal.png"},
  visual_scale = 1.0,
	paramtype = "light",
	paramtype2 = "facedir",

	groups = {dig_immediate=3},
})

mobs:register_mob("mobs:unspeakable", {
	type = "monster",
	attack_type = "dogfight",
	pathfinding = true,
	reach = 2,
	damage = 10,
	hp_min = 88,
	hp_max = 200,
	armor = 99,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "upright_sprite",
	visual_size = {x=1, y=2},
	textures = {
		"unspeakable.png",
	},
	makes_footstep_sound = true,
	sounds = {
		random = "fog",
		damage = "spooky_noise",
		death = "scary",

   },
	walk_velocity = 3,
	run_velocity = 6,
	view_range = 50,
	jump = true,
	drops = {
		{name = "", chance = 0.5, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 4,
	floats = 1,
})



