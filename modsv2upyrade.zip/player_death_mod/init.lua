-- Define the radius within which players will be killed
local killRadius = 22

-- Register the death block
minetest.register_node("player_death_mod:death666_you_are_deadnowrunbeforeitfindsyouandkillsyou666___error", {
	tiles = {"HTAED.png"},
	groups = {plastic = 9},
})

-- Add an ABM (Active Block Modifier) to check for nearby players and kill them
minetest.register_abm({
	nodenames = {"player_death_mod:death666_you_are_deadnowrunbeforeitfindsyouandkillsyou666___error"},
	interval = 1,
	chance = 1,
	action = function(pos, node)
		local players = minetest.get_objects_inside_radius(pos, killRadius)
		for _, player in ipairs(players) do
			if player:is_player() then
				player:set_hp(0) -- Kill the player
			end
		end
	end,
})